# Hardening plan

The current architecture refactor follows [refactor-architecture.md](refactor-architecture.md).
It expands the earlier pipeline-extraction proposal below into explicit planning,
step execution, final review, delivery, and ticket coordination responsibilities.
The earlier PR list is retained as historical context; use the current document
for the refactor's ownership and validation requirements.

Follow-up work from the repo analysis. Product boundaries in [automation-harness-spec.md](automation-harness-spec.md) stay: Pi-only, localhost daemon, JSON store until measured need, no extra notifiers.

Use `node scripts/nav.mjs`, `node scripts/test.mjs`, and `node scripts/seed.mjs` while doing this. They read current source and `JsonStore` instead of a parallel inventory.

## Out of scope

- Second agent harness or provider layer
- Replacing `state-v3.json` with SQLite
- OS/email/Slack notifications
- Direct deploy

Done in-tree: PR1 (named statuses in `src/run-status.js`), PR2 (`src/http.js`), PR4 (`test/e2e-daemon.test.js`), PR5 (Pi labels). Screenshots: [evidence/](evidence/). PR3 (pipeline extract) and PR6 (jj parallel) remain.

## PR 1 — Named run vocabulary

**Why:** Run, merge, checkpoint, and recovery statuses are raw strings copied across [src/store.js](../src/store.js), [src/execution.js](../src/execution.js), and [src/server.js](../src/server.js). Splitting the daemon later without a single list will drop a transition.

**Do:**

- Export frozen status sets from `src/execution.js` (or a tiny `src/run-status.js` if execution would get noisier): run, merge, step, checkpoint kind, recovery kind.
- Replace every matching string list, including daemon-restart interruption in `JsonStore.init`.
- Keep values identical; this is a rename-to-constants change, not a behavior change.

**Prove:** existing store/execution/server tests plus `node scripts/nav.mjs stages`.

## PR 2 — HTTP surface out of `createDaemon`

**Why:** [src/server.js](../src/server.js) is ~2.3k lines of pipeline + routing. The route table is already recoverable via `node scripts/nav.mjs routes`.

**Do:**

- Move `api()`, `staticFile()`, `authorizeApi()`, `handleRequest()` into `src/http.js` (or similar) that receives the daemon context.
- `createDaemon` keeps store, lock, harness, previews, and the ticket pipeline.
- Do not change paths or payloads.

**Prove:** `test/server.test.js`, `node scripts/nav.mjs routes` still lists the same `METHOD path` pairs.

## PR 3 — Ticket pipeline out of `createDaemon`

**Why:** After PR 2, the remaining bulk is `beginTicket` → requirements → explore → design → implement → verify → handoff.

**Do:**

- Extract pipeline functions into `src/pipeline.js` (name flexible) that the daemon calls.
- Keep `createDaemon` as composition: store + harness + pipeline + http.
- No workflow or permission changes.

**Prove:** server tests, workflow tests, `node scripts/seed.mjs plan-approval` still produces an approvable run.

## PR 4 — Daemon-level e2e without Pi

**Why:** [test/e2e-automation.test.js](../test/e2e-automation.test.js) only stitches mocked Jira + GitLab. The live daemon path (seed → approve → step gate → compact run) is untested as one sequence.

**Do:**

- Add `test/e2e-daemon.test.js` using `withDaemon`, `invoke`, and `writeSeed` from [test/helpers.js](../test/helpers.js).
- Cover at least: seed `plan-approval` → `POST /approve` → mocked worker/supervisor → step `review_ready` → accept; seed `needs-attention` → CLI `wait` exits 1; restart recovery of an in-flight status.
- Mock `PiHarness` methods; do not call a real model.

**Prove:** `node scripts/test.mjs e2e`.

## PR 5 — Drop leftover Codex names

**Why:** The API already reports the real Pi provider (`test/server.test.js`). The UI still uses `codexModels` and the default profile provider is `openai-codex`.

**Do:**

- Rename `codexModels` → `piModels` (or `models`) in [public/app.js](../public/app.js).
- Keep profile provider configurable; only change labels/defaults if they disagree with `GET /api/models`.
- Do not retarget models without a dashboard-visible reason.

**Prove:** `test/ui-model.test.js`, server models test, `node --check public/app.js`.

## PR 6 — Jujutsu sibling isolation (optional, after 1–4)

**Why:** Git parallel writers use isolated worktrees. README states jj siblings currently run serially.

**Do:**

- Only if a real ticket needs concurrent jj writers.
- Give dependency-ready jj siblings isolated working copies whose change IDs survive, then export/cherry-pick in review order as Git does today.
- Conflicts still stop for humans.

**Prove:** extend [test/jj.test.js](../test/jj.test.js) and [test/worktrees.test.js](../test/worktrees.test.js). Skip this PR if serial jj remains an accepted MVP limit.

## Order

```
PR1 vocabulary
  └─ PR2 http extract
       └─ PR3 pipeline extract
            └─ PR4 daemon e2e
  └─ PR5 Codex rename (independent after PR1, can parallel PR2)
PR6 jj parallel (independent, lowest urgency)
```

## Checks for every PR

```bash
node scripts/test.mjs
node scripts/test.mjs --check
node scripts/nav.mjs --json > /tmp/nav-before.json   # before behavior changes
```

### Review recovery and proportional execution

- Final reviewer responses are checked for complete final-criterion coverage,
  duplicate verdicts and usable citation identities before the session ends.
  One repair turn can fill coverage or citations; it cannot discard findings.
- Successful reviewer results are saved per role and immutable evidence digest.
  A failed sibling does not repeat them. Changed code, checks, evidence, media,
  constraints, access or model profile produces a different cache identity.
- New plans can explicitly approve `reviewPolicy: {mode: "small", reason, risks: []}`.
  One comprehensive independent reviewer covers bounded single-repository diffs
  of at most eight files and 400 lines. Larger, risky and legacy plans retain
  requirements, integration and verification reviewers. No proof gates are waived.
- Criterion bindings default to `scope: "final"`. Temporary construction constraints
  use `scope: "step"`: checked at acceptance and retained as history, not asserted
  as properties of the finished product. Final product requirements must not use
  step scope. Plan small changes as a vertical slice with its tests and proof.
- `/api/health` includes event-loop delay and last storage clone/serialization metrics.
  The dashboard checks responsiveness independently of SSE, distinguishes review
  evidence errors from approval gates, and shows the next action and last activity.
- Completed-run output exceeding 4,000 characters is retained in historical-output
  artifacts; live state keeps 2,000-character excerpts. Active output remains intact.
  Persistence stays immediate so browser reload cannot miss the last emitted output.
  Full-state transactional cloning remains; use measured storage timings before
  considering a different store or more complicated persistence scheme.
- Supervision should report meaningful gates, failures and completion only. Healthy
  model/tool activity is a verified wait, not a reason to restart or send an update.

Completed runs now keep identity and cached dashboard summaries in the working
state, with audit fields in immutable, content-addressed `run-history/*.json`
files. Existing readers hydrate history on first access; unrelated updates clone
and serialize only the working state. Resuming a completed run restores its full
record. Archive writes precede the atomic state commit, and missing or corrupt
archives fail explicitly. Backups must include the entire data directory, not
just `state-v3.json`. Old archive revisions are retained; this reduces hot-state
work, not total audit disk usage. History reads use the existing synchronous store
interface, so opening an individual large history still incurs a parse cost.

Requirements and planning prompts preserve the ticket's observable acceptance
outcomes, with detailed validation rules and constraints retained as assertions
under their owning outcomes. Splits need a behavioral or verification reason;
there is no arbitrary criterion-count cap. Worker, verifier, reviewer, and capture
instructions explicitly reuse evidence across criteria while requiring a separate
assertion-based verdict for each. Existing freshness, identity, and visual
inspection gates remain unchanged. This guides future generation; it does not
rewrite an already approved contract or guarantee a particular model output.

### Simplify the model-facing contract

New planners describe acceptance outcomes inline as `{text, evidence, scope?}`.
The normalizer assigns criterion identities, indices, default journey identities,
and visual/video flags. Legacy approved string criteria and bindings still
round-trip unchanged. Current-check citations may be just `{type:"check"}`;
the verifier attaches the actual invocation scope and attempt identity. Explicit
historical references are never upgraded silently, and artifact/media references
still require real evidence IDs and inspection. The planner defaults to one
implementation slice with its tests, docs and capture updates. Editing existing
verification configuration no longer triggers a bootstrap-only scope restriction;
normal declared scope and review budgets still apply.

### Reliability measurement

Optimize for correct delivery with occasional planned decisions. Each run exposes
`reliability` in its status response; the dashboard shows required-criterion
coverage and observed execution/decision-wait time. Read it with
`node src/cli.js status <ticketId>`. Existing cost and usage fields accompany it.
Ready requires delivered status, every required final criterion verified with
valid evidence, passing final checks, and a final review without actionable
findings. This reports harness acceptance, not independent ground truth.

Record only status transitions for timing. Pre-existing runs explicitly have
partial/unavailable coverage. Execution time is wall time in execution statuses,
not CPU time, and may include an unobserved outage until restart recovery.
Planned-gate resumes are separate from recovery resumes, but transitions cannot
reliably identify human versus automatic action. Report known restarts, steers,
retries and exact repeated attempt errors separately rather than inventing a
single human-intervention count. First-pass success is unknown without complete
transition history. Independent acceptance and regression assessments remain
not_recorded until an external assessment exists; model-generated tests alone do
not establish them. Benchmark comparable approved tickets from clean snapshots
with a fixed harness revision and predefined external acceptance checks; compare
correct completion, interventions, elapsed execution time, cost, and regressions.
