import { compactRun } from "./inspection.js";
import { createHash, randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { mkdir, writeFile, rename, rm } from "node:fs/promises";
import { join } from "node:path";

// Keep identity and lifecycle fields available without opening audit history.
const hotKeys = new Set(["id", "runId", "ticket", "status", "auto", "createdAt", "updatedAt", "historySummary", "checkpoint", "supervisorObservation", "access", "submission", "completedAt"]);
const loaded = new WeakMap();

function historyFile(dataDir, digest) {
  if (!/^[a-f0-9]{64}$/.test(digest)) throw new Error("Invalid run history reference");
  return join(dataDir, "run-history", `${digest}.json`);
}

export function historyView(state, dataDir) {
  const view = structuredClone(state);
  for (const bucket of [view.ticketRuns, view.retainedRuns]) for (const run of Object.values(bucket || {})) {
    if (!run.historyRef) continue;
    const ref = run.historyRef;
    let history;
    const open = () => {
      // Existing store readers are synchronous. Open only on first history access
      // in this snapshot; unrelated updates never read or clone the archive.
      if (!history) {
        const content = readFileSync(historyFile(dataDir, ref.digest), "utf8");
        if (createHash("sha256").update(content).digest("hex") !== ref.digest) throw new Error("Run history checksum mismatch");
        history = JSON.parse(content);
        loaded.set(run, history);
      }
      return history;
    };
    for (const key of ref.keys) Object.defineProperty(run, key, {
      enumerable: true, configurable: true,
      get() { return open()[key]; },
      set(value) { Object.defineProperty(run, key, { value, writable: true, enumerable: true, configurable: true }); }
    });
  }
  return view;
}

export async function storeRunHistory(state, dataDir) {
  const result = { ...state };
  for (const name of ["ticketRuns", "retainedRuns"]) {
    result[name] = {};
    for (const [id, run] of Object.entries(state[name] || {})) {
      if (run.status !== "completed" || !run.runId) {
        const full = { ...run };
        delete full.historyRef;
        delete full.historySummary;
        result[name][id] = full;
        continue;
      }
      const descriptors = Object.getOwnPropertyDescriptors(run);
      const untouched = run.historyRef && !loaded.has(run)
        && run.historyRef.keys.every((key) => descriptors[key]?.get)
        && Object.keys(run).every((key) => hotKeys.has(key) || key === "historyRef" || run.historyRef.keys.includes(key));
      if (untouched) {
        result[name][id] = Object.fromEntries(Object.entries(descriptors).filter(([, d]) => "value" in d).map(([key, d]) => [key, d.value]));
        continue;
      }
      const hot = {}, history = {};
      for (const [key, value] of Object.entries(run)) {
        if (key !== "historyRef") (hotKeys.has(key) ? hot : history)[key] = value;
      }
      hot.historySummary = compactRun({ ...run, historySummary: null });
      const content = JSON.stringify(history);
      const digest = createHash("sha256").update(content).digest("hex");
      await mkdir(join(dataDir, "run-history"), { recursive: true });
      // Immutable content-addressed files precede the atomic state commit. Never
      // overwrite an archive that a previous durable revision still references.
      const target = historyFile(dataDir, digest);
      const temporary = `${target}.${randomUUID()}.tmp`;
      try {
        await writeFile(temporary, content, { flag: "wx" });
        await rename(temporary, target);
      } finally { await rm(temporary, { force: true }); }
      hot.historyRef = { digest, keys: Object.keys(history) };
      result[name][id] = hot;
    }
  }
  return result;
}
