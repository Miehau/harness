import { createHash, randomUUID } from "node:crypto";
import { stepStatuses } from "./run-status.js";
export const defaultReviewBudget = Object.freeze({ maxFiles: 8, maxChangedLines: 400 });

function positiveInteger(value, fallback) {
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : fallback;
}

function normalizeReviewBudget(raw = {}) {
  return {
    maxFiles: positiveInteger(raw?.maxFiles, defaultReviewBudget.maxFiles),
    maxChangedLines: positiveInteger(raw?.maxChangedLines, defaultReviewBudget.maxChangedLines),
    justification: String(raw?.justification || "").trim()
  };
}

function excludedFromReviewBudget(path) {
  return /(^|\/)(?:dist|build|coverage|vendor|generated)(?:\/|$)/i.test(path)
    || /^\.agent-plan\/(?:evidence\/|project\.json$|verify\.mjs$)/i.test(path)
    || /(^|\/)(?:package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|pnpm-lock\.yaml|bun\.lockb?)$/i.test(path);
}

function idFrom(value, used) {
  const base = String(value || "step")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || `step-${randomUUID().slice(0, 8)}`;
  let id = base;
  let suffix = 2;
  while (used.has(id)) id = `${base}-${suffix++}`;
  used.add(id);
  return id;
}

function strings(value) {
  if (Array.isArray(value)) return value.map(String).map((item) => item.trim()).filter(Boolean);
  if (typeof value === "string") return value.split("\n").map((item) => item.trim()).filter(Boolean);
  return [];
}

export function normalizeReviewPolicy(value) {
  if (!value || !["small", "standard"].includes(value.mode) || !String(value.reason || "").trim()) throw new Error("Review policy needs small or standard mode and a reason");
  if (value.mode === "small" && (!Array.isArray(value.risks) || value.risks.length)) throw new Error("Small review requires an explicit empty risk list");
  return { mode: value.mode, reason: String(value.reason).trim(), risks: strings(value.risks) };
}

export function finalReviewRoles(plan, diff = {}) {
  const policy = plan?.reviewPolicy;
  const small = policy?.mode === "small" && policy.risks?.length === 0 && policy.reason
    && diff.available !== false && (diff.files || []).length > 0 && diff.files.length <= 8
    && Number.isFinite(diff.changedLines) && diff.changedLines <= 400
    && (diff.repositories || []).length <= 1;
  return small ? ["requirements"] : ["requirements", "integration", "verification"];
}

export function normalizeUiImpact(value) {
  if (!value || !["none", "minor", "material"].includes(value.level)) throw new Error("UI impact must be none, minor, or material");
  const reason = String(value.reason || "").trim().slice(0, 1000);
  if (!reason) throw new Error("UI impact requires a reason (including minor-change exemptions)");
  return { level: value.level, reason };
}

export function criterionId(stepId, index, text) {
  const digest = createHash("sha256").update(`${stepId}\0${index}\0${text}`).digest("hex").slice(0, 16);
  return `criterion-${digest}`;
}

function normalizeCriterionBindings(value, criteria) {
  if (!Array.isArray(value)) throw new Error("criterionBindings must be an array");
  const seen = new Set();
  return value.map((binding) => {
    if (!binding || !Number.isInteger(binding.index) || binding.index < 0 || binding.index >= criteria.length || seen.has(binding.index)) throw new Error("Criterion bindings require unique valid acceptance-criterion indices");
    seen.add(binding.index);
    if (!/^[a-z0-9][a-z0-9_-]{0,99}$/i.test(binding.id || "")) throw new Error("Criterion bindings require stable IDs");
    if (!["check", "screenshot", "video"].includes(binding.evidence)) throw new Error("Criterion evidence must be check, screenshot, or video");
    if (binding.evidence !== "check" && !/^[a-z0-9][a-z0-9_-]{0,99}$/i.test(binding.journeyId || "")) throw new Error("Visual criteria require a stable journeyId");
    if (binding.scope !== undefined && !["step", "final"].includes(binding.scope)) throw new Error("Criterion scope must be step or final");
    return { index: binding.index, id: binding.id, evidence: binding.evidence, ...(binding.scope ? { scope: binding.scope } : {}), ...(binding.evidence !== "check" ? { journeyId: binding.journeyId } : {}) };
  });
}

function normalizeStep(raw, used, defaultHarness) {
  if (!raw || typeof raw !== "object") throw new Error("Each step must be an object");
  const title = String(raw.title || raw.name || "Untitled step").trim();
  const id = idFrom(raw.id || title, used);
  const inline = Array.isArray(raw.acceptanceCriteria) && raw.acceptanceCriteria.some((item) => item && typeof item === "object");
  if (inline && raw.criterionBindings !== undefined) throw new Error("Use inline acceptance criteria or legacy criterionBindings, not both");
  const criteria = inline ? raw.acceptanceCriteria.map((item) => {
    if (!item || typeof item !== "object" || typeof item.text !== "string" || !item.text.trim()) throw new Error("Inline acceptance criteria require non-empty text");
    return item.text.trim();
  }) : strings(raw.acceptanceCriteria);
  const bindings = inline ? raw.acceptanceCriteria.map((item, index) => ({
    index, id: criterionId(id, index, criteria[index]), evidence: item.evidence,
    scope: item.scope || "final",
    ...(item.evidence !== "check" ? { journeyId: item.journeyId || `${id}-journey` } : {})
  })) : raw.criterionBindings;
  return {
    id,
    type: "step",
    title,
    role: ["architecture", "implementation"].includes(raw.role) ? raw.role : "implementation",
    description: String(raw.description || "").trim(),
    prompt: String(raw.prompt || "").trim(),
    contextPolicy: ["fresh", "seeded", "fork"].includes(raw.contextPolicy) ? raw.contextPolicy : "seeded",
    harness: String(raw.harness || defaultHarness || "pi"),
    agentId: String(raw.agentId || `worker:${id}`),
    permission: ["none", "read", "write"].includes(raw.permission) ? raw.permission : "read",
    writeScope: String(raw.writeScope || "").trim(),
    expectedFiles: strings(raw.expectedFiles),
    estimatedChangedLines: Math.max(0, Number(raw.estimatedChangedLines) || 0),
    reviewBudget: normalizeReviewBudget(raw.reviewBudget),
    skills: strings(raw.skills),
    references: strings(raw.references),
    requirementIds: strings(raw.requirementIds),
    capabilityIds: strings(raw.capabilityIds),
    deltaIds: strings(raw.deltaIds),
    productContext: String(raw.productContext || "").trim(),
    expectedArtifacts: strings(raw.expectedArtifacts),
    acceptanceCriteria: criteria,
    ...(bindings !== undefined ? { criterionBindings: normalizeCriterionBindings(bindings, criteria) } : {}),
    ...(raw.uiPlan && typeof raw.uiPlan === "object" ? { uiPlan: Object.fromEntries(["reuse", "hierarchy", "states", "interaction", "proof", "deviations"].map((key) => [key, String(raw.uiPlan[key] || "").trim().slice(0, 600)])) } : {}),
    requiresVisualEvidence: raw.requiresVisualEvidence === true || raw.requiresVideoEvidence === true || (inline && bindings.some((item) => item.evidence !== "check")),
    requiresVideoEvidence: raw.requiresVideoEvidence === true || (inline && bindings.some((item) => item.evidence === "video")),
    dependsOn: strings(raw.dependsOn),
    required: raw.required !== false,
    status: stepStatuses.has(raw.status) ? raw.status : "ready",
    attempts: Array.isArray(raw.attempts) ? raw.attempts : [],
    artifacts: Array.isArray(raw.artifacts) ? raw.artifacts : [],
    attachments: Array.isArray(raw.attachments) ? raw.attachments : [],
    diff: raw.diff || null,
    vcsChange: raw.vcsChange || null,
    sessionFile: raw.sessionFile || null,
    supervisorReview: raw.supervisorReview || null,
    lastError: raw.lastError || null
  };
}

export function planReviewViolations(plan) {
  return flattenSteps(plan).flatMap((step) => {
    if (step.permission !== "write") return [];
    const budget = normalizeReviewBudget(step.reviewBudget);
    const exception = budget.justification;
    const violations = [];
    if (!step.expectedFiles.length) violations.push(`${step.title}: expectedFiles must name the predicted review surface`);
    if (!step.estimatedChangedLines) violations.push(`${step.title}: estimatedChangedLines must be a positive review estimate`);
    if (/^(?:\*|\*\*)$/.test(step.writeScope) && !exception) violations.push(`${step.title}: broad write scope requires a review-budget justification`);
    if (budget.maxFiles > defaultReviewBudget.maxFiles && !exception) violations.push(`${step.title}: maxFiles above ${defaultReviewBudget.maxFiles} requires justification`);
    if (budget.maxChangedLines > defaultReviewBudget.maxChangedLines && !exception) violations.push(`${step.title}: maxChangedLines above ${defaultReviewBudget.maxChangedLines} requires justification`);
    if (step.expectedFiles.length > budget.maxFiles && !exception) violations.push(`${step.title}: ${step.expectedFiles.length} expected files exceed the ${budget.maxFiles}-file review budget`);
    if (step.estimatedChangedLines > budget.maxChangedLines && !exception) violations.push(`${step.title}: ${step.estimatedChangedLines} estimated changed lines exceed the ${budget.maxChangedLines}-line review budget`);
    return violations;
  });
}

export function diffReviewBudget(step, diff) {
  const budget = normalizeReviewBudget(step?.reviewBudget);
  const fileStats = (diff?.fileStats || (diff?.files || []).map((path) => ({ path, additions: 0, deletions: 0 })))
    .filter((file) => !excludedFromReviewBudget(file.path));
  const files = fileStats.length;
  const changedLines = fileStats.reduce((total, file) => total + Number(file.additions || 0) + Number(file.deletions || 0), 0);
  const reasons = [
    files > budget.maxFiles ? `${files} reviewable files exceed the ${budget.maxFiles}-file budget` : null,
    changedLines > budget.maxChangedLines ? `${changedLines} changed lines exceed the ${budget.maxChangedLines}-line budget` : null
  ].filter(Boolean);
  return {
    ...budget,
    files,
    changedLines,
    excludedFiles: Math.max(0, (diff?.files?.length || 0) - files),
    reasons,
    exceeded: reasons.length > 0 && !budget.justification
  };
}

export function reviewBudgetRequiresRollback(result, multiplier = 2) {
  return Number(result?.files || 0) > Number(result?.maxFiles || 0) * multiplier
    || Number(result?.changedLines || 0) > Number(result?.maxChangedLines || 0) * multiplier;
}

export function normalizePlan(raw) {
  if (!raw || typeof raw !== "object") throw new Error("Plan must be an object");
  const used = new Set();
  const harness = String(raw.harness || "pi");
  const nodes = (Array.isArray(raw.nodes) ? raw.nodes : []).map((node) => {
    if (node?.type === "group" || Array.isArray(node?.children)) {
      const title = String(node.title || node.name || "Untitled group").trim();
      const id = idFrom(node.id || title, used);
      const children = (node.children || []).map((child) => {
        if (child?.type === "group" || Array.isArray(child?.children)) throw new Error("MVP supports one nesting level only");
        return normalizeStep(child, used, harness);
      });
      if (!children.length) throw new Error(`Group “${title}” needs at least one child step`);
      return { id, type: "group", title, description: String(node.description || "").trim(), required: node.required !== false, children };
    }
    return normalizeStep(node, used, harness);
  });
  if (!nodes.length) throw new Error("Plan needs at least one step");

  validatePlanDependencies({ nodes });

  const criterionIds = flattenSteps({ nodes }).flatMap((step) => (step.criterionBindings || []).map((binding) => binding.id));
  if (new Set(criterionIds).size !== criterionIds.length) throw new Error("Criterion IDs must be unique across the plan");
  return {
    ...(raw.reviewPolicy !== undefined ? { reviewPolicy: normalizeReviewPolicy(raw.reviewPolicy) } : {}),
    ...(raw.uiImpact !== undefined ? { uiImpact: normalizeUiImpact(raw.uiImpact) } : {}),
    id: String(raw.id || `plan-${randomUUID().slice(0, 8)}`),
    title: String(raw.title || "Untitled plan").trim(),
    summary: String(raw.summary || "").trim(),
    harness,
    createdAt: raw.createdAt || new Date().toISOString(),
    nodes
  };
}

function rawNodes(raw) {
  return (Array.isArray(raw?.nodes) ? raw.nodes : []).flatMap((node) =>
    node?.type === "group" || Array.isArray(node?.children) ? [node, ...(node.children || [])] : [node]
  );
}

export function normalizeEditedPlan(raw) {
  if (!raw || typeof raw !== "object") throw new Error("Plan must be an object");
  const ids = rawNodes(raw).map((node) => String(node?.id || "").trim()).filter(Boolean);
  const duplicate = ids.find((id, index) => ids.indexOf(id) !== index);
  if (duplicate) throw new Error(`Plan contains duplicate id “${duplicate}”`);

  return normalizePlan(raw);
}

function validatePlanDependencies(plan) {
  const known = new Set(rawNodes(plan).map((node) => node.id));
  for (const step of flattenSteps(plan)) {
    for (const dependency of step.dependsOn) {
      if (dependency === step.id) throw new Error(`Step “${step.id}” cannot depend on itself`);
      if (!known.has(dependency)) throw new Error(`Step “${step.id}” has unknown dependency “${dependency}”`);
    }
  }
  const groups = new Map(plan.nodes.filter((node) => node.type === "group").map((group) => [group.id, group.children.map((step) => step.id)]));
  const edges = new Map(flattenSteps(plan).map((step) => [step.id, step.dependsOn.flatMap((id) => groups.get(id) || [id])]));
  const visiting = new Set();
  const visited = new Set();
  const visit = (id) => {
    if (visiting.has(id)) throw new Error(`Plan dependency cycle includes “${id}”`);
    if (visited.has(id)) return;
    visiting.add(id);
    for (const dependency of edges.get(id) || []) visit(dependency);
    visiting.delete(id);
    visited.add(id);
  };
  for (const id of edges.keys()) visit(id);
  return plan;
}

export function flattenSteps(plan) {
  return (plan?.nodes || []).flatMap((node) => node.type === "group" ? node.children : [node]);
}

export function findNode(plan, id) {
  for (const node of plan?.nodes || []) {
    if (node.id === id) return node;
    if (node.type === "group") {
      const child = node.children.find((item) => item.id === id);
      if (child) return child;
    }
  }
  return null;
}

export function parentGroup(plan, stepId) {
  return (plan?.nodes || []).find((node) => node.type === "group" && node.children.some((child) => child.id === stepId)) || null;
}

export function groupStatus(group) {
  const required = group.children.filter((step) => step.required);
  if (required.every((step) => step.status === "accepted")) return "accepted";
  if (required.some((step) => ["failed", "needs_attention", "interrupted", "cancelled"].includes(step.status))) return "needs_attention";
  if (required.some((step) => ["needs_input", "awaiting_approval"].includes(step.status))) return "needs_input";
  if (required.some((step) => ["running", "fixing"].includes(step.status))) return "running";
  if (required.some((step) => step.status === "review_ready")) return "review";
  return "blocked";
}

export function dependencySteps(plan, step) {
  const result = [];
  for (const id of step.dependsOn || []) {
    const node = findNode(plan, id);
    if (!node) continue;
    if (node.type === "group") result.push(...node.children.filter((child) => child.required));
    else result.push(node);
  }
  return result;
}

export function blockingReasons(plan, step) {
  return dependencySteps(plan, step)
    .filter((dependency) => dependency.status !== "accepted")
    .map((dependency) => `${dependency.title} is ${dependency.status}`);
}

export function dependencyArtifacts(plan, step) {
  const dependencies = [];
  const visited = new Set([step.id]);
  const visit = (current) => {
    for (const dependency of dependencySteps(plan, current)) {
      if (visited.has(dependency.id) || dependency.status !== "accepted") continue;
      visited.add(dependency.id);
      visit(dependency);
      dependencies.push(dependency);
    }
  };
  visit(step);
  return dependencies.flatMap((dependency) =>
    (dependency.artifacts || [])
      .filter((artifact) => artifact.kind !== "step-verification")
      .map((artifact) => ({ ...artifact, sourceStepId: dependency.id, sourceStepTitle: dependency.title,
        sourceStepOutcome: dependency.description || dependency.title, sourceStepFiles: dependency.diff?.files || [] }))
  );
}

export function planProgress(plan) {
  const steps = flattenSteps(plan);
  const accepted = steps.filter((step) => step.status === "accepted").length;
  return { accepted, total: steps.length, percent: steps.length ? Math.round((accepted / steps.length) * 100) : 0 };
}
