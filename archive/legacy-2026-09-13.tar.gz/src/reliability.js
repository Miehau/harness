import { flattenSteps } from "./plan.js";
import { projectProofMap, proofEligibility } from "./proof-map.js";

const decisions = new Set(["awaiting_requirements", "awaiting_input", "awaiting_approval", "awaiting_step_review", "awaiting_evidence_review"]);
const stopped = new Set(["failed", "interrupted", "paused", "needs_attention", "cancelled"]);
const terminal = new Set(["completed", "cancelled"]);

// Record transitions, not another copy of the run. Older runs explicitly have
// partial coverage; missing history must never look like zero waiting or rescues.
export function recordReliabilityTransitions(previous, draft, at = new Date().toISOString()) {
  for (const [id, run] of Object.entries(draft.ticketRuns || {})) {
    const old = previous.ticketRuns?.[id];
    const sameRun = Boolean(old && old.runId === run.runId);
    if (sameRun && old.status === run.status) continue;
    run.reliabilityHistory ||= { complete: !sameRun, transitions: [] };
    run.reliabilityHistory.transitions.push({ status: run.status, at });
  }
}

export function reliabilityReport(run, now = Date.now()) {
  const proof = projectProofMap(run);
  const criteria = proof.criteria.filter((item) => item.scope !== "step" && item.stepRequired !== false);
  const gate = proofEligibility(proof, { requiredOnly: true });
  const checksPassed = run.finalChecks?.status === "passed";
  const blockers = [...gate.blockingReasons.map((item) => ({ criterionId: item.criterionId, reason: item.message }))];
  if (proof.compatibility || !criteria.length) blockers.push({ reason: "No explicit final acceptance contract is available." });
  if (!checksPassed) blockers.push({ reason: "Final deterministic checks have not passed." });
  const review = run.reviews?.at(-1);
  if (!Array.isArray(review?.actionableFindings) || review.actionableFindings.length) blockers.push({ reason: "Final independent review is missing or has unresolved findings." });
  if (run.status !== "completed") blockers.push({ reason: "Delivery has not completed." });
  const transitions = run.reliabilityHistory?.transitions || [];
  const seconds = { execution: 0, decisionWait: 0, blocked: 0 };
  let decisionResumes = 0, recoveryResumes = 0;
  for (const [i, transition] of transitions.entries()) {
    const next = transitions[i + 1];
    const elapsed = Math.max(0, ((next ? Date.parse(next.at) : now) - Date.parse(transition.at)) / 1000);
    if (!terminal.has(transition.status) && Number.isFinite(elapsed)) {
      seconds[decisions.has(transition.status) ? "decisionWait" : stopped.has(transition.status) ? "blocked" : "execution"] += elapsed;
    }
    if (next && !decisions.has(next.status) && !stopped.has(next.status) && !terminal.has(next.status)) {
      if (decisions.has(transition.status)) decisionResumes++;
      if (stopped.has(transition.status)) recoveryResumes++;
    }
  }
  const steps = flattenSteps(run.plan || { nodes: [] });
  const repeatedFailures = steps.flatMap((step) => {
    const counts = new Map();
    for (const attempt of step.attempts || []) {
      const reason = attempt.error || attempt.lastError || attempt.verification?.error;
      if (typeof reason === "string" && reason.trim()) counts.set(reason.trim(), (counts.get(reason.trim()) || 0) + 1);
    }
    return [...counts].filter(([, count]) => count > 1).map(([reason, count]) => ({ stepId: step.id, reason, count }));
  });
  const retries = steps.reduce((sum, step) => sum + Math.max(0, (step.attempts?.length || 0) - 1), 0) + Math.max(0, (run.reviews?.length || 0) - 1);
  return {
    ready: blockers.length === 0,
    acceptance: { required: criteria.length, verified: criteria.filter((item) => item.current.status === "verified" && item.current.evidenceValidity === "valid").length, finalChecksPassed: checksPassed, blockers },
    timing: { coverage: run.reliabilityHistory?.complete ? "complete" : transitions.length ? "partial" : "unavailable", observedSince: transitions[0]?.at || null,
      seconds: transitions.length ? Object.fromEntries(Object.entries(seconds).map(([key, value]) => [key, Math.floor(value)])) : null },
    decisions: { plannedGateResumes: decisionResumes, recoveryResumes, attribution: "Status transitions; may be human or automatic." },
    retries, recordedRestarts: run.restartHistory?.length || 0, recordedSteers: run.steering?.records?.length || 0,
    firstPass: !run.reliabilityHistory?.complete || run.status !== "completed" ? null : blockers.length === 0 && retries === 0 && recoveryResumes === 0 && !(run.restartHistory?.length) && !(run.steering?.records?.length),
    repeatedFailures,
    independentAcceptance: "not_recorded",
    regressionAssessment: "not_recorded"
  };
}
