import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { compactRun } from "../src/inspection.js";
import { JsonStore } from "../src/store.js";

test("completed output is retained outside hot state, reloadable, and not archived repeatedly", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "history-output-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const file = join(root, "state-v3.json");
  const store = new JsonStore(file, root);
  await store.init();
  const output = "historical check output\n".repeat(10000);
  await store.update((draft) => {
    draft.ticketRuns.done = { ticket: { id: "done", identifier: "DONE" }, runId: "run", status: "completed", finalChecks: { status: "passed", output } };
    draft.ticketRuns.active = { ticket: { id: "active" }, runId: "active-run", status: "running", finalChecks: { output } };
  });
  const done = store.read((state) => state.ticketRuns.done);
  assert.ok(done.finalChecks.output.length < 4000);
  assert.equal(done.finalChecks.status, "passed");
  const artifact = done.artifacts.find((item) => item.kind === "historical-output");
  const entries = JSON.parse(await readFile(artifact.path, "utf8"));
  assert.deepEqual(entries, [{ pointer: ["finalChecks", "output"], content: output }]);
  assert.equal(store.read((state) => state.ticketRuns.active.finalChecks.output), output);
  await store.update((draft) => { draft.notice = "another update"; });
  assert.equal(store.read((state) => state.ticketRuns.done.artifacts.length), 1);
  const reloaded = await new JsonStore(file, root).init();
  assert.equal(reloaded.ticketRuns.done.artifacts[0].path, artifact.path);
  assert.ok(store.metrics.bytes > 0);
  assert.ok(store.metrics.serializeMs >= 0);
});

test("finished histories stay cold across unrelated updates and remain mutable transactionally", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "run-history-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const file = join(root, "state-v3.json");
  const store = new JsonStore(file, root);
  await store.init();
  const events = Array.from({ length: 500 }, (_, i) => ({ content: `${i}: ${"evidence ".repeat(100)}` }));
  await store.update((draft) => {
    draft.ticketRuns.done = { id: "done", runId: "run", status: "completed", restartHistory: events };
  });
  assert.ok(store.metrics.bytes < 20000);
  assert.equal(store.state.ticketRuns.done.restartHistory, undefined);
  const disk = JSON.parse(await readFile(file, "utf8"));
  const archive = join(root, "run-history", `${disk.ticketRuns.done.historyRef.digest}.json`);
  const body = await readFile(archive, "utf8");
  // A metadata-only read/update must not even open the cold file.
  await rm(archive);
  assert.equal(store.read((state) => state.ticketRuns.done.status), "completed");
  assert.equal(compactRun(store.read().ticketRuns.done).status, "completed");
  await store.update((draft) => { draft.notice = "metadata only"; });
  const { writeFile } = await import("node:fs/promises");
  await writeFile(archive, body);
  assert.deepEqual(store.read((state) => state.ticketRuns.done.restartHistory), events);
  await assert.rejects(store.update((draft) => {
    draft.ticketRuns.done.restartHistory[0].content = "must roll back";
    throw new Error("rollback");
  }), /rollback/);
  assert.equal(store.read((state) => state.ticketRuns.done.restartHistory[0].content), events[0].content);
  await store.update((draft) => { draft.ticketRuns.done.restartHistory[0].content = "amended"; });
  const reloaded = new JsonStore(file, root);
  await reloaded.init();
  assert.equal(reloaded.read((state) => state.ticketRuns.done.restartHistory[0].content), "amended");
  await reloaded.update((draft) => { draft.ticketRuns.done.status = "interrupted"; });
  assert.equal(reloaded.state.ticketRuns.done.historyRef, undefined);
  assert.equal(reloaded.state.ticketRuns.done.historySummary, undefined);
  assert.equal(reloaded.state.ticketRuns.done.restartHistory[0].content, "amended");
});

test("a missing history archive fails startup without replacing durable state", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "missing-history-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const file = join(root, "state-v3.json");
  const store = new JsonStore(file, root);
  await store.init();
  await store.update((draft) => {
    draft.ticketRuns.done = { id: "done", runId: "run", status: "completed", restartHistory: [{ reason: "preserve me" }] };
  });
  const original = await readFile(file, "utf8");
  const digest = JSON.parse(original).ticketRuns.done.historyRef.digest;
  await rm(join(root, "run-history", `${digest}.json`));
  await assert.rejects(new JsonStore(file, root).init(), /ENOENT/);
  assert.equal(await readFile(file, "utf8"), original);
});
