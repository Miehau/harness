import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, rm, symlink, realpath, chmod } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Runtime } from '../runner/runtime.js';
import { serve } from '../runner/server.js';
import { git, id, atomic } from '../runner/io.js';

class FakeHerdr {
  constructor() { this.agents = new Map(); this.starts = []; }
  async create(task, agent) { return { pane: agent.id, tab: agent.id, workspace: task.workspace ?? 'test-workspace' }; }
  async start(agent) { this.agents.set(agent.id, 'idle'); this.starts.push(agent.id); }
  async status(agent) { return this.agents.get(agent.id) ?? 'missing'; }
  async stop(agent) { this.agents.delete(agent.id); }
}
async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), 'runner-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const repo = join(root, 'repo'); await mkdir(join(repo, '.runner'), { recursive: true });
  await git(repo, 'init', '-b', 'main'); await git(repo, 'config', 'user.email', 'test@example.invalid'); await git(repo, 'config', 'user.name', 'Runner Test');
  await writeFile(join(repo, 'value.txt'), 'base\n');
  await writeFile(join(repo, '.runner', 'project.json'), JSON.stringify({ commands: { test: [process.execPath, '-e', "if(!require('fs').readFileSync('value.txt','utf8').trim())process.exit(1)"] }, verify: ['test'], maxWorkers: 2 }));
  await git(repo, 'add', '.'); await git(repo, 'commit', '-m', 'Fixture');
  const transport = new FakeHerdr(); const data = join(root, 'data'); const runtime = new Runtime(data, { transport }); await runtime.init(); runtime.url = 'http://127.0.0.1:1';
  const call = (identity, action, taskId, input = {}, requestId = id()) => runtime.execute(identity, { action, taskId, input, requestId });
  const task = await call('owner', 'submit', null, { repo, text: 'Implement an improvement', requestId: id() });
  await call('owner', 'start', task.id);
  const main = runtime.task(task.id).agents[0]; const who = a => ({ taskId: task.id, agentId: a.id });
  const artifact = async (name, content = name, actor = who(main)) => { await call(actor, 'write', task.id, { area: 'artifacts', path: name, content }); return name; };
  return { root, repo, data, runtime, transport, call, task, main, who, artifact };
}

test('fresh runner: worker question, restart, answer, report, integrate and verify', async t => {
  const f = await fixture(t); const { runtime, call, task, main, who, artifact, transport } = f;
  await artifact('assignment.md', 'Change value.txt to improved');
  const spawnId = id();
  const spawned = await call(who(main), 'spawn', task.id, { assignment: 'assignment.md', mode: 'write' }, spawnId);
  assert.deepEqual(await call(who(main), 'spawn', task.id, { assignment: 'assignment.md', mode: 'write' }, spawnId), spawned);
  assert.equal(transport.starts.length, 2);
  const worker = runtime.task(task.id).agents.find(a => a.id === spawned.workerId);
  assert.notEqual(worker.cwd, f.repo); assert.notEqual(worker.cwd, main.cwd);
  await artifact('question.md', 'Which wording?', who(worker));
  const question = await call(who(worker), 'ask', task.id, { artifact: 'question.md' });
  await assert.rejects(call(who(worker), 'write', task.id, { area: 'repo', path: 'value.txt', content: 'premature' }), /Waiting/);
  assert(runtime.poll(who(main)).messages.some(m => m.decisionId === question.decisionId));
  const restarted = new Runtime(f.data, { transport }); await restarted.init();
  assert.equal(restarted.task(task.id).decisions[0].id, question.decisionId);
  assert.equal(restarted.task(task.id).agents.find(a => a.id === worker.id).status, 'waiting');
  await artifact('answer.md', 'Use improved');
  await call(who(main), 'answer', task.id, { decisionId: question.decisionId, artifact: 'answer.md' });
  assert(runtime.poll(who(worker)).messages.some(m => m.kind === 'answer'));
  await call(who(worker), 'write', task.id, { area: 'repo', path: 'value.txt', content: 'improved\n' });
  await artifact('handoff.md', 'Updated value; verify after integration.', who(worker));
  await call(who(worker), 'report', task.id, { status: 'completed', artifact: 'handoff.md' });
  await assert.rejects(call(who(worker), 'write', task.id, { area: 'repo', path: 'value.txt', content: 'late' }), /Inactive/);
  await artifact('result.md', 'Completed candidate');
  await assert.rejects(call(who(main), 'report', task.id, { status: 'completed', artifact: 'result.md' }), /integrated/);
  await call(who(main), 'integrate', task.id, { workerId: worker.id });
  await assert.rejects(call(who(main), 'report', task.id, { status: 'completed', artifact: 'result.md' }), /verification/);
  const proof = await call(who(main), 'verify', task.id); assert.equal(proof.passed, true);
  await call(who(main), 'report', task.id, { status: 'completed', artifact: 'result.md' });
  assert.equal(runtime.task(task.id).status, 'completed');
  assert.equal(await readFile(join(f.repo, 'value.txt'), 'utf8'), 'base\n');
  assert.equal(await readFile(join(main.cwd, 'value.txt'), 'utf8'), 'improved\n');
});

test('ownership, shared contracts, path boundaries and exact user decisions', async t => {
  const { runtime, call, task, main, who, artifact, root } = await fixture(t);
  await artifact('assignment.md');
  const first = await call(who(main), 'spawn', task.id, { assignment: 'assignment.md', mode: 'write' });
  await assert.rejects(call(who(main), 'spawn', task.id, { assignment: 'assignment.md', mode: 'write' }), /contract/);
  const worker = runtime.task(task.id).agents.find(a => a.id === first.workerId);
  await assert.rejects(call(who(worker), 'spawn', task.id, { assignment: 'assignment.md', mode: 'explore' }), /Orchestrator/);
  await assert.rejects(call(who(main), 'write', task.id, { area: 'repo', path: 'value.txt', content: 'no' }), /cannot write/);
  await assert.rejects(call(who(worker), 'write', task.id, { area: 'repo', path: '../escape', content: 'no' }), /inside/);
  await symlink(root, join(worker.cwd, 'escape'));
  await assert.rejects(call(who(worker), 'write', task.id, { area: 'repo', path: 'escape/secret', content: 'no' }), /Symlink/);
  await artifact('user-question.md');
  const q = await call(who(main), 'ask', task.id, { artifact: 'user-question.md' });
  await artifact('answer.md', 'Yes', 'owner');
  await assert.rejects(call(who(worker), 'answer', task.id, { decisionId: q.decisionId, artifact: 'answer.md' }), /Orchestrator/);
  await call('owner', 'answer', task.id, { decisionId: q.decisionId, artifact: 'answer.md' });
  await artifact('different.md');
  await assert.rejects(call('owner', 'answer', task.id, { decisionId: q.decisionId, artifact: 'different.md' }), /differently/);
});

test('Herdr idle/done never completes a task, missing agents require explicit resume', async t => {
  const { runtime, transport, call, task, main } = await fixture(t);
  transport.agents.set(main.id, 'done'); await runtime.reconcile();
  assert.equal(runtime.task(task.id).status, 'running');
  transport.agents.delete(main.id); await runtime.reconcile();
  assert.equal(runtime.task(task.id).agents[0].status, 'failed');
  await call('owner', 'resume', task.id, { agentId: main.id });
  assert.equal(runtime.task(task.id).agents[0].session, main.session);
  assert.equal(transport.starts.length, 2);
});

test('HTTP owner and worker scopes survive server restart', async t => {
  const root = await mkdtemp(join(tmpdir(), 'runner-http-')); const data = join(root, 'http'); const transport = new FakeHerdr();
  let server = await serve(data, { transport });
  t.after(async () => { await server.close(); await rm(root, { recursive: true, force: true }); });
  const url = server.runtime.url; const token = server.descriptor.token;
  assert.equal((await fetch(url + '/tasks')).status, 401);
  assert.equal((await fetch(url + '/tasks', { headers: { authorization: `Bearer ${token}`, origin: 'https://evil.invalid' } })).status, 403);
  assert.equal((await fetch(url + '/tasks', { headers: { authorization: `Bearer ${token}` } })).status, 200);
  await assert.rejects(serve(data, { transport }), /already owns/);
  await server.close(); server = await serve(data, { transport });
  assert.equal(server.runtime.url, url); assert.equal(server.descriptor.token, token);
});

test('submission is idempotent and workflow snapshot survives repo edits', async t => {
  const { runtime, call, repo, task } = await fixture(t);
  const requestId = id(); const input = { repo, text: 'A queued task', requestId };
  const submitted = await call('owner', 'submit', null, input);
  assert.equal((await call('owner', 'submit', null, input)).id, submitted.id);
  await assert.rejects(call('owner', 'submit', null, { ...input, text: 'Different' }), /different/);
  await assert.rejects(call('owner', 'start', submitted.id), /owns this repository/);
  await writeFile(join(repo, '.runner', 'workflow.md'), 'changed');
  const snapshot = await readFile(join(runtime.dir(task), 'artifacts', 'workflow.md'), 'utf8');
  assert.match(snapshot, /Main agent workflow/);
});

test('parallel writing workers share a contract and integrate independently', async t => {
  const { runtime, call, task, main, who, artifact } = await fixture(t);
  await artifact('contract.md', 'API: GET /message returns {text:string}; FE owns ui.txt, BE owns api.txt');
  await call(who(main), 'contract', task.id, { artifact: 'contract.md' });
  await artifact('fe.md'); await artifact('be.md');
  const workers = [];
  for (const assignment of ['fe.md', 'be.md']) {
    const spawn = await call(who(main), 'spawn', task.id, { assignment, mode: 'write', contract: 'contract.md' });
    workers.push(runtime.task(task.id).agents.find(a => a.id === spawn.workerId));
  }
  await assert.rejects(call(who(main), 'spawn', task.id, { assignment: 'fe.md', mode: 'explore' }), /capacity/);
  await artifact('revised.md');
  await assert.rejects(call(who(main), 'contract', task.id, { artifact: 'revised.md' }), /Pause/);
  for (const [i, worker] of workers.entries()) {
    await call(who(worker), 'write', task.id, { area: 'repo', path: i ? 'api.txt' : 'ui.txt', content: 'contract implementation' });
    await artifact(`handoff-${i}.md`, 'Implemented', who(worker));
    await call(who(worker), 'report', task.id, { status: 'completed', artifact: `handoff-${i}.md` });
  }
  for (const worker of workers) await call(who(main), 'integrate', task.id, { workerId: worker.id });
  assert.equal((await call(who(main), 'verify', task.id)).passed, true);
  assert.equal(await readFile(join(main.cwd, 'ui.txt'), 'utf8'), 'contract implementation');
  assert.equal(await readFile(join(main.cwd, 'api.txt'), 'utf8'), 'contract implementation');
});

test('shared contract revision pauses and resumes exact workers', async t => {
  const { runtime, call, task, main, who, artifact } = await fixture(t);
  await artifact('assignment.md'); await artifact('contract.md');
  await call(who(main), 'contract', task.id, { artifact: 'contract.md' });
  const spawned = await call(who(main), 'spawn', task.id, { assignment: 'assignment.md', mode: 'write', contract: 'contract.md' });
  const worker = runtime.task(task.id).agents.find(a => a.id === spawned.workerId);
  await artifact('pause.md', 'Shared response field changes');
  const q = await call(who(main), 'pause', task.id, { workerId: worker.id, artifact: 'pause.md' });
  await artifact('contract-v2.md'); await call(who(main), 'contract', task.id, { artifact: 'contract-v2.md' });
  await call(who(main), 'answer', task.id, { decisionId: q.decisionId, artifact: 'contract-v2.md' });
  assert.equal(runtime.task(task.id).agents.find(a => a.id === worker.id).contract, 'contract-v2.md');
  assert(runtime.poll(who(worker)).messages.some(m => m.kind === 'contract' && m.artifact === 'contract-v2.md'));
});

test('pending request receipts never repeat an uncertain spawn after restart', async t => {
  const { runtime, task, main, who, data, transport } = await fixture(t);
  const current = runtime.task(task.id); const requestId = id();
  const { createHash } = await import('node:crypto'); const body = { assignment: 'unknown.md', mode: 'write' };
  const fingerprint = createHash('sha256').update(JSON.stringify({ action: 'spawn', body })).digest('hex');
  current.receipts[`${main.id}:${requestId}`] = { fingerprint, action: 'spawn', status: 'pending' }; await runtime.save(current);
  const restarted = new Runtime(data, { transport }); await restarted.init();
  await assert.rejects(restarted.execute(who(main), { action: 'spawn', input: body, requestId }), /uncertain/);
  assert.equal(transport.starts.length, 1);
});

test('verification failure and changed integration invalidate completion', async t => {
  const { runtime, call, task, main, who, artifact } = await fixture(t);
  await artifact('result.md');
  const current = runtime.task(task.id); current.config.commands.test = [process.execPath, '-e', 'console.log("failure evidence");process.exit(1)']; await runtime.save(current);
  const proof = await call(who(main), 'verify', task.id); assert.equal(proof.passed, false);
  await assert.rejects(call(who(main), 'report', task.id, { status: 'completed', artifact: 'result.md' }), /verification/);
  const evidence = JSON.parse(await readFile(join(runtime.dir(task), 'artifacts', proof.artifact), 'utf8'));
  const check = JSON.parse(await readFile(join(runtime.dir(task), 'artifacts', evidence.checks[0].artifact), 'utf8'));
  assert.match(await readFile(join(runtime.dir(task), 'artifacts', check.output), 'utf8'), /failure evidence/);
});

test('worker time budget applies even with a healthy heartbeat', async t => {
  const { runtime, task, main } = await fixture(t);
  const current = runtime.task(task.id); current.agents[0].startedAt = new Date(0).toISOString(); await runtime.save(current);
  runtime.heartbeats.set(main.id, Date.now()); await runtime.reconcile();
  assert.equal(runtime.task(task.id).agents[0].status, 'failed');
  assert.match(runtime.task(task.id).agents[0].error, /budget/);
});

test('webhook uncertainty is recorded without automatic duplicate delivery', async t => {
  const { notify } = await import('../runner/notifications.js');
  const { runtime, task } = await fixture(t);
  await atomic(join(runtime.root, 'supervisor.json'), { webhook: { url: 'https://receiver.example.invalid/events' } });
  const current = runtime.task(task.id); runtime.event(current, 'decision', { decisionId: id(), artifact: 'question.md' }); await runtime.save(current);
  let calls = 0;
  const transport = async () => { calls++; throw new Error('network uncertain'); };
  await notify(runtime, transport); await notify(runtime, transport);
  assert.equal(calls, 1);
  const receipts = JSON.parse(await readFile(join(runtime.root, 'notifications.json'), 'utf8'));
  assert.equal(Object.values(receipts)[0].status, 'unknown');
});

test('one runtime operates independently in two repositories', async t => {
  const a = await fixture(t); const b = await fixture(t);
  const task = await a.call('owner', 'submit', null, { repo: b.repo, text: 'Another repo', requestId: id() });
  await a.call('owner', 'start', task.id);
  assert.equal(a.runtime.task(task.id).status, 'running');
  assert.equal(a.runtime.task(a.task.id).status, 'running');
  assert.equal(a.runtime.task(task.id).repo, await realpath(b.repo));
});

test('cancellation interrupts named commands instead of waiting for their timeout', async t => {
  const f = await fixture(t); const task = f.runtime.task(f.task.id);
  task.config.commands.long = [process.execPath, '-e', 'setInterval(()=>{},1000)']; await f.runtime.save(task);
  const command = f.call(f.who(f.main), 'command', task.id, { name: 'long' });
  const { setTimeout: sleep } = await import('node:timers/promises');
  for (let i = 0; !f.runtime.processes.size && i < 100; i++) await sleep(10);
  assert.equal(f.runtime.processes.size, 1);
  const cancelled = f.call('owner', 'cancel', task.id);
  assert.equal((await command).passed, false);
  assert.equal((await cancelled).status, 'cancelled');
});

test('Pi extension delivers references, acknowledges turns, and surfaces model failure', async t => {
  let cleanup;
  const f = await fixture({ after(fn) { cleanup = fn; } });
  const server = await serve(f.data, { transport: f.transport });
  const prior = { url: process.env.RUNNER_URL, token: process.env.RUNNER_TOKEN };
  process.env.RUNNER_URL = server.runtime.url; process.env.RUNNER_TOKEN = f.main.token;
  const handlers = new Map(), tools = new Map(), messages = [];
  const pi = { on: (name, fn) => handlers.set(name, fn), registerTool: tool => tools.set(tool.name, tool), setActiveTools() {}, sendMessage: message => messages.push(message) };
  const { default: extension } = await import('../runner/pi-extension.js'); extension(pi);
  t.after(async () => {
    handlers.get('session_shutdown')(); await server.close(); await cleanup();
    if (prior.url === undefined) delete process.env.RUNNER_URL; else process.env.RUNNER_URL = prior.url;
    if (prior.token === undefined) delete process.env.RUNNER_TOKEN; else process.env.RUNNER_TOKEN = prior.token;
  });
  await handlers.get('session_start')({}, { isIdle: () => true, shutdown() {}, ui: { setStatus() {} } });
  const { setTimeout: sleep } = await import('node:timers/promises');
  for (let i = 0; !messages.length && i < 100; i++) await sleep(10);
  assert.equal(messages.length, 1); assert.match(messages[0].content, /brief.md/);
  await handlers.get('agent_end')({ messages: [messages[0], { role: 'assistant', stopReason: 'stop' }] });
  assert(server.runtime.task(f.task.id).agents[0].inbox.every(m => m.acknowledgedAt));
  const report = tools.get('runner_action');
  await tools.get('runner_write').execute(id(), { area: 'artifacts', path: 'ask.md', content: 'Need user decision' });
  const q = await report.execute(id(), { action: 'ask', input: { artifact: 'ask.md' } }); assert.equal(q.terminate, true);
  await server.runtime.execute('owner', { action: 'write', taskId: f.task.id, requestId: id(), input: { area: 'artifacts', path: 'answer.md', content: 'Proceed' } });
  await server.runtime.execute('owner', { action: 'answer', taskId: f.task.id, requestId: id(), input: { decisionId: q.details.decisionId, artifact: 'answer.md' } });
  for (let i = 0; messages.length < 2 && i < 250; i++) await sleep(10);
  assert.equal(messages.length, 2); assert.match(messages[1].content, /answer.md/);
  await handlers.get('agent_end')({ messages: [messages[1], { role: 'assistant', stopReason: 'error', errorMessage: 'Provider unavailable' }] });
  assert.equal(server.runtime.task(f.task.id).agents[0].status, 'failed');
  assert.equal(server.runtime.task(f.task.id).status, 'running');
});

test('resume wakes acknowledged sessions and preserves unanswered user decisions', async t => {
  const f = await fixture(t);
  const inbox = f.runtime.poll(f.who(f.main)).messages;
  await f.call(f.who(f.main), 'ack', f.task.id, { ids: inbox.map(m => m.id) });
  f.transport.agents.delete(f.main.id); await f.runtime.reconcile();
  await f.call('owner', 'resume', f.task.id, { agentId: f.main.id });
  assert(f.runtime.poll(f.who(f.main)).messages.some(m => m.kind === 'resume'));
  await f.artifact('question.md'); const q = await f.call(f.who(f.main), 'ask', f.task.id, { artifact: 'question.md' });
  f.transport.agents.delete(f.main.id); f.runtime.heartbeats.clear(); await f.runtime.reconcile();
  await f.call('owner', 'resume', f.task.id, { agentId: f.main.id });
  assert.equal(f.runtime.poll(f.who(f.main)).status, 'waiting');
  assert.equal(f.runtime.task(f.task.id).decisions.find(d => d.id === q.decisionId).answer, undefined);
});

test('interrupted integration can recover without replaying an applied commit', async t => {
  const f = await fixture(t); await f.artifact('assignment.md');
  const spawned = await f.call(f.who(f.main), 'spawn', f.task.id, { assignment: 'assignment.md', mode: 'write' });
  const worker = f.runtime.task(f.task.id).agents.find(a => a.id === spawned.workerId);
  await f.call(f.who(worker), 'write', f.task.id, { area: 'repo', path: 'extra.txt', content: 'change' });
  await f.artifact('handoff.md', 'Done', f.who(worker));
  await f.call(f.who(worker), 'report', f.task.id, { status: 'completed', artifact: 'handoff.md' });
  const current = f.runtime.task(f.task.id); const saved = current.agents.find(a => a.id === worker.id);
  current.operation = { kind: 'integrate', workerId: worker.id, before: await git(f.main.cwd, 'rev-parse', 'HEAD'), commit: saved.commit };
  await f.runtime.save(current); await git(f.main.cwd, 'cherry-pick', saved.commit);
  await assert.rejects(f.call('owner', 'recover', f.task.id, { outcome: 'aborted' }), /differs/);
  await f.call('owner', 'recover', f.task.id, { outcome: 'applied' });
  const head = await git(f.main.cwd, 'rev-parse', 'HEAD');
  assert.equal((await f.call(f.who(f.main), 'integrate', f.task.id, { workerId: worker.id })).commit, head);
  assert.equal(await git(f.main.cwd, 'rev-parse', 'HEAD'), head);
});

test('malformed connection credentials fail closed and release the startup lock', async t => {
  const root = await mkdtemp(join(tmpdir(), 'runner-invalid-')); t.after(() => rm(root, { recursive: true, force: true }));
  await atomic(join(root, 'connection.json'), {});
  await assert.rejects(serve(root, { transport: new FakeHerdr() }), /Invalid connection/);
  await assert.rejects(readFile(join(root, 'daemon.lock')), /ENOENT/);
});


test('Herdr transport errors never expose launch credentials', async t => {
  const root = await mkdtemp(join(tmpdir(), 'runner-herdr-error-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const binary = join(root, 'herdr');
  await writeFile(binary, `#!${process.execPath}\nprocess.stderr.write('transport unavailable');process.exit(1);\n`); await chmod(binary, 0o700);
  const previous = process.env.PATH; process.env.PATH = root;
  try {
    const { Herdr } = await import('../runner/herdr.js');
    await assert.rejects(new Herdr().call('tab', 'create', '--env', 'RUNNER_TOKEN=private-secret'), error => !error.message.includes('private-secret') && error.message.includes('Herdr'));
  } finally { process.env.PATH = previous; }
});
