import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { artifactsForStage, cleanupInspectorModel, eventGroups, eventTimeline, executionGraph, finalReview, fleetLane, fleetTicketView, formatOutput, freeTextTicket, inspectionResourceLabel, inspectionSelection, inspectionSummary, inspectionTransitionAnnouncement, parseDiff, preferredStageId, preferredStepId, proofMapView, recentActivity, restartOptions, restoreInspectionSelection, reviewNotesForRows, runHeartbeat, runMetrics, stageDetailModel, verificationProgress, stageMilestones, steeringLifecycle, steeringTarget, stepInspectorSummary } from "../public/ui-model.js";


test("resolves canonical attempt selection without replacing a retained choice", () => {
  const projection = {
    focus: { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:two" },
    stages: [{ id: "stage:implement" }],
    workers: [{ id: "worker:build", stepId: "build", stageId: "stage:implement" }],
    attempts: [
      { id: "attempt:build:one", workerId: "worker:build", stageId: "stage:implement", status: "failed", latestAction: "Tests failed", evidence: { state: "incomplete" }, blocker: { type: "repository-check", summary: "Tests failed" } },
      { id: "attempt:build:two", workerId: "worker:build", stageId: "stage:implement", status: "verified", latestAction: "Checks passed", evidence: { state: "complete" } }
    ]
  };
  assert.deepEqual(inspectionSelection(projection, { attemptId: "attempt:build:one" }), { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:one" });
  assert.deepEqual(inspectionSelection(projection), { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:two" });
  projection.workers[0].attemptIds = ["attempt:build:one", "attempt:build:two"];
  projection.workers[0].nextAction = { kind: "review", label: "Review latest worker result" };
  assert.deepEqual(inspectionSummary({ worker: projection.workers[0], attempt: projection.attempts[0] }), {
    status: "failed", latestAction: "Tests failed", blocker: { type: "repository-check", summary: "Tests failed" }, evidence: { state: "incomplete" }, nextAction: { kind: "none", label: "No action available" }
  });
  assert.deepEqual(inspectionSummary({ worker: projection.workers[0], attempt: projection.attempts[1] }).nextAction, { kind: "review", label: "Review latest worker result" });
  assert.equal(inspectionResourceLabel({ state: "not_retained" }), "Not retained");
  assert.equal(inspectionResourceLabel({ state: "truncated" }), "Truncated");
});

test("restores deliberate inspection selection and announces only meaningful attempt changes", () => {
  const previous = {
    focus: { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:one", reason: "active" },
    stages: [{ id: "stage:implement" }], workers: [{ id: "worker:build", stageId: "stage:implement", attemptIds: ["attempt:build:one"] }],
    attempts: [{ id: "attempt:build:one", workerId: "worker:build", stageId: "stage:implement", lifecycle: "active" }]
  };
  const completed = {
    ...previous,
    attempts: [{ ...previous.attempts[0], lifecycle: "completed" }]
  };
  assert.deepEqual(restoreInspectionSelection(completed, { attemptId: "attempt:build:one" }), {
    selection: { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:one" }, preserved: true, disappeared: false, reason: "preserved"
  });
  assert.match(inspectionTransitionAnnouncement(previous, completed, { attemptId: "attempt:build:one" }), /completed.*Retained history/i);

  const corrected = {
    ...completed,
    focus: { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:two", reason: "active" },
    workers: [{ ...completed.workers[0], attemptIds: ["attempt:build:one", "attempt:build:two"] }],
    attempts: [...completed.attempts, { id: "attempt:build:two", workerId: "worker:build", stageId: "stage:implement", lifecycle: "active" }]
  };
  assert.match(inspectionTransitionAnnouncement(completed, corrected, { workerId: "worker:build" }), /correction attempt started/i);
  assert.deepEqual(restoreInspectionSelection(corrected, { workerId: "worker:build" }), {
    selection: { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:two" }, preserved: true, disappeared: false, reason: "preserved"
  });
  assert.deepEqual(restoreInspectionSelection(corrected, { attemptId: "attempt:missing" }), {
    selection: { stageId: "stage:implement", workerId: "worker:build", attemptId: "attempt:build:two" }, preserved: false, disappeared: true, reason: "active"
  });
});

test("summarizes subscription usage without imposing a budget", () => {
  const run = {
    createdAt: "2026-08-24T18:00:00.000Z", completedAt: "2026-08-24T18:02:00.000Z", reviews: [{}, {}],
    plan: { nodes: [{ type: "step", attempts: [
      { events: [{ type: "usage", input: 100, output: 20, cacheRead: 50, cacheWrite: 5 }, { type: "tool_start" }] },
      { events: [{ type: "usage", input: 40, output: 10 }, { type: "tool_start" }] }
    ] }] }, stages: []
  };
  assert.deepEqual(runMetrics(run), { modelCalls: 2, cost: { usd: null, currency: "USD", state: "unavailable", reportedCalls: 0 }, input: 140, output: 30, cacheRead: 50, cacheWrite: 5, calls: 2, usageState: "partial", correctionRounds: 2, durationSeconds: 120 });
});

test("builds graph levels and readable diff rows", () => {
  const graph = executionGraph({ nodes: [
    { id: "research", type: "group", children: [{ id: "a", dependsOn: [] }, { id: "b", dependsOn: [] }] },
    { id: "build", type: "step", dependsOn: ["research"] },
    { id: "verify", type: "step", dependsOn: ["build"] }
  ] });
  assert.deepEqual(graph.columns.map((column) => column.map((unit) => unit.id)), [["research"], ["build"], ["verify"]]);
  assert.deepEqual(graph.edges, [{ from: "research", to: "build" }, { from: "build", to: "verify" }]);

  const diff = parseDiff("diff --git a/a.ts b/a.ts\nindex 123..456 100644\n--- a/a.ts\n+++ b/a.ts\n@@ -1,2 +1,2 @@\n-old\n+new\n same");
  assert.equal(diff.files[0].name, "a.ts");
  assert.deepEqual([diff.additions, diff.deletions], [1, 1]);
  assert.equal(diff.files[0].hunks.length, 1);
  assert.equal(diff.files[0].hunks[0].context, "");
  assert.deepEqual(diff.files[0].rows.filter((row) => row.kind !== "hunk").map((row) => [row.kind, row.old, row.new]), [
    ["delete", 1, ""], ["add", "", 1], ["context", 2, 2]
  ]);
});

test("new-file metadata does not hide the first real diff hunk", () => {
  const diff = parseDiff("diff --git a/new.ts b/new.ts\nnew file mode 100644\nindex 0000000..1234567\n--- /dev/null\n+++ b/new.ts\n@@ -0,0 +1,2 @@\n+one\n+two");
  assert.equal(diff.files[0].hunks.length, 1);
  assert.equal(diff.files[0].hunks[0].header, "@@ -0,0 +1,2 @@");
  assert.deepEqual(diff.files[0].hunks[0].rows.map((row) => row.text), ["one", "two"]);
});

test("review notes attach only to their current old or new diff lines", () => {
  const rows = parseDiff("diff --git a/a.ts b/a.ts\n--- a/a.ts\n+++ b/a.ts\n@@ -3 +3 @@\n-old\n+new").files[0].hunks[0].rows;
  const notes = [
    { id: "left", path: "a.ts", side: "LEFT", startLine: 3, endLine: 3, status: "current" },
    { id: "right", path: "a.ts", side: "RIGHT", startLine: 3, endLine: 3, status: "current" },
    { id: "stale", path: "a.ts", side: "RIGHT", startLine: 3, endLine: 3, status: "stale" },
    { id: "other", path: "b.ts", side: "RIGHT", startLine: 3, endLine: 3, status: "current" }
  ];
  assert.deepEqual(reviewNotesForRows(notes, "a.ts", rows).map((note) => note.id), ["left", "right"]);
});

test("live run heartbeat distinguishes active, stale, and permission-risk states", () => {
  assert.equal(runHeartbeat({}), null);
  const startedAt = "2026-08-24T18:00:00.000Z";
  const now = Date.parse("2026-08-24T18:01:00.000Z");
  assert.equal(runHeartbeat({ startedAt, lastEventAt: "2026-08-24T18:00:55.000Z", lastEvent: "Using bash" }, {}, now).state, "active");
  assert.equal(runHeartbeat({ startedAt, lastEvent: "Using bash" }, {}, now).state, "stale");
  assert.match(runHeartbeat({ startedAt, warning: true }, {}, now).note, /permission/);
  assert.equal(runHeartbeat({ startedAt, lastEvent: "Starting", activity: { lastEventAt: "2026-08-24T18:00:55.000Z", lastEvent: "Running repository checks" } }, {}, now).label, "Running repository checks");
});

test("tool activity preserves event order and pairs details", () => {
  const timeline = eventTimeline([
    { type: "tool_start", callId: "1", tool: "bash", args: "{\"command\":\"npm test\"}", at: "1" },
    { type: "tool_end", callId: "1", tool: "bash", result: "32 tests pass", at: "2" },
    { type: "tool_start", callId: "2", tool: "read", args: "{\"path\":\"src/app.js\"}", at: "3" },
    { type: "tool_end", callId: "2", tool: "read", result: "source", at: "4" }
  ]);
  assert.deepEqual(timeline.map((item) => item.tool), ["bash", "read"]);
  assert.equal(timeline[0].title, "Command · npm test");
  assert.equal(timeline[0].key, "1");
  assert.equal(timeline[0].result, "32 tests pass");
  assert.equal(eventTimeline([{ type: "tool_start", tool: "edit", at: "1" }, { type: "tool_end", tool: "edit", at: "2" }])[0].hasDetails, false);
});

test("cumulative tool updates replace earlier snapshots", () => {
  const [item] = eventTimeline([
    { type: "tool_start", callId: "1", tool: "read", at: "1" },
    { type: "tool_update", callId: "1", tool: "read", detail: "partial", replace: true, at: "2" },
    { type: "tool_update", callId: "1", tool: "read", detail: "complete", replace: true, at: "3" }
  ]);
  assert.equal(item.output, "complete");
});

test("recent activity puts the latest worker actions first", () => {
  const events = ["read", "edit", "test"].flatMap((tool, index) => [
    { type: "tool_start", callId: String(index), tool, at: String(index) },
    { type: "tool_end", callId: String(index), tool, result: "done", at: String(index) }
  ]);
  assert.deepEqual(recentActivity(events, 2).map((item) => item.tool), ["test", "edit"]);
});

test("activity gives persisted reasoning and worker reports meaningful titles and details", () => {
  const timeline = eventTimeline([
    { type: "reasoning_summary", detail: "**Mapped** task lifecycle invariants", at: "1" },
    { type: "reasoning_summary", detail: "Checked automation ownership", at: "2" },
    { type: "tool_start", callId: "report", tool: "worker_report", args: '{"status":"completed","summary":"Derived domain architecture","artifact":"# Architecture"}', at: "3" },
    { type: "tool_end", callId: "report", tool: "worker_report", result: "Reported completed", at: "4" }
  ]);
  assert.deepEqual(timeline.map((item) => item.title), [
    "Reasoning · Mapped task lifecycle invariants",
    "Reasoning · Checked automation ownership",
    "Worker report · completed — Derived domain architecture"
  ]);
  assert.equal(timeline[2].hasDetails, true);
});

test("workflow stage activity uses its recorded title and status", () => {
  const [item] = eventTimeline([
    { type: "tool_start", callId: "stage", tool: "workflow_stage", args: '{"id":"shape","title":"Execution plan shaping","status":"active"}', at: "1" },
    { type: "tool_end", callId: "stage", tool: "workflow_stage", result: "Workflow stage shape is active", at: "2" }
  ]);
  assert.equal(item.title, "Execution plan shaping");
  assert.equal(item.status, "active");
});

test("activity groups tool calls under the latest reasoning focus", () => {
  const groups = eventGroups([
    { type: "reasoning_summary", detail: "Inspect the current UI", at: "2026-08-25T10:00:00.000Z" },
    { type: "tool_start", callId: "read", tool: "read", args: '{"path":"public/app.js"}', at: "2026-08-25T10:00:01.000Z" },
    { type: "tool_end", callId: "read", tool: "read", result: "source", at: "2026-08-25T10:00:03.000Z" },
    { type: "reasoning_summary", detail: "Verify the focused redesign", at: "2026-08-25T10:00:04.000Z" },
    { type: "tool_start", callId: "test", tool: "bash", args: '{"command":"npm test"}', at: "2026-08-25T10:00:05.000Z" }
  ]);
  assert.deepEqual(groups.map((group) => [group.title, group.items.map((item) => item.key)]), [
    ["Inspect the current UI", ["read"]],
    ["Verify the focused redesign", ["test"]]
  ]);
  assert.equal(groups[1].items[0].status, "running");
});

test("activity uses persisted group labels when an agent run is saved", () => {
  const groups = eventGroups([], [{
    key: "group:explore", title: "Explore repository", note: "Find the smallest relevant slice.",
    at: "2026-09-02T10:00:00.000Z", endedAt: "2026-09-02T10:00:02.000Z", status: "complete",
    events: [
      { type: "tool_start", tool: "read", callId: "read", args: '{"path":"src/app.js"}', at: "2026-09-02T10:00:00.000Z" },
      { type: "tool_end", tool: "read", callId: "read", result: "source", at: "2026-09-02T10:00:02.000Z" }
    ]
  }]);
  assert.deepEqual(groups.map((group) => [group.title, group.status, group.items[0].title]), [["Explore repository", "complete", "Read · src/app.js"]]);
});

test("activity hides empty generic lifecycle groups but keeps named phases", () => {
  const groups = eventGroups([], [{
    key: "lifecycle", title: "Agent activity", status: "complete", events: [
      { type: "agent_start", at: "2026-09-02T10:00:00.000Z" },
      { type: "usage", input: 20, output: 4, at: "2026-09-02T10:00:01.000Z" }
    ]
  }, {
    key: "checks", title: "Running repository checks", status: "running", events: [
      { type: "phase", label: "Running repository checks", at: "2026-09-02T10:00:02.000Z" }
    ]
  }]);
  assert.deepEqual(groups.map((group) => [group.title, group.status, group.items.length]), [["Running repository checks", "running", 0]]);
  assert.match(groups[0].note, /configured checks before review/);
});

test("stage activity identifies concurrent reviewers", () => {
  const timeline = eventTimeline([
    { type: "thinking", actor: "requirements", label: "Model is reasoning", at: "1" },
    { type: "tool_start", actor: "verification", callId: "read", tool: "read", args: '{"path":"test/app.test.js"}', at: "2" }
  ]);
  assert.deepEqual(timeline.map((item) => item.title), ["Reasoning · requirements · Model is reasoning", "verification · Read · test/app.test.js"]);
});

test("review stage becomes a findings-and-fixes timeline", () => {
  const milestones = stageMilestones({ reviews: [{
    round: 1, createdAt: "2026-08-25T10:01:00.000Z",
    actionableFindings: [{ severity: "blocking", claim: "Completion is not persisted", suggestedFix: "Save the state" }],
    fix: { report: { summary: "Persisted completion" }, diff: { stat: "1 file changed" }, artifact: { createdAt: "2026-08-25T10:02:00.000Z" } }
  }] }, { id: "verify", status: "active", updatedAt: "2026-08-25T10:03:00.000Z", activity: { startedAt: "2026-08-25T10:00:00.000Z" } });
  assert.deepEqual(milestones.map((item) => item.title), ["Agent review started.", "Review round 1 found issues.", "Focused fixes completed.", "Review round 2 started."]);
  assert.match(milestones[1].detail, /Completion is not persisted/);
  assert.match(milestones[2].detail, /Persisted completion/);
});

test("a clean review does not invent another round while final proof is being prepared", () => {
  const stage = { id: "verify", status: "active" };
  const run = { reviews: [{ round: 4, actionableFindings: [] }] };
  const items = stageMilestones(run, stage);
  assert.equal(items[0].title, "Review round 4 passed.");
  assert.equal(items.at(-1).title, "Preparing final proof.");
  run.pendingReviewAttempt = { round: 5 };
  assert.equal(stageMilestones(run, stage).at(-1).title, "Review round 5 started.");
});

test("review stage names an active fixer and repeats the issues being corrected", () => {
  const stage = { id: "verify", status: "active", updatedAt: "2026-09-03T10:00:00.000Z" };
  const items = stageMilestones({ status: "fixing", reviews: [{ createdAt: stage.updatedAt, actionableFindings: [{ severity: "high", claim: "Scope expansion bypasses the approved plan" }] }] }, stage);
  assert.equal(items.at(-1).title, "Focused correction in progress.");
  assert.match(items.at(-1).detail, /Scope expansion bypasses the approved plan/);
});

test("handoff timeline exposes merge queue, conflict resolution, verification, and integration", () => {
  const milestones = stageMilestones({
    merge: {
      status: "integrated", queuedAt: "2026-08-25T10:00:00.000Z", startedAt: "2026-08-25T10:01:00.000Z",
      sourceCwd: "/repo", branch: "codex/ticket", conflicts: ["src/app.js"], resolverStartedAt: "2026-08-25T10:02:00.000Z",
      resolverCompletedAt: "2026-08-25T10:03:00.000Z", resolutionArtifact: { content: "Combined /Users/operator/private/repo state transitions." },
      verifiedAt: "2026-08-25T10:04:00.000Z", checks: { status: "passed", summary: "npm test passed in /Users/operator/private/repo." }
    },
    integration: { sourceCwd: "/repo", commit: "abc123", integratedAt: "2026-08-25T10:05:00.000Z" }, artifacts: []
  }, { id: "handoff", status: "completed" });
  assert.deepEqual(milestones.map((item) => item.title), [
    "Added to merge queue.", "Automated merge started.", "Merge conflicts found.",
    "Conflict-resolution agent completed.", "Merged result verified.", "Changes integrated into the working directory."
  ]);
  const renderedMilestones = milestones.map((item) => item.detail).join("\n");
  assert.equal(renderedMilestones.includes("/repo"), false);
  assert.match(milestones[0].detail, /Target repository selected/);
  assert.match(milestones.at(-1).detail, /Commit: `abc123`/);
});

test("handoff timeline lists captured visual evidence as proof without inventing shots", () => {
  const shots = [
    { kind: "visual-evidence", name: "desktop.png", stageId: "verify", createdAt: "2026-08-25T10:00:30.000Z" },
    { kind: "visual-evidence", name: "mobile.png", stageId: "verify", createdAt: "2026-08-25T10:00:31.000Z" }
  ];
  const withShots = stageMilestones({ artifacts: shots, integration: { sourceCwd: "/repo", commit: "abc", integratedAt: "2026-08-25T10:05:00.000Z" } }, { id: "handoff", status: "completed" });
  assert.equal(withShots[0].title, "Visual evidence attached as proof.");
  assert.equal(withShots[0].status, "2 shots");
  assert.match(withShots[0].detail, /desktop\.png/);
  assert.match(withShots[0].detail, /mobile\.png/);
  const withoutShots = stageMilestones({ artifacts: [{ kind: "handoff", name: "handoff.md" }], integration: { sourceCwd: "/repo", commit: "abc", integratedAt: "t" } }, { id: "handoff" });
  assert.equal(withoutShots.some((item) => /visual evidence/i.test(item.title)), false);
});

test("final review keeps supported visual proof and its final check summary", () => {
  const review = finalReview({
    artifacts: [{ kind: "visual-evidence", name: "desktop.png" }, { kind: "visual-evidence", name: "walkthrough.mp4" }, { kind: "visual-evidence", name: "notes.txt" }],
    reviews: [{ reviews: [
      { role: "deterministic", summary: "passed", checks: { status: "passed", summary: "node scripts/test.mjs" } },
      { role: "integration", summary: "No issues found" }
    ] }]
  });
  assert.deepEqual(review.proof.map((item) => item.media), ["image", "video"]);
  assert.deepEqual(review.checks, { status: "passed", summary: "node scripts/test.mjs", command: undefined });
  assert.deepEqual(review.reviews, [{ role: "integration", summary: "No issues found" }]);
});

test("approved proof survives delivery and completion without mixing earlier captures", () => {
  for (const status of ["resolving_conflicts", "completed"]) {
    const review = finalReview({ id: "ticket", runId: "run", status, checkpoint: null,
      finalEvidenceArtifactIds: ["approved"],
      artifacts: [{ id: "old", kind: "visual-evidence", name: "old.png" }, { id: "approved", kind: "visual-evidence", name: "desktop.png" }]
    });
    assert.deepEqual(review.proof.map(item => item.id), ["approved"]);
    assert.equal(review.proof[0].mediaUrl, "/api/tickets/ticket/runs/run/artifacts/approved/media");
  }
});

test("proof presentation preserves ordered history and makes typed evidence actionable", () => {
  const run = {
    id: "ticket/a", proofMap: {
      compatibility: false, approvedAt: "2026-09-10T10:00:00.000Z", criteria: [
        { id: "one", stepId: "build", stepTitle: "Build", index: 0, text: "Works", current: { status: "verified", evidenceValidity: "valid", evidence: [{ type: "check", scope: "step", stepId: "build" }] }, history: [{ status: "unresolved", evidenceValidity: "missing" }] },
        { id: "two", stepId: "build", stepTitle: "Build", index: 1, text: "Still works", current: { status: "verified", evidenceValidity: "stale", evidence: [{ type: "diff", scope: "step", stepId: "build" }] }, history: [] },
        { id: "three", stepId: "visual", stepTitle: "Visual", index: 0, text: "Looks right", current: { status: "verified", evidenceValidity: "missing", evidence: [{ type: "media", artifactId: "screen" }] }, history: [] },
        { id: "four", stepId: "visual", stepTitle: "Visual", index: 1, text: "Explains failure", current: { status: "failed", evidenceValidity: "missing", evidence: [] }, history: [] },
        { id: "five", stepId: "visual", stepTitle: "Visual", index: 2, text: "Waiting", current: { status: "unresolved", evidenceValidity: "missing", evidence: [] }, history: [] }
      ]
    }
  };
  const all = proofMapView(run);
  assert.deepEqual(all.criteria.map((criterion) => [criterion.id, criterion.state, criterion.history.length]), [
    ["one", "verified", 1], ["two", "stale", 0], ["three", "missing-evidence", 0], ["four", "failed", 0], ["five", "not_yet_verified", 0]
  ]);
  assert.equal(all.criteria[0].evidence[0].route, "/api/tickets/ticket%2Fa/proof/check-output?scope=step&stepId=build");
  assert.deepEqual(proofMapView({ ...run, proofMap: { ...run.proofMap, criteria: [{ ...run.proofMap.criteria[0], current: { ...run.proofMap.criteria[0].current, evidence: [{ type: "check", scope: "attempt", stepId: "build", attemptId: "attempt-2" }] } }] } }).criteria[0].evidence[0].route, "/api/tickets/ticket%2Fa/proof/check-output?scope=attempt&stepId=build&attemptId=attempt-2");
  assert.deepEqual(all.criteria.slice(2).map((criterion) => [criterion.resultLabel, criterion.evidenceLabel]), [["Verified", "Evidence missing"], ["Failed", "Evidence missing"], ["Not yet verified", "Evidence missing"]]);
  assert.equal(all.criteria[1].evidence[0].unavailable, true);
  assert.equal(all.criteria[1].evidence[0].route, undefined);
  assert.equal(all.criteria[2].evidence[0].mediaUrl, "/api/tickets/ticket%2Fa/artifacts/screen/media");
  const missing = proofMapView({ ...run, proofMap: { ...run.proofMap, criteria: [{ ...run.proofMap.criteria[2], current: { ...run.proofMap.criteria[2].current, evidence: [{ type: "media", artifactId: "screen", validity: "missing", reason: "missing_evidence" }] } }] } }).criteria[0].evidence[0];
  assert.deepEqual([missing.unavailable, missing.route, missing.mediaUrl, missing.label], [true, undefined, undefined, "Evidence unavailable: missing evidence"]);
  assert.equal(all.eligibility.blockingReasons[0].criterionId, "two");
  assert.equal(proofMapView(run, { stepId: "build" }).criteria.length, 2);
});

test("free text becomes a local ticket without losing the original request", () => {
  const ticket = freeTextTicket("# Improve search\n\nAdd keyboard navigation.", "A1B2-C3D4");
  assert.deepEqual([ticket.id, ticket.identifier, ticket.title, ticket.source], ["local-text-a1b2-c3d4", "TEXT-A1B2C3D4", "Improve search", "local"]);
  assert.match(ticket.description, /keyboard navigation/);
  assert.throws(() => freeTextTicket("", "id"), /Describe the task/);
});

test("formats JSON output including nested serialized JSON", () => {
  assert.equal(formatOutput('{"summary":"ok","rawOutput":"{\\"findings\\":[]}"}'), '{\n  "summary": "ok",\n  "rawOutput": {\n    "findings": []\n  }\n}');
});

test("filters artifacts for a workflow stage and includes review rounds in verification", () => {
  const artifacts = [{ stageId: "design" }, { stageId: "verify" }, { stageId: "review-round-1" }, { stageId: "implement" }];
  assert.equal(artifactsForStage(artifacts, "design").length, 1);
  assert.equal(artifactsForStage(artifacts, "verify").length, 2);
});

test("handoff artifacts include verify visual-evidence without retagging them", () => {
  const artifacts = [
    { stageId: "handoff", kind: "handoff", name: "handoff.md" },
    { stageId: "verify", kind: "visual-evidence", name: "desktop.png" },
    { stageId: "verify", kind: "independent-review", name: "requirements.json" }
  ];
  assert.deepEqual(artifactsForStage(artifacts, "handoff").map((artifact) => artifact.name), ["handoff.md", "desktop.png"]);
  assert.deepEqual(artifactsForStage(artifacts, "verify").map((artifact) => artifact.name), ["desktop.png", "requirements.json"]);
});

test("keeps an explicit step selection when another step awaits review", () => {
  const plan = { nodes: [{ id: "review", status: "review_ready" }, { id: "other", status: "ready" }] };
  assert.equal(preferredStepId(plan, "other"), "other");
  assert.equal(preferredStepId(plan, null), "review");
});

test("defaults the inspector to the blocked or active workflow stage", () => {
  const stages = [{ id: "clarify", status: "completed" }, { id: "implement", status: "blocked" }, { id: "verify", status: "pending" }];
  assert.equal(preferredStageId(stages), "implement");
  assert.equal(preferredStageId(stages, "verify"), "verify");
});

test("stage details keep the implementation index ordered and split its dependency edges", () => {
  const run = {
    stages: [{ id: "implement", title: "Implement", status: "active" }, { id: "verify", title: "Verify", status: "pending" }],
    plan: { nodes: [
      { id: "foundation", type: "step", title: "Foundation", status: "accepted", dependsOn: [] },
      { id: "build", type: "step", title: "Build UI", status: "running", dependsOn: ["foundation"] },
      { id: "verify-ui", type: "step", stageId: "verify", title: "Verify UI", status: "ready", dependsOn: ["build"] }
    ] }
  };
  assert.deepEqual(stageDetailModel(run, "implement"), {
    stage: { id: "implement", title: "Implement", status: "active", position: 1, total: 2 },
    stepIndex: [{ id: "foundation", title: "Foundation", status: "accepted", position: 1 }, { id: "build", title: "Build UI", status: "running", position: 2 }],
    dependencies: { internal: [{ from: "foundation", to: "build", title: "Foundation", status: "accepted" }], external: [] }
  });
  assert.deepEqual(stageDetailModel(run, "verify").dependencies.external, [{ from: "build", to: "verify-ui", title: "Build UI", status: "running" }]);
});

test("cleanup inspector keeps every durable outcome and marks only advisories as warnings", async () => {
  const executions = {
    complete: { executionId: "complete", outcome: "complete", platform: { name: "linux", supported: true }, triggers: [{ trigger: "worker-completed", at: "2026-09-03T10:00:00.000Z" }], discovered: [{ pid: 42, ppid: 7, startTime: "101" }], actions: [{ pid: 42, signal: "SIGTERM", status: "sent", at: "2026-09-03T10:00:01.000Z" }], unresolved: [], diagnostics: [] },
    incomplete: { executionId: "incomplete", outcome: "incomplete", platform: { name: "linux", supported: true }, triggers: [{ trigger: "run-cancelled", at: "2026-09-03T10:00:00.000Z" }], discovered: [{ pid: 43, ppid: 7, startTime: "102" }], actions: [{ pid: 43, signal: "SIGKILL", status: "sent" }], unresolved: [{ pid: 43, reason: "still-running-after-force" }], diagnostics: ["Fixture process did not exit"] },
    unsupported: { executionId: "unsupported", outcome: "unsupported", platform: { name: "darwin", supported: false, reason: "Safe discovery unavailable" }, triggers: [{ trigger: "daemon-shutdown", at: "2026-09-03T10:00:00.000Z" }], discovered: [], actions: [], unresolved: [], diagnostics: ["No safe adapter"] },
    "not-required": { executionId: "none", outcome: "not-required", platform: { name: "linux", supported: true }, triggers: [{ trigger: "worker-completed", at: "2026-09-03T10:00:00.000Z" }], discovered: [], actions: [], unresolved: [], diagnostics: [] }
  };
  for (const [outcome, execution] of Object.entries(executions)) {
    const model = cleanupInspectorModel({ cleanup: { outcome, updatedAt: "2026-09-03T10:00:02.000Z", executions: [execution] } });
    assert.equal(model.outcome, outcome);
    assert.equal(model.advisory, outcome === "incomplete");
    assert.deepEqual(model.executions[0].discovered, execution.discovered);
    assert.deepEqual(model.executions[0].unresolved, execution.unresolved);
    assert.deepEqual(model.executions[0].diagnostics, execution.diagnostics);
  }
  const app = await readFile(new URL("../public/app.js", import.meta.url), "utf8");
  assert.equal(cleanupInspectorModel({
    cleanup: {
      outcome: "incomplete",
      executions: [{ executionId: "legacy-unrecorded", outcome: "incomplete", unresolved: [], actions: [] }]
    }
  }).advisory, false);
  assert.doesNotMatch(app, /cleanup-advisory|cleanupAdvisoryHtml|Process cleanup is not confirmed/);
  assert.doesNotMatch(app, /data-tab="cleanup"|function cleanupInspectorHtml/);
});

test("step inspector surfaces real attention findings without inventing criterion progress", () => {
  const summary = stepInspectorSummary({
    status: "needs_attention",
    acceptanceCriteria: ["One", "Two"],
    artifacts: [{ id: "result" }],
    attempts: [{ verification: { findings: [{ severity: "high", claim: "Final-admin protection is unresolved" }] } }, { status: "interrupted" }]
  });
  assert.deepEqual(summary, {
    needsAttention: true,
    finding: "Final-admin protection is unresolved",
    findings: [{ severity: "high", claim: "Final-admin protection is unresolved" }],
    findingCount: 1,
    criteria: ["One", "Two"],
    artifactCount: 1,
    attemptCount: 2
  });
  assert.equal(stepInspectorSummary({ status: "accepted", lastError: "stale", attempts: [] }).needsAttention, false);
});

test("fleet rail groups tickets by operator urgency, not tracker buckets", () => {
  assert.equal(fleetLane(null), "idle");
  assert.equal(fleetLane({ status: "completed" }), "idle");
  assert.equal(fleetLane({ status: "running" }), "running");
  assert.equal(fleetLane({ status: "awaiting_approval", checkpoint: { kind: "awaiting_approval" } }), "you");
  assert.equal(fleetLane({ status: "running", plan: { nodes: [{ id: "build", status: "review_ready" }] } }), "you");
  assert.equal(fleetLane({ status: "needs_attention" }), "you");
  assert.equal(fleetLane({ status: "interrupted" }), "you");
  assert.equal(fleetLane({ status: "paused" }), "you");
});

test("fleet ticket view omits findings and exposes stages plus selected agents", () => {
  const view = fleetTicketView(
    { id: "t", identifier: "TEXT-7F2", title: "Merge-queue rebase" },
    {
      status: "needs_attention",
      lastError: "duplicate preview-port bind in src/previews.js",
      createdAt: "2026-09-01T00:00:00.000Z",
      stages: [
        { id: "requirements", status: "completed" },
        { id: "explore", status: "completed" },
        { id: "design", status: "completed" },
        { id: "implement", status: "completed" },
        { id: "verify", status: "blocked" },
        { id: "handoff", status: "pending" }
      ],
      plan: { nodes: [
        { id: "rebase", title: "Rebase", agentId: "worker:rebase", status: "needs_attention", attempts: [{}, {}, {}] },
        { id: "tests", title: "Tests", agentId: "worker:tests", status: "ready" }
      ] }
    },
    { selected: true, now: Date.parse("2026-09-01T00:00:09.000Z") }
  );
  assert.equal(view.lane, "you");
  assert.equal(view.stateLabel, "needs you");
  assert.equal(view.stageLabel, "verify");
  assert.equal(view.agentCount, 2);
  assert.equal(view.idle, "9s idle");
  assert.equal(view.finding, undefined);
  assert.equal(JSON.stringify(view).includes("duplicate"), false);
  assert.deepEqual(view.stages.map((stage) => stage.kind), ["done", "done", "done", "done", "now", "pending"]);
  assert.deepEqual(view.agents.map((agent) => [agent.id, agent.name, agent.meta]), [["rebase", "rebase", "3 att"], ["tests", "tests", "queued"]]);
  assert.equal(fleetTicketView({ id: "t" }, { status: "needs_attention", plan: { nodes: [{ id: "rebase", status: "needs_attention" }] } }, { selected: false }).agents.length, 0);
  const planGate = fleetTicketView(
    { id: "p", identifier: "APP-1842", title: "Board" },
    { status: "awaiting_approval", checkpoint: { kind: "awaiting_approval" }, plan: { nodes: [{ id: "a", status: "ready" }, { id: "b", status: "ready" }] } },
    { selected: true }
  );
  assert.equal(planGate.stateLabel, "plan gate");
  assert.equal(planGate.agentCount, 2);
  assert.equal(planGate.agents.length, 0);
});

test("steering selects only an active or paused saved attempt", () => {
  const run = { id: "ticket", runId: "run", status: "running", plan: { nodes: [{ id: "build", status: "running" }] }, activeRuns: { build: { attemptId: "attempt" } } };
  assert.deepEqual(steeringTarget(run).target, { ticketId: "ticket", runId: "run", stepId: "build", attemptId: "attempt" });
  const paused = { ...run, status: "paused", activeRuns: {}, plan: { nodes: [{ id: "build", status: "interrupted", activeAttempt: { id: "attempt", status: "interrupted" } }] } };
  assert.equal(steeringTarget(paused).paused, true);
  assert.match(steeringTarget(paused).message, /resume is still a separate manual action/i);
  const unavailable = { ...run, activeRuns: { build: { attemptId: "attempt", piSessionState: "unavailable" } } };
  assert.equal(steeringTarget(unavailable).targetable, false);
  assert.match(steeringTarget(unavailable).reason, /not active or resumable/i);
  assert.equal(steeringTarget({ ...run, status: "completed" }).targetable, false);
});

test("steering lifecycle distinguishes unacknowledged Pi delivery", () => {
  const delivered = steeringLifecycle({ state: "delivered", deliveredAt: "2026-09-03T10:01:00.000Z", deliveryEvidence: { session: "pi" } });
  assert.equal(delivered.unacknowledged, true);
  assert.match(delivered.label, /awaiting acknowledgment/);
  assert.deepEqual(delivered.deliveryEvidence, { session: "pi" });
  assert.equal(delivered.acknowledgmentEvidence, null);
  assert.equal(steeringLifecycle({ state: "rejected" }).label, "Rejected before acceptance");
});

test("offers only restart points backed by durable checkpoints", () => {
  const run = {
    baselineTree: "base", workspace: { cwd: "/worktree" },
    artifacts: ["requirements", "product-context-snapshot", "implementation-delta"].map((kind) => ({ kind })),
    plan: { nodes: [{ id: "one", title: "First", status: "accepted", baseTree: "base" }] }
  };
  assert.deepEqual(restartOptions(run).map((option) => option.value), ["stage:explore", "stage:design", "step:one", "stage:verify"]);
  assert.deepEqual(restartOptions({ ...run, merge: { status: "queued" } }), []);
});


test("verification progress keeps open findings until an independent review resolves them", () => {
  const run = { status: "fixing", reviews: [{ round: 1, actionableFindings: [{ claim: "Missing empty state" }], fix: { diff: { files: ["ui.js"] } } }], reviewFindings: [{ id: "one", status: "open", finding: { claim: "Missing empty state" } }] };
  assert.equal(verificationProgress(run).phase, "Correction in progress");
  run.status = "verifying";
  assert.match(verificationProgress(run).phase, /awaiting independent review/);
  assert.equal(verificationProgress(run).open, 1);
  run.reviewFindings[0].status = "resolved";
  run.reviews.push({ round: 2, actionableFindings: [] });
  assert.equal(verificationProgress(run).resolved, 1);
  assert.equal(verificationProgress(run).open, 0);
  assert.deepEqual(verificationProgress({}).findings, []);
});


test("token totals include active work without recounting its saved attempt", () => {
  const usage = { input: 10, output: 4, cacheRead: 8, cacheWrite: 0, calls: 3, records: 1, complete: true };
  const run = { plan: { nodes: [{ id: "one", attempts: [{ runId: "old", attemptId: "attempt-1", usage }] }] }, activeRuns: { old: { runId: "old", attemptId: "attempt-1", activity: { usage } }, current: { runId: "current", attemptId: "attempt-1", activity: { usage } } } };
  assert.equal(runMetrics(run).input, 20);
  assert.equal(runMetrics(run).calls, 6);
  assert.equal(runMetrics(run).usageState, "recorded");
  assert.equal(runMetrics({ plan: { nodes: [] } }).usageState, "unavailable");
});

test("token totals deduplicate repeated saved attempt identities", () => {
  const usage = { input: 10, output: 4, calls: 1, records: 1, complete: true };
  const attempt = { attemptId: "attempt-1", usage };
  const run = { plan: { nodes: [{ id: "one", attempts: [attempt, { ...attempt }] }, { id: "two", attempts: [{ ...attempt }] }] }, activeRuns: { one: { attemptId: "attempt-1", activity: { usage } } } };
  assert.equal(runMetrics(run).input, 20);
  assert.equal(runMetrics(run).calls, 2);
});

test("progress distinguishes actual work, provider waits and user gates", async () => {
  const { runProgress } = await import("../public/ui-model.js");
  assert.equal(runProgress({ status: "running" }).working, true);
  for (const status of ["paused", "completed", "failed", "interrupted", "awaiting_approval"]) assert.equal(runProgress({ status }).working, false);
  assert.equal(runProgress({ status: "running", checkpoint: { kind: "provider_wait" } }).title, "Waiting for provider");
  assert.equal(runProgress({ status: "planning", checkpoint: { title: "Approve direction" } }).working, false);
  assert.equal(runProgress({ status: "paused", uiReplay: { status: "running" } }).title, "Replaying proof checks");
});

test("progress distinguishes evidence repair, approval, live tools and an unresponsive daemon", async () => {
  const { runProgress } = await import("../public/ui-model.js");
  const now = Date.now();
  const run = { status: "reviewing", stages: [{ status: "active", activity: { lastEventAt: new Date(now - 5000).toISOString(), events: [{ type: "tool_start", callId: "one", tool: "review_media" }] } }] };
  assert.equal(runProgress(run, now).phase, "tool");
  assert.equal(runProgress(run, now).lastActivitySeconds, 5);
  assert.equal(runProgress(run, now, { responsive: false }).phase, "daemon_unresponsive");
  assert.equal(runProgress({ status: "needs_attention", lastError: "Proof gate blocked: missing citation" }).phase, "evidence_error");
  assert.match(runProgress({ status: "awaiting_step_review", checkpoint: { kind: "step_review", title: "402 lines exceed 400-line budget" } }).nextAction, /accept/);
});

test("coordination gates use the scrolling workspace and never render plan approval", async () => {
  const app = await readFile(new URL("../public/app.js", import.meta.url), "utf8");
  const usesWorkspace = new Function(`return (${app.match(/function checkpointUsesWorkspace\(run\) \{[\s\S]*?\n\}/)[0]})`)();
  assert.equal(usesWorkspace({ checkpoint: { kind: "coordination" } }), true);
  assert.equal(usesWorkspace({ checkpoint: { kind: "step_review" } }), false);
  const render = new Function("escapeHtml", "clarificationHistoryHtml", `return (${app.match(/function checkpointHtml\(run\) \{[\s\S]*?\n\}/)[0]})`)(String, () => "");
  const html = render({ checkpoint: { kind: "coordination", title: "Resolve work coordination" } });
  assert.match(html, /Open coordination/);
  assert.doesNotMatch(html, /Approve proposal|iframe|Plan approval/);
});
