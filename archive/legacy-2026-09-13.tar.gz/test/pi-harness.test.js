import assert from "node:assert/strict";
import test from "node:test";
import { findPackageJSON } from "node:module";
import { pathToFileURL } from "node:url";
import { chmod, lstat, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { freezeRunAccess, normalizeProjectPolicy } from "../src/access-policy.js";
import { ensureVerificationContractStep, formatCommitMessage, formatTicketHorizon, MAX_VERIFICATION_ACTIONS, verificationContractFiles, verificationContractExists, PiHarness, projectCommandTool, scopedReadTools, scopedWorkerTools, stepContext, transientRepositoryCheckFailure, verificationTools } from "../src/pi-harness.js";
import { runRepositoryChecks } from "../src/repository-checks.js";
import { normalizePlan } from "../src/plan.js";
import { defaultStageProfiles } from "../src/profiles.js";
import { PROCESS_OWNERSHIP_ENV, ProcessContainment, createExecutionOwnership } from "../src/process-containment.js";
import { runProjectCommand } from "../src/project-config.js";
import { resolveEvidence } from "../src/proof-map.js";

test("verifier reads retain immutable, redacted, run-owned source evidence behind access checks", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-source-proof-"));
  try {
    const cwd = join(root, "project");
    const dataDir = join(root, "data");
    await mkdir(cwd);
    await writeFile(join(cwd, "package.json"), '{"devDependencies":{"playwright":"1"},"token":"secret_abcdefgh"}');
    await writeFile(join(root, "outside.txt"), "not permitted");
    const harness = new PiHarness({ dataDir });
    const artifacts = [];
    let read;
    const session = {
      state: { messages: [] }, setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
      async prompt() {
        await assert.rejects(read.execute("outside", { path: "../outside.txt" }));
        assert.equal(artifacts.length, 0);
        const first = await read.execute("first", { path: "package.json" });
        assert.ok(first.content.at(-1).text.includes(artifacts[0].id));
        await writeFile(join(cwd, "package.json"), '{"devDependencies":{"playwright":"2"}}');
        await read.execute("second", { path: "package.json" });
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: JSON.stringify({ summary: "Inspected sources", findings: [], criterionResults: [] }) }] });
      }
    };
    harness.sdk = async () => ({ createAgentSession: async ({ customTools }) => { read = customTools.find((tool) => tool.name === "read"); return { session }; }, SessionManager: { create: () => ({}) } });
    const plan = normalizePlan({ nodes: [{ id: "deps", title: "Dependencies", permission: "read" }] });
    await harness.verifyStep({ cwd, ticket: { id: "ticket" }, plan, step: plan.nodes[0], runId: "run", attemptId: "attempt-2", round: 1, diff: { files: [] }, checks: { status: "passed" }, onEvidence: async (artifact) => { artifacts.push(artifact); } });
    assert.equal(artifacts.length, 2);
    assert.notEqual(artifacts[0].id, artifacts[1].id);
    const firstBody = await readFile(artifacts[0].path, "utf8");
    assert.match(firstBody, /playwright/);
    assert.doesNotMatch(firstBody, /secret_abcdefgh/);
    assert.notEqual(firstBody, await readFile(artifacts[1].path, "utf8"));
    for (const artifact of artifacts) {
      assert.equal(artifact.attemptId, "attempt-2");
      assert.equal(resolveEvidence({ artifacts, proofStorageRoot: dataDir }, { type: "artifact", artifactId: artifact.id }).valid, true);
    }
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("Grok Build omits reasoning on the wire for fresh and cached sessions", async () => {
  // Exercise the SDK's installed dependency even when npm keeps it nested.
  const aiPackage = pathToFileURL(findPackageJSON("@earendil-works/pi-ai", import.meta.resolve("@earendil-works/pi-coding-agent")));
  const { streamSimple } = await import(new URL("./dist/api/openai-responses.js", aiPackage));
  const { clampThinkingLevel } = await import(new URL("./dist/compat.js", aiPackage));
  const harness = new PiHarness({ dataDir: tmpdir() });
  const build = {
    id: "grok-build-0.1", provider: "xai", api: "openai-responses",
    baseUrl: "https://example.invalid/v1", reasoning: true,
    thinkingLevelMap: { off: null, minimal: null },
    input: ["text"], contextWindow: 256000, maxTokens: 1000,
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }
  };
  harness.sdk = async () => ({
    ModelRuntime: {
      create: async () => ({
        getModel: (provider, id) => id === build.id ? build : ({
          id, provider, reasoning: true,
          thinkingLevelMap: { off: null, minimal: null, low: "low", medium: "medium" }
        })
      })
    }
  });
  for (const thinking of ["off", "high"]) {
    const options = await harness.sessionOptions({ provider: "xai", model: build.id, thinking });
    assert.equal(options.thinkingLevel, "off");
    assert.equal(clampThinkingLevel(options.model, "high"), "off");
    let payload;
    const stream = streamSimple(options.model, { messages: [{ role: "user", content: "test", timestamp: 0 }] }, {
      apiKey: "test-only", reasoning: options.thinkingLevel,
      fetch: async (_url, init) => {
        payload = JSON.parse(init.body);
        return new Response("data: [DONE]\n\n", { headers: { "content-type": "text/event-stream" } });
      }
    });
    await stream.result();
    assert.ok(payload, "the real SDK request builder must be exercised");
    assert.equal(Object.hasOwn(payload, "reasoning"), false);
  }
  assert.equal(build.reasoning, true, "shared registry metadata stays unchanged");
  const mapped = await harness.sessionOptions({ provider: "xai", model: "grok-4.3", thinking: "medium" });
  assert.equal(mapped.thinkingLevel, "medium");
  const calls = [];
  await harness.applyProfile({
    model: build,
    setModel: async (model) => calls.push(model.reasoning),
    setThinkingLevel: (level) => calls.push(level)
  }, { provider: "xai", model: "grok-build-0.1", thinking: "off" });
  assert.deepEqual(calls, [false, "off"]);
});

test("commit messages always explain why and name the requirement", () => {
  assert.equal(formatCommitMessage({ subject: "feat: add task board", why: "Users need a visible queue.", requirement: "REQ-board — tasks are displayed" }, {}), "feat: add task board\n\nWhy: Users need a visible queue.\nRequirement: REQ-board — tasks are displayed");
});

test("ticket horizon excludes the current ticket and puts same-team work first", () => {
  const horizon = formatTicketHorizon(
    { id: "current", team: { id: "team-a" } },
    [
      { id: "other", identifier: "B-1", title: "Other team", team: { id: "team-b" } },
      { id: "current", identifier: "A-1", title: "Current", team: { id: "team-a" } },
      { id: "next", identifier: "A-2", title: "Shared foundation", description: "Reuse the task model", team: { id: "team-a" }, state: { name: "Backlog" } }
    ]
  );
  assert.doesNotMatch(horizon, /Current/);
  assert.ok(horizon.indexOf("A-2") < horizon.indexOf("B-1"));
  assert.match(horizon, /A-2 \[Backlog\] Shared foundation — Reuse the task model/);
});

test("requirements clarification reuses the private session for follow-up questions", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  let opened;
  let prompt;
  harness.planningSession = async (...args) => {
    opened = args;
    return { sessionFile: "/tmp/requirements.jsonl" };
  };
  harness.visibleSupervisorPrompt = async (_session, value) => {
    prompt = value;
    return JSON.stringify({ artifact: "# Revised requirements", questions: ["Should archived tasks remain searchable?"] });
  };

  const result = await harness.refineRequirements({
    cwd: "/repo", ticket: { id: "ticket-1" }, runId: "run-1",
    sessionFile: "/tmp/requirements.jsonl", answers: "Yes, keep them searchable."
  });

  assert.equal(opened[1], "/tmp/requirements.jsonl");
  assert.equal(opened[3].repositoryAccess, false);
  assert.match(prompt, /Yes, keep them searchable\./);
  assert.doesNotMatch(prompt, /attachments/);
  assert.deepEqual(result.questions, ["Should archived tasks remain searchable?"]);
});

test("requirements clarification reserves questions for unresolved product outcomes", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  let prompt;
  harness.planningSession = async () => ({ sessionFile: "/tmp/requirements.jsonl" });
  harness.visibleSupervisorPrompt = async (_session, value) => {
    prompt = value;
    return JSON.stringify({ artifact: "# Requirements", questions: [] });
  };

  await harness.clarifyRequirements({
    cwd: "/repo", runId: "run-1", productContext: "No extra context.",
    ticket: { id: "ticket-1", identifier: "T-1", title: "Add verification", description: "Reuse existing checks." }
  });

  assert.match(prompt, /Questions are a last resort/);
  assert.match(prompt, /conservative minimal interpretation/);
  assert.match(prompt, /Never ask the user to choose implementation mechanics/);
  assert.match(prompt, /fail-fast versus aggregate execution/);
});

test("planning exposes exact skills and rejects unavailable names", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  const session = {
    sessionFile: "/tmp/planning.jsonl",
    resourceLoader: { getSkills: () => ({ skills: [{ name: "frontend", description: "UI work" }] }) }
  };
  let prompt;
  harness.planningSession = async () => session;
  harness.visibleSupervisorPrompt = async (_session, value) => {
    prompt = value;
    return JSON.stringify({ title: "Plan", nodes: [{ title: "Build", skills: ["invented"] }] });
  };

  await assert.rejects(harness.generatePlan({ cwd: "/repo", sessionFile: null }), /unavailable skills: invented/);
  assert.match(prompt, /# Available skills\n- frontend/);
  assert.match(prompt, /Default to serial vertical slices/);
  assert.match(prompt, /"designArtifact"/);
  assert.doesNotMatch(prompt, /establish one shared contract first/);
});

test("configured guidance is emitted once per stage in a session", () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  const session = {};
  const profile = { id: "requirements", prompt: "Ask only consequential questions." };

  assert.match(harness.configuredPrompt(session, profile, "Hard contract."), /Ask only consequential questions[\s\S]*Hard contract/);
  assert.equal(harness.configuredPrompt(session, profile, "Follow-up contract."), "Follow-up contract.");
  assert.match(harness.configuredPrompt(session, { ...profile, id: "exploration" }, "Explore."), /Ask only consequential questions[\s\S]*Explore/);
});

test("worker project commands defer canonical verification to the framework", async () => {
  for (const name of ["verify", "capture-proof"]) {
    const result = await projectCommandTool("/unused").execute("call-1", { name });
    assert.equal(result.isError, false);
    assert.equal(result.details.status, "deferred");
    assert.match(result.content[0].text, /once after worker_report/);
  }
});

test("worker project commands isolate generated evidence from the worktree", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-command-evidence-"));
  try {
    let options;
    const tool = projectCommandTool("/fixture", undefined, undefined, async (_cwd, _name, received) => {
      options = received;
      return { status: "passed", command: "capture", output: "captured" };
    }, undefined, root);
    await tool.execute("call-1", { name: "capture" });
    assert.match(options.environment.AGENT_PLAN_EVIDENCE_DIR, new RegExp(`^${root}/command-`));
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("architecture workers see completed and future plan outcomes without unrelated verification ownership", () => {
  const plan = normalizePlan({ title: "Board", nodes: [
    { id: "skeleton", title: "Create skeleton", description: "Launch the empty app.", status: "accepted" },
    { id: "architecture", role: "architecture", title: "Design the domain", description: "Define boundaries for the full board." },
    { id: "persistence", title: "Persist tasks", description: "Survive browser reloads." }
  ] });
  const prompt = stepContext({ plan, step: plan.nodes[1], artifacts: [] });

  assert.match(prompt, /Already completed[\s\S]*Create skeleton: Launch the empty app\./);
  assert.match(prompt, /Current architecture outcome[\s\S]*Design the domain: Define boundaries for the full board\./);
  assert.match(prompt, /Planned after this ticket[\s\S]*Persist tasks: Survive browser reloads\./);
  assert.doesNotMatch(prompt, /Own the repository verification contract/);
  assert.match(prompt, /Expected files:/);
  assert.match(prompt, /Review budget:/);
});

test("existing projects get one focused verification contract before feature work", () => {
  const plan = ensureVerificationContractStep(normalizePlan({ nodes: [
    { id: "feature", title: "Build feature", permission: "write", writeScope: "src,test", requiresVisualEvidence: true }
  ] }), false);
  assert.equal(plan.nodes[0].role, "architecture");
  assert.equal(plan.nodes[0].writeScope, ".agent-plan");
  assert.equal(plan.nodes[1].writeScope, "src,test");
  assert.deepEqual(plan.nodes[1].dependsOn, [plan.nodes[0].id]);
  assert.match(plan.nodes[0].prompt, /AGENT_PLAN_EVIDENCE_DIR/);
  assert.match(plan.nodes[0].prompt, /project\.json/);
  assert.deepEqual(plan.nodes[0].expectedArtifacts, verificationContractFiles);
  assert.match(plan.nodes[0].prompt, /progressive map/);
  assert.match(plan.nodes[0].prompt, /Test real navigation/);
  assert.doesNotMatch(plan.nodes[0].prompt, /docs\/architecture\.md|AGENTS\.md/);
  assert.equal(ensureVerificationContractStep(plan, true), plan);
});

test("bootstrap detects missing discovery and UI files in an otherwise configured repository", async () => {
  const root = await mkdtemp(join(tmpdir(), "harness-bootstrap-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    for (const path of verificationContractFiles.slice(0, 2)) await writeFile(join(root, path), "configured");
    assert.equal(await verificationContractExists(root), false);
    const plan = normalizePlan({ nodes: [{ id: "feature", title: "Feature", permission: "write", writeScope: "src" }] });
    const bootstrapped = ensureVerificationContractStep(plan, await verificationContractExists(root), true);
    assert.deepEqual(bootstrapped.nodes[1].dependsOn, [bootstrapped.nodes[0].id]);
    for (const path of verificationContractFiles.slice(2)) await writeFile(join(root, path), "configured");
    assert.equal(await verificationContractExists(root), true);
    assert.equal(ensureVerificationContractStep(bootstrapped, true, true), bootstrapped);
    assert.match(stepContext({ plan: bootstrapped, step: bootstrapped.nodes[1], artifacts: [] }), /Maintain this progressive map when behavior or navigation changes/);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("visual steps retain explicit scope when verification contracts already exist", () => {
  const original = normalizePlan({ nodes: [
    { id: "visual", title: "Prove the dashboard", permission: "write", writeScope: "public,test", requiresVisualEvidence: true }
  ] });
  const plan = ensureVerificationContractStep(original, true, true);
  assert.equal(plan.nodes.length, 1);
  assert.equal(plan.nodes[0].writeScope, "public,test");
  assert.match(stepContext({ plan: original, step: original.nodes[0], artifacts: [] }), /Write scope: public,test\n/);
  assert.equal(ensureVerificationContractStep(plan, true, true), plan);
});

test("focused screenshot corrections do not receive repository inspection tools", () => {
  const finding = { severity: "high", category: "requirements", claim: "The screenshot omits the proof panel", evidence: [{ file: "proof.png", line: 1 }] };
  assert.deepEqual(verificationTools([finding], [{ data: "image" }]), []);
  assert.deepEqual(verificationTools([finding], []), ["read", "grep", "find", "ls"]);
  assert.deepEqual(verificationTools([{ ...finding, evidence: [{ file: "src/app.js", line: 1 }] }], [{ data: "image" }]), ["read", "grep", "find", "ls"]);
});

test("worker prompts bind structured results to the approved criterion IDs", () => {
  const plan = normalizePlan({ title: "Proof", nodes: [{ id: "build", title: "Build", permission: "write", writeScope: "src", acceptanceCriteria: ["Works"] }] });
  const prompt = stepContext({
    plan, step: plan.nodes[0], artifacts: [],
    proofMap: { criteria: [{ id: "criterion-fixed", stepId: "build", text: "Works" }] }
  });
  assert.match(prompt, /Criterion proof report/);
  assert.match(prompt, /do not repeat repository-wide discovery/);
  assert.match(prompt, /criterion-fixed: Works/);
  assert.match(prompt, /Omit criterionResults entirely/);
  assert.match(prompt, /Step ID: build/);
  assert.ok(prompt.includes(JSON.stringify({ type: "check", scope: "step", stepId: "build" })));
});

test("synthetic review steps can omit optional planning arrays", () => {
  const step = { id: "review-fix", title: "Fix review findings", role: "implementation", harness: "pi", contextPolicy: "seeded", permission: "write" };
  const prompt = stepContext({ plan: { title: "Review", nodes: [step] }, step, artifacts: [] });
  assert.match(prompt, /Skills requested: none/);
  assert.match(prompt, /use review_note for up to five non-obvious changed sections/);
  assert.match(prompt, /one to three informative, direct sentences/);
});

test("review fixer context stays focused when historical artifacts are large", () => {
  const plan = { title: "Ticket plan", summary: "Implement the ticket", nodes: [] };
  const step = {
    id: "review-fix-4", title: "Fix review findings", role: "implementation", harness: "pi",
    contextPolicy: "seeded", permission: "write", writeScope: "**", skills: [], references: [],
    prompt: "Correct the persisted findings.", expectedArtifacts: ["review-fix.md"],
    acceptanceCriteria: ["The reported defect is resolved"]
  };
  const prompt = stepContext({ plan, step, artifacts: [] });
  assert.match(prompt, /Correct the persisted findings/);
  assert.ok(prompt.length < 10000);
});

test("requires the canonical verification script even when npm test exists", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-checks-"));
  try {
    await writeFile(join(root, "package.json"), JSON.stringify({ scripts: { test: "node -e \"process.exit(0)\"" } }));
    const harness = new PiHarness({ dataDir: root });
    assert.equal((await harness.runRepositoryChecks({ cwd: root })).status, "failed");
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "process.exitCode = 0;");
    assert.equal((await harness.runRepositoryChecks({ cwd: root })).status, "passed");

    await writeFile(join(root, "package.json"), JSON.stringify({ scripts: { test: "node -e \"process.exit(1)\"" } }));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "process.exitCode = 1;");
    assert.equal((await harness.runRepositoryChecks({ cwd: root })).status, "failed");
  } finally {
    await rm(root, { recursive: true });
  }
});

test("standalone repository checks use the managed default runner", async () => {
  const root = await mkdtemp(join(tmpdir(), "repository-check-default-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "console.log('passed');");
    assert.equal((await runRepositoryChecks({ cwd: root, dataDir: root })).status, "passed");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("retries one transient filesystem cleanup race without spending a correction round", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-check-retry-"));
  try {
    await writeFile(join(root, "package.json"), JSON.stringify({ scripts: { test: "node verify.mjs" } }));
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), 'import "../verify.mjs";');
    await writeFile(join(root, "verify.mjs"), `
      import { readFileSync, writeFileSync } from "node:fs";
      const path = new URL("count", import.meta.url);
      let count = 0;
      try { count = Number(readFileSync(path, "utf8")); } catch {}
      writeFileSync(path, String(count + 1));
      if (!count) { console.error("ENOTEMPTY: directory not empty, rmdir '/tmp/agent-plan-daemon-test'"); process.exit(1); }
    `);
    const result = await new PiHarness({ dataDir: root }).runRepositoryChecks({ cwd: root });
    assert.equal(result.status, "passed");
    assert.match(result.summary, /after retrying/);
    assert.equal(await readFile(join(root, "count"), "utf8"), "2");
    assert.equal(transientRepositoryCheckFailure("ordinary assertion failure"), false);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("standalone proof capture runs only after passing visual verification and fails closed", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-separate-proof-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "");
    await writeFile(join(root, ".agent-plan", "project.json"), JSON.stringify({ commands: { "capture-proof": ["node", "capture.mjs"] } }));
    const calls = [];
    let fail = "";
    const harness = new PiHarness({ dataDir: root, execImpl: async (_command, args, options) => {
      const phase = args[0].endsWith("capture.mjs") ? "capture" : "verify";
      calls.push(phase);
      if (options.env.AGENT_PLAN_CAPTURE_TICKET_ID) assert.deepEqual(JSON.parse(options.env.AGENT_PLAN_CAPTURE_CRITERIA), phase === "capture" ? [{ id: "backend-criterion" }] : []);
      if (fail === phase) throw new Error(`${phase} failed`);
      if (phase === "capture") {
        assert.equal(options.env.AGENT_PLAN_CAPTURE_TICKET_ID, "T-1");
        await writeFile(join(options.env.AGENT_PLAN_EVIDENCE_DIR, "proof.png"), "fixture");
      }
      return { stdout: `${phase} passed`, stderr: "" };
    } });
    const input = { cwd: root, requireVisualEvidence: true, environment: { AGENT_PLAN_CAPTURE_TICKET_ID: "T-1", AGENT_PLAN_CAPTURE_CRITERIA: "[]" }, proofCriteria: [{ id: "backend-criterion" }] };
    const result = await harness.runRepositoryChecks(input);
    assert.equal(result.status, "passed");
    assert.equal(result.evidence.length, 1);
    assert.deepEqual(calls.splice(0), ["verify", "capture"]);
    await harness.runRepositoryChecks({ cwd: root });
    assert.deepEqual(calls.splice(0), ["verify"]);
    fail = "verify";
    assert.equal((await harness.runRepositoryChecks(input)).status, "failed");
    assert.deepEqual(calls.splice(0), ["verify"]);
    fail = "capture";
    const failed = await harness.runRepositoryChecks(input);
    assert.equal(failed.status, "failed");
    assert.equal(failed.failureKind, "visual-evidence");
    assert.match(failed.summary, /capture-proof failed/);
    assert.deepEqual(calls, ["verify", "capture"]);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("bounded repository failure output retains both context and the final failing evidence", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-check-output-"));
  try {
    await writeFile(join(root, "package.json"), JSON.stringify({ scripts: { test: "node verify.mjs" } }));
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), 'import "../verify.mjs";');
    await writeFile(join(root, "verify.mjs"), `
      console.log("BEGIN-CONTEXT:" + "a".repeat(6000));
      console.log("not ok 237 - preserves the proof record");
      console.log("  location: 'test/proof.test.js:42:1'");
      console.log("  error: |-");
      console.log("    Command failed: git worktree add --detach /tmp/feature abc123");
      console.log("    fatal: failed to read .git/worktrees/feature/commondir");
      console.log("  code: 128");
      console.log("  stack: |-");
      console.log("    TestContext.<anonymous> (file:///tmp/project/test/proof.test.js:87:12)");
      console.log("Final proof dashboard did not render selected MEA-55 workflow within 45 seconds");
      console.log("AFTER-FAILURE-NOISE:" + "c".repeat(120000));
      console.error("CHROME-NOISE:" + "b".repeat(120000));
      process.exit(1);
    `);
    const result = await new PiHarness({ dataDir: root }).runRepositoryChecks({ cwd: root });
    assert.equal(result.status, "failed");
    assert.match(result.output, /BEGIN-CONTEXT/);
    assert.match(result.output, /characters omitted/);
    assert.match(result.output, /Failure highlights/);
    assert.match(result.output, /not ok 237 - preserves the proof record/);
    assert.match(result.output, /test\/proof\.test\.js:42:1/);
    assert.match(result.failureHighlights, /not ok 237 - preserves the proof record/);
    assert.match(result.failureHighlights, /Command failed: git worktree add/);
    assert.match(result.failureHighlights, /fatal: failed to read/);
    assert.match(result.failureHighlights, /test\/proof\.test\.js:87:12/);
    assert.match(result.failureHighlights, /did not render selected MEA-55 workflow within 45 seconds/);
    assert.doesNotMatch(result.failureHighlights, /BEGIN-CONTEXT/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("repository-check timeouts settle despite inherited pipes and request containment immediately", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-check-pipe-timeout-"));
  let parent;
  let descendant;
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), `import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";
const child = spawn(process.execPath, [new URL("./held.mjs", import.meta.url).pathname], { stdio: "inherit" });
await writeFile("pids", [process.pid, child.pid].join(":"));
setInterval(() => {}, 1000);
`);
    await writeFile(join(root, "held.mjs"), "setInterval(() => {}, 1000);\n");
    const triggers = [];
    const containment = {
      executionId: "timed-repository-check", ownership: { token: "timed-check-owner" },
      cleanup: async (trigger) => { triggers.push(trigger); return { executionId: "timed-repository-check", outcome: "complete" }; }
    };
    const started = Date.now();
    const result = await new PiHarness({ dataDir: root, repositoryCheckTimeoutMs: 500 }).runRepositoryChecks({ cwd: root, containment });
    assert.ok(Date.now() - started < 1_500, "timeout must not wait for inherited stdio to close");
    assert.equal(result.status, "failed");
    assert.deepEqual(triggers.map(({ trigger }) => trigger), ["repository-check-timeout", "repository-check-exit"]);
    assert.match(triggers[1].at, /^\d{4}-\d{2}-\d{2}T/);
    [parent, descendant] = (await readFile(join(root, "pids"), "utf8")).split(":").map(Number);
  } finally {
    for (const pid of [parent, descendant]) {
      if (!pid) continue;
      try { process.kill(pid, "SIGKILL"); } catch (error) { if (error.code !== "ESRCH") throw error; }
    }
    await rm(root, { recursive: true, force: true });
  }
});

test("prefers the repository verification contract and discovers image and video evidence when declared", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-contract-"));
  const dataDir = await mkdtemp(join(tmpdir(), "pi-contract-state-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "// deterministic checks\n");
    await writeFile(join(root, ".agent-plan", "project.json"), JSON.stringify({ commands: { "capture-proof": ["node", ".agent-plan/capture.mjs"] } }));
    await writeFile(join(root, ".agent-plan", "capture.mjs"), `
      import { mkdirSync, writeFileSync } from "node:fs";
      import { dirname, join } from "node:path";
      mkdirSync(process.env.AGENT_PLAN_EVIDENCE_DIR, { recursive: true });
      writeFileSync(join(process.env.AGENT_PLAN_EVIDENCE_DIR, "page.png"), Buffer.from("png"));
      writeFileSync(join(process.env.AGENT_PLAN_EVIDENCE_DIR, "interaction.webm"), Buffer.from("webm"));
      writeFileSync(join(process.env.AGENT_PLAN_EVIDENCE_DIR, "ignored.txt"), "not evidence");
    `);
    const harness = new PiHarness({ dataDir });
    const invalid = await harness.runRepositoryChecks({ cwd: root, requireVideoEvidence: true });
    assert.equal(invalid.status, "failed", "a file named .webm is not a playable recording");

    await writeFile(join(root, ".agent-plan", "capture.mjs"), `
      import { mkdirSync, writeFileSync } from "node:fs";
      import { dirname, join } from "node:path";
      mkdirSync(process.env.AGENT_PLAN_EVIDENCE_DIR, { recursive: true });
      writeFileSync(join(process.env.AGENT_PLAN_EVIDENCE_DIR, "page.png"), Buffer.from("png"));
    `);
    const screenshot = await harness.runRepositoryChecks({ cwd: root, requireVisualEvidence: true });
    assert.equal(screenshot.status, "passed");
    const images = await harness.evidenceImages(screenshot.evidence);
    assert.equal(images.length, 1);
    assert.equal(images[0].mimeType, "image/png");
    assert.equal((await harness.runRepositoryChecks({ cwd: root, requireVideoEvidence: true })).status, "failed");

    await writeFile(join(root, ".agent-plan", "capture.mjs"), `
      import { mkdirSync, writeFileSync } from "node:fs";
      import { dirname, join } from "node:path";
      mkdirSync(process.env.AGENT_PLAN_EVIDENCE_DIR, { recursive: true });
      writeFileSync(join(process.env.AGENT_PLAN_EVIDENCE_DIR, "interaction.webm"), Buffer.from("webm"));
    `);
    assert.equal((await harness.runRepositoryChecks({ cwd: root, requireVideoEvidence: true })).status, "failed");

    await writeFile(join(root, ".agent-plan", "capture.mjs"), "// no screenshot\n");
    const missingEvidence = await harness.runRepositoryChecks({ cwd: root, requireVisualEvidence: true });
    assert.equal(missingEvidence.status, "failed");
    assert.equal(missingEvidence.failureKind, "visual-evidence");
  } finally {
    await rm(root, { recursive: true, force: true });
    await rm(dataDir, { recursive: true, force: true });
  }
});

test("repository checks add only the supplied execution ownership to their curated environment", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-owned-checks-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "// injected executor\n");
    let options;
    let cleanupTrigger;
    const harness = new PiHarness({ dataDir: root, execImpl: async (_file, _args, value) => {
      options = value;
      return { stdout: "ok", stderr: "" };
    } });
    const containment = {
      executionId: "check-execution", ownership: { token: "check-owner" },
      cleanup: async (trigger) => { cleanupTrigger = trigger; return { outcome: "not-required" }; }
    };
    const result = await harness.runRepositoryChecks({ cwd: root, containment });
    assert.equal(result.status, "passed");
    assert.equal(options.env[PROCESS_OWNERSHIP_ENV], "check-owner");
    assert.equal(options.env.UNLISTED, undefined);
    assert.equal(cleanupTrigger.trigger, "repository-check-exit");
    assert.equal(cleanupTrigger.at, result.cleanupTrigger.at);
    assert.match(result.cleanupTrigger.at, /^\d{4}-\d{2}-\d{2}T/);
    assert.equal(result.cleanup.outcome, "not-required");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("a repository check launched after settled cleanup starts a fresh owned-process cycle", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-check-after-settled-cleanup-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "// injected executor\n");
    const ownership = createExecutionOwnership("check-after-settled", { randomUUIDImpl: () => "check-owner", now: () => 0 });
    const targets = new Map();
    const signals = [];
    const containment = new ProcessContainment({
      executionId: ownership.executionId,
      ownership,
      graceMs: 0,
      forceWaitMs: 0,
      timeoutMs: 100,
      adapter: {
        platform: "test",
        supported: true,
        discover: async () => ({ processes: [...targets.values()], unresolved: [] }),
        observe: async (pid) => targets.get(pid) || null,
        signal: async (pid, signal) => { signals.push([pid, signal]); targets.delete(pid); }
      }
    });
    await containment.cleanup("preview-exit");
    const harness = new PiHarness({
      dataDir: root,
      execImpl: async () => {
        targets.set(41, { pid: 41, ppid: 7, startTime: "100", ownershipToken: ownership.token });
        return { stdout: "ok", stderr: "" };
      }
    });

    const result = await harness.runRepositoryChecks({ cwd: root, containment });

    assert.equal(result.status, "passed");
    assert.deepEqual(signals, [[41, "SIGTERM"]]);
    assert.deepEqual(result.cleanup.discovered, [{ pid: 41, ppid: 7, startTime: "100" }]);
    assert.deepEqual(result.cleanup.triggers.map(({ trigger }) => trigger), ["preview-exit", "repository-check-exit"]);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("timed-out repository commands forward the containment timeout trigger unchanged", async () => {
  const cleanupTrigger = { trigger: "repository-command-timeout", command: "check", at: "2026-09-03T10:00:01.000Z" };
  const cleanup = { executionId: "timed-command", outcome: "complete" };
  const containment = {
    executionId: "timed-command", ownership: { token: "timed-owner" },
    cleanup: async () => assert.fail("the command already requested containment cleanup")
  };
  let persisted;
  const tool = projectCommandTool("/fixture", undefined, containment, async () => ({
    status: "failed", command: "check", timedOut: true, output: "timed out", cleanup, cleanupTrigger
  }), (evidence, trigger) => { persisted = { evidence, trigger }; });
  const result = await tool.execute("timeout", { name: "check" });
  assert.equal(result.isError, true);
  assert.strictEqual(result.details.cleanup, cleanup);
  assert.strictEqual(persisted.evidence, cleanup);
  assert.strictEqual(persisted.trigger, cleanupTrigger);
});

test("repository-check discovery settles containment when no command can launch", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-empty-checks-"));
  try {
    let cleanupTrigger;
    const containment = {
      executionId: "empty-check", ownership: { token: "empty-owner" },
      cleanup: async (trigger) => { cleanupTrigger = trigger; return { executionId: "empty-check", outcome: "not-required", actions: [] }; }
    };
    const result = await new PiHarness({ dataDir: root }).runRepositoryChecks({ cwd: root, containment });
    assert.equal(result.status, "failed");
    assert.equal(result.cleanup.outcome, "not-required");
    assert.equal(cleanupTrigger.trigger, "repository-check-exit");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("worker project commands share execution ownership and cleanup on exit", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-owned-worker-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, "check.mjs"), "console.log(process.env.AGENT_PLAN_EXECUTION_OWNER)\n");
    await writeFile(join(root, ".agent-plan", "project.json"), JSON.stringify({ commands: { check: ["node", "check.mjs"] } }));
    let customTools;
    let cleanupTrigger;
    const harness = new PiHarness({
      dataDir: root,
      containmentFactory: () => ({
        executionId: "worker-execution", ownership: { token: "own" },
        cleanup: async (trigger) => { cleanupTrigger = trigger; return { outcome: "not-required" }; }
      })
    });
    const session = {
      sessionFile: join(root, "worker.jsonl"), state: { messages: [] },
      resourceLoader: { getSkills: () => ({ skills: [] }) }, setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
      async prompt() {
        const command = customTools.find((tool) => tool.name === "project_command");
        const report = customTools.find((tool) => tool.name === "worker_report");
        const commandResult = await command.execute("command", { name: "check" });
        await report.execute("report", { status: "completed", summary: "Done", artifact: commandResult.details.output });
      }
    };
    harness.sdk = async () => ({
      createAgentSession: async (options) => { customTools = options.customTools; for (const tool of customTools) assert.ok(options.tools.includes(tool.name), `Registered tool ${tool.name} must be allowed by the Pi SDK`); return { session }; },
      SessionManager: { create: () => ({}) }
    });
    const plan = normalizePlan({ title: "Owned command", nodes: [{ id: "owned", title: "Owned", permission: "write", writeScope: "src", skills: [] }] });
    const result = await harness.runStep({ cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [] });
    assert.equal(result.output.trim(), "own");
    assert.equal(cleanupTrigger.trigger, "worker-completed");
    assert.equal(result.cleanup.outcome, "not-required");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("worker uses a daemon-supplied containment rather than replacing its ownership", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-supplied-worker-"));
  try {
    let cleanupTrigger;
    const containment = {
      executionId: "persisted-worker", ownership: { executionId: "persisted-worker", token: "persisted-owner", createdAt: "2026-09-03T10:00:00.000Z" },
      cleanup: async (trigger) => { cleanupTrigger = trigger; return { executionId: "persisted-worker", outcome: "not-required" }; }
    };
    const harness = new PiHarness({ dataDir: root, containmentFactory: () => assert.fail("must use the containment persisted by the daemon") });
    let customTools;
    const session = {
      sessionFile: join(root, "worker.jsonl"), state: { messages: [] }, resourceLoader: { getSkills: () => ({ skills: [] }) },
      setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
      async prompt() { await customTools.find((tool) => tool.name === "worker_report").execute("report", { status: "completed", summary: "Done", artifact: "ok" }); }
    };
    harness.sdk = async () => ({ createAgentSession: async (options) => { customTools = options.customTools; for (const tool of customTools) assert.ok(options.tools.includes(tool.name), `Registered tool ${tool.name} must be allowed by the Pi SDK`); return { session }; }, SessionManager: { create: () => ({}) } });
    const plan = normalizePlan({ title: "Supplied containment", nodes: [{ id: "owned", title: "Owned", permission: "read", skills: [] }] });
    const result = await harness.runStep({ cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [], containment });
    assert.equal(result.cleanup.executionId, "persisted-worker");
    assert.equal(cleanupTrigger.trigger, "worker-completed");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("worker aborts retain conservative cleanup evidence", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-worker-abort-"));
  try {
    const controller = new AbortController();
    let cleanupTrigger;
    const harness = new PiHarness({
      dataDir: root,
      containmentFactory: () => ({
        executionId: "aborted-worker", ownership: { token: "aborted-owner" },
        cleanup: async (trigger) => { cleanupTrigger = trigger; return { outcome: "incomplete" }; }
      })
    });
    const session = {
      state: { messages: [] }, resourceLoader: { getSkills: () => ({ skills: [] }) }, setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
      async prompt() { controller.abort(new Error("cancelled")); }, async abort() {}
    };
    harness.sdk = async () => ({ createAgentSession: async () => ({ session }), SessionManager: { create: () => ({}) } });
    const plan = normalizePlan({ title: "Abort", nodes: [{ id: "abort", title: "Abort", permission: "read", skills: [] }] });
    await assert.rejects(harness.runStep({ cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [], signal: controller.signal }), /cancelled/);
    assert.equal(cleanupTrigger.trigger, "worker-aborted");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("hard worker tools allow scoped writes and block sibling paths", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-sandbox-"));
  try {
    await mkdir(join(root, "allowed"));
    const write = scopedWorkerTools(root, "allowed").find((tool) => tool.name === "write");
    await write.execute("allowed", { path: "allowed/result.txt", content: "ok" });
    assert.equal(await readFile(join(root, "allowed", "result.txt"), "utf8"), "ok");
    await assert.rejects(write.execute("replace", { path: "allowed/result.txt", content: "truncated" }), /exist/i);
    assert.equal(await readFile(join(root, "allowed", "result.txt"), "utf8"), "ok");
    await assert.rejects(write.execute("blocked", { path: "blocked.txt", content: "nope" }), /Write blocked outside scope/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("workers can delete only files inside their write scope", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-delete-"));
  try {
    await mkdir(join(root, "allowed"));
    await writeFile(join(root, "allowed", "obsolete.js"), "old");
    await writeFile(join(root, "blocked.js"), "keep");
    const remove = scopedWorkerTools(root, "allowed").find((tool) => tool.name === "delete");
    await remove.execute("allowed", { path: "allowed/obsolete.js" });
    await assert.rejects(readFile(join(root, "allowed", "obsolete.js")), /ENOENT/);
    await assert.rejects(remove.execute("blocked", { path: "blocked.js" }), /Write blocked outside scope/);
    assert.equal(await readFile(join(root, "blocked.js"), "utf8"), "keep");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("an exact file scope can create its missing parent directory", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-exact-scope-"));
  try {
    const write = scopedWorkerTools(root, "docs/architecture.md").find((tool) => tool.name === "write");
    await write.execute("architecture", { path: "docs/architecture.md", content: "# Architecture\n" });
    assert.equal(await readFile(join(root, "docs", "architecture.md"), "utf8"), "# Architecture\n");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("workers cannot complete without the terminating worker report", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-worker-report-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    let calls = 0;
    let returnReport = false;
    let customTools;
    const session = {
      state: { messages: [] },
      resourceLoader: { getSkills: () => ({ skills: [] }) },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt(value) {
        calls++;
        if (calls % 2 === 0) {
          assert.match(value, /Preserve unresolved failures/);
          if (returnReport) await customTools.find((tool) => tool.name === "worker_report").execute("report", { status: "needs_input", summary: "Dependency unavailable", artifact: "The check could not run", request: "Restore the dependency" });
        }
      },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async (options) => { customTools = options.customTools; for (const tool of customTools) assert.ok(options.tools.includes(tool.name), `Registered tool ${tool.name} must be allowed by the Pi SDK`); return { session }; },
      SessionManager: { create: () => ({}) }
    });
    const plan = normalizePlan({ title: "Read", nodes: [{ id: "inspect", title: "Inspect", permission: "read" }] });

    await assert.rejects(harness.runStep({
      cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [], feedback: ""
    }), /required worker_report tool/);
    assert.equal(calls, 2, "missing report gets only one reminder");
    returnReport = true;
    const result = await harness.runStep({ cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [] });
    assert.equal(calls, 4);
    assert.equal(result.report.status, "needs_input", "the reminder does not turn missing evidence into success");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("fresh verification receives the completed deterministic gate", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-verification-prompt-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    let prompt;
    const sessionDirs = [];
    const session = {
      state: { messages: [] },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt(value) {
        prompt = value;
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: '{"summary":"Verified","findings":[],"criterionResults":[{"criterionId":"current","status":"verified","evidence":[{"type":"check"}]}]}' }] });
      },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: (_cwd, directory) => { sessionDirs.push(directory); return {}; } }
    });
    const plan = normalizePlan({ title: "Verify", nodes: [
      { id: "slice", title: "Slice", permission: "write", writeScope: "src" },
      { id: "later", title: "Recover queued work", permission: "write", writeScope: "src", dependsOn: ["slice"], acceptanceCriteria: ["Paused work drains after resume"] }
    ] });

    const input = {
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" }, plan, step: plan.nodes[0],
      design: "Design", diff: { files: ["src/a.js"], patch: "+change" }, output: "Done", checks: {
        status: "passed", command: "node .agent-plan/verify.mjs", summary: "Checks passed.", output: "10 tests passed"
      }, runId: "run", round: 1
    };
    const result = await harness.verifyStep(input);

    assert.equal(result.summary, "Verified");
    assert.deepEqual(result.criterionResults[0].evidence, [{ type: "check", scope: "step", stepId: "slice" }]);
    assert.match(prompt, /The deterministic gate has already run/);
    assert.match(prompt, /Checks passed\./);
    assert.match(prompt, /Step ID: slice/);
    assert.ok(prompt.includes('{"type":"check"}'));
    assert.match(prompt, /harness attaches the current step and attempt identity/);
    assert.doesNotMatch(prompt, /"type":"diff"/);
    assert.doesNotMatch(prompt, /check \| artifact \| media \| diff/);
    assert.match(prompt, /Diffs are inspection context, not supported proof locators/);
    assert.doesNotMatch(prompt, /10 tests passed/);
    assert.match(prompt, /Report only critical, high, or medium findings/);
    assert.match(prompt, /Keep inspection inside the current working directory/);
    assert.match(prompt, /primary review packet/);
    assert.match(prompt, /concrete medium-or-higher risk/);
    assert.match(prompt, /Deferred plan slices \(not acceptance criteria for this review\)/);
    assert.match(prompt, /Recover queued work: Paused work drains after resume/);
    assert.match(prompt, /Do not report behavior assigned exclusively to a deferred plan slice/);
    assert.doesNotMatch(prompt, /run focused deterministic checks when useful/);

    await harness.verifyStep({ ...input, round: 2, focusFindings: [{ severity: "high", claim: "Write guard is bypassed" }] });
    assert.match(prompt, /This is a correction verification/);
    assert.match(prompt, /Write guard is bypassed/);
    assert.match(prompt, /Do not start a new broad audit/);
    for (const attemptId of ["attempt-2", "attempt-3"]) {
      const verified = await harness.verifyStep({ ...input, attemptId });
      assert.deepEqual(verified.criterionResults[0].evidence, [{ type: "check", scope: "attempt", stepId: "slice", attemptId }]);
      assert.match(prompt, /do not copy them as evidence/);
      assert.ok(sessionDirs.at(-1).includes(`/${attemptId}/round-1`));
    }
    assert.notEqual(sessionDirs.at(-1), sessionDirs.at(-2));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("fresh verification retries one empty model response without repeating inspection", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-verification-retry-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    const prompts = [];
    const session = {
      state: { messages: [] },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt(value) {
        prompts.push(value);
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: prompts.length === 1 ? " " : '{"summary":"Verified after retry","findings":[]}' }] });
      },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}) }
    });
    const plan = normalizePlan({ title: "Verify", nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] });

    const result = await harness.verifyStep({
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" }, plan, step: plan.nodes[0],
      design: "Design", diff: { files: ["src/a.js"], patch: "+change" }, output: "Done",
      checks: { status: "passed", command: "verify", summary: "Passed", output: "10 tests passed" }, runId: "run", round: 1
    });

    assert.equal(result.summary, "Verified after retry");
    assert.equal(prompts.length, 2);
    assert.match(prompts[1], /do not repeat repository inspection/);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("verification surfaces the provider error after one retry", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-verification-error-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    let prompts = 0;
    const session = {
      state: { messages: [] },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt() {
        prompts++;
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: '{"summary":"Partial response","findings":[]}' }], stopReason: "error", errorMessage: "Provider rejected the image payload" });
      },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}) }
    });
    const plan = normalizePlan({ title: "Verify", nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] });

    await assert.rejects(harness.verifyStep({
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" }, plan, step: plan.nodes[0],
      design: "Design", diff: { files: ["src/a.js"], patch: "+change" }, output: "Done",
      checks: { status: "passed", command: "verify", summary: "Passed" }, runId: "run", round: 1
    }), /Provider rejected the image payload/);
    assert.equal(prompts, 2);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("later final-review rounds explicitly recheck earlier findings", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-review-focus-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    let prompt = "";
    const session = {
      state: { messages: [] },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt(value) {
        prompt = value;
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: '{"summary":"Rechecked","findings":[]}' }] });
      },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}) }
    });
    const finding = { severity: "high", claim: "A late child can escape cleanup", evidence: [{ file: "src/process.js", line: 42 }] };
    await harness.reviewTicket({
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" },
      plan: normalizePlan({ title: "Review", nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] }),
      artifacts: [], diff: { files: ["src/process.js"], patch: "+change" }, checks: { status: "passed", summary: "Passed" },
      focusFindings: [finding], operatorFeedback: "AGENT_PLAN_CAPTURE_* variables were injected by the live harness.",
      images: [{ type: "image", data: "proof", mimeType: "image/png" }], role: "integration", round: 2, runId: "run"
    });
    assert.match(prompt, /Progressive review index/);
    assert.match(prompt, /A late child can escape cleanup/);
    assert.match(prompt, /Report an earlier finding again when it remains unresolved/);
    assert.match(prompt, /Do not start a new broad audit or expand the review horizon/);
    assert.match(prompt, /expected application, screen, data and fully loaded state/);
    const navigation = JSON.parse(prompt.split("# Progressive review index\n")[1].split("\n\n")[0]);
    assert.match(await readFile(navigation.constraints, "utf8"), /AGENT_PLAN_CAPTURE_\* variables were injected/);
    assert.doesNotMatch(prompt, /AGENT_PLAN_CAPTURE_\* variables were injected/);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("an interrupted independent reviewer resumes its durable session", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-review-resume-"));
  try {
    const sessionDir = join(root, "pi-sessions", "tickets", "T-1", "run", "reviews", "round-2", "integration", "progressive-v1");
    await mkdir(sessionDir, { recursive: true });
    const sessionFile = join(sessionDir, "saved.jsonl");
    await writeFile(sessionFile, "persisted review");
    const opened = [];
    let prompt;
    let promptImages;
    const prompts = [];
    const session = {
      state: { messages: [{ role: "user", content: "Original review packet" }] },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt(value, options) {
        prompts.push(value);
        prompt = value;
        promptImages = options.images;
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: prompts.length === 1 ? '{"assessment":"Missing summary","findings":[]}' : '{"summary":"Resumed","findings":[]}' }] });
      },
      dispose() {}
    };
    const harness = new PiHarness({ dataDir: root });
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({ fresh: true }), open: (...args) => { opened.push(args); return { resumed: true }; } }
    });
    const input = {
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" },
      plan: normalizePlan({ title: "Review", nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] }), artifacts: [], diff: { files: [], patch: "" },
      proofMap: { criteria: [{ id: "criterion-exact", text: "Preserve the checkpoint" }] },
      checks: { status: "passed", summary: "Passed" }, operatorFeedback: "Fix the blank status pill and clipped mobile worker row.", images: [{ data: "large" }], role: "integration", round: 2, runId: "run"
    };
    const result = await harness.reviewTicket(input);
    assert.equal(result.summary, "Resumed");
    assert.equal(prompts.length, 2);
    assert.match(prompts[1], /Independent-review output: summary must be non-empty/);
    assert.match(prompts[1], /Preserve evidence-backed verdicts and all unresolved findings/);
    assert.match(prompts[1], /do not repeat completed repository inspection/);
    prompt = prompts[0];
    assert.equal(opened[0][0], sessionFile);
    assert.match(prompt, /Continue the interrupted independent review/);
    assert.match(prompt, /"ticket": "T-1"/);
    assert.match(prompt, /"status": "passed"/);
    assert.match(prompt, /"summary": "Passed"/);
    assert.match(prompt, /Filenames, manifests and capture claims alone are not visual proof/);
    const navigation = JSON.parse(prompt.split("# Progressive review index\n")[1].split("\n\n")[0]);
    assert.match(await readFile(navigation.constraints, "utf8"), /blank status pill and clipped mobile worker row/);
    assert.match(prompt, /criterion-exact/);
    assert.deepEqual(promptImages, []);
    session.state.messages = [];
    input.operatorFeedback += " Updated constraints.";
    const events = [];
    await harness.reviewTicket({ ...input, onEvent: (event) => events.push(event) });
    assert.match(prompts.at(-1), /# Independent integration review/);
    assert.match(prompts.at(-1), /# Progressive review index/);
    assert.match(prompts.at(-1), /criterion-exact/);
    assert.ok(events.some((event) => /rebuilding full review context/.test(event.label)));
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}), open: () => { session.state.messages = []; throw new Error("Unreadable session"); } }
    });
    input.operatorFeedback += " Second update.";
    await harness.reviewTicket(input);
    assert.match(prompts.at(-1), /# Progressive review index/);

    session.prompt = async (value) => {
      prompts.push(value);
      session.state.messages.push({ role: "assistant", content: [{ type: "text", text: '{"assessment":"Still invalid","findings":[]}' }] });
    };
    input.operatorFeedback += " Third update.";
    await assert.rejects(harness.reviewTicket(input), /Independent-review output: summary must be non-empty/);
    assert.equal(prompts.length, 6, "invalid output gets only one repair attempt per invocation");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("oversized durable reviewer errors get one fresh compact review", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-review-context-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    const prompts = [];
    let alwaysFail = false;
    let disposed = 0;
    harness.sdk = async () => ({
      SessionManager: { create: () => ({}) },
      createAgentSession: async () => {
        let message;
        return { session: {
          state: { messages: [] },
          sessionManager: { getBranch: () => [{ type: "message", message }] },
          setSessionName() {}, subscribe() { return () => {}; }, dispose() { disposed++; },
          async prompt(value) {
            prompts.push(value);
            message = alwaysFail || prompts.length === 1
              ? { role: "assistant", stopReason: "error", errorMessage: "Your input exceeds the context window of this model", content: [] }
              : { role: "assistant", content: [{ type: "text", text: '{"summary":"Current evidence reviewed","findings":[],"criterionResults":[{"criterionId":"current-criterion","status":"blocked","evidence":[]}]}' }] };
          }
        } };
      }
    });
    const input = {
      cwd: root, ticket: { id: "T-1" }, plan: normalizePlan({ title: "Review", nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] }),
      proofMap: { legacy: { summary: "legacy-sentinel" }, criteria: [{ id: "current-criterion", text: "Current requirement", current: { status: "verified", evidence: [{ artifactId: "current-image" }] }, history: [{ summary: "history-sentinel" }] }] },
      role: "requirements", round: 1, runId: "run"
    };
    assert.equal((await harness.reviewTicket(input)).summary, "Current evidence reviewed");
    assert.equal(prompts.length, 2);
    for (const prompt of prompts) {
      assert.match(prompt, /current-criterion/);
      const navigation = JSON.parse(prompt.split("# Progressive review index\n")[1].split("\n\n")[0]);
      assert.match(await readFile(join(navigation.index, "..", navigation.criteria[0].detail), "utf8"), /current-image/);
      assert.doesNotMatch(prompt, /legacy-sentinel|history-sentinel/);
    }
    assert.equal(disposed, 2);
    alwaysFail = true;
    input.operatorFeedback = "New constraints invalidate cached review";
    await assert.rejects(harness.reviewTicket(input), /exceeds the context window/);
    assert.equal(prompts.length, 4, "fresh context retry is bounded");
    assert.equal(disposed, 4);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("fresh verification stops after its repository inspection budget", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-verification-budget-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    const subscribers = [];
    let aborted = false;
    const session = {
      state: { messages: [] },
      setSessionName() {},
      subscribe(fn) { subscribers.push(fn); return () => {}; },
      async prompt() {
        for (let index = 0; index <= MAX_VERIFICATION_ACTIONS; index++) {
          for (const fn of subscribers) fn({ type: "tool_execution_start", toolName: "review_evidence", toolCallId: `evidence-${index}`, args: { file: "checks.json" } });
        }
        assert.equal(aborted, false, "packet reads must not consume the repository inspection budget");
        for (let index = 0; index <= MAX_VERIFICATION_ACTIONS; index++) {
          for (const fn of subscribers) fn({ type: "tool_execution_start", toolName: "read", toolCallId: `read-${index}`, args: { path: "src/a.js" } });
        }
      },
      async abort() { aborted = true; },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}) }
    });
    const plan = normalizePlan({ title: "Verify", nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] });

    await assert.rejects(harness.verifyStep({
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" }, plan, step: plan.nodes[0],
      design: "Design", diff: { files: ["src/a.js"], patch: "+change" }, output: "Done", checks: {
        status: "passed", command: "node .agent-plan/verify.mjs", summary: "Checks passed.", output: "10 tests passed"
      }, runId: "run", round: 1
    }), new RegExp(`${MAX_VERIFICATION_ACTIONS}-action inspection budget`));

    const saved = join(root, "pi-sessions", "tickets", "T-1", "run", "verifications", "slice", "round-1", "saved.jsonl");
    await writeFile(saved, "saved inspection");
    let opened;
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}), open: path => { opened = path; return {}; } }
    });
    session.state.messages = [{ role: "user", content: "Original verification and inspection" }];
    session.prompt = async prompt => {
      assert.match(prompt, /Continue the interrupted verification/);
      assert.match(prompt, /Do not repeat completed reads/);
      const navigation = JSON.parse(prompt.split("# Current evidence index\n")[1].split("\n\n")[0]);
      assert.deepEqual(JSON.parse(await readFile(join(dirname(navigation.index), "changes.json"), "utf8")).files, ["src/a.js"]);
      session.state.messages.push({ role: "assistant", content: [{ type: "text", text: '{"summary":"Inspected remaining evidence","findings":[]}' }] });
    };
    const result = await harness.verifyStep({
      cwd: root, ticket: { id: "T-1", identifier: "T-1", title: "Ticket" }, plan, step: plan.nodes[0],
      design: "Design", diff: { files: ["src/a.js"], patch: "+current" }, output: "Done",
      checks: { status: "passed", summary: "Checks passed" }, runId: "run", round: 1
    });
    assert.equal(opened, saved);
    assert.equal(result.summary, "Inspected remaining evidence");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("lists every configured model used by stage profiles", async () => {
  const models = await new PiHarness({ dataDir: tmpdir() }).models();
  for (const profile of Object.values(defaultStageProfiles())) {
    assert.equal(models.some((model) => model.id === profile.model && model.provider === profile.provider), true);
  }
});

test("recovers a chronological, detailed trace from a persisted Pi session", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-trace-"));
  const directory = join(root, "pi-sessions");
  const file = join(directory, "run.jsonl");
  try {
    await mkdir(directory);
    await writeFile(file, [
      { type: "message", message: { role: "user", timestamp: 1, content: [{ type: "text", text: "Rendered prompt" }] } },
      { type: "message", message: { role: "assistant", timestamp: 2, usage: { input: 12, output: 3, cacheRead: 7, cacheWrite: 2 }, content: [
        { type: "thinking", thinkingSignature: JSON.stringify({ summary: [{ text: "Inspecting files" }, { text: "Checking the task model" }] }) },
        { type: "toolCall", id: "call-1", name: "bash", arguments: { command: "npm test" } },
        { type: "toolCall", id: "call-2", name: "worker_report", arguments: { status: "completed", summary: "Derived the architecture", artifact: "# Architecture" } }
      ] } },
      { type: "message", message: { role: "toolResult", timestamp: 3, toolCallId: "call-1", toolName: "bash", content: [{ type: "text", text: "32 tests pass" }], isError: false } },
      { type: "message", message: { role: "toolResult", timestamp: 4, toolCallId: "call-2", toolName: "worker_report", content: [{ type: "text", text: "Reported completed" }], isError: false } }
    ].map(JSON.stringify).join("\n"));
    const trace = await new PiHarness({ dataDir: root }).sessionTrace(file);
    assert.equal(trace.prompt, "Rendered prompt");
    assert.deepEqual(trace.prompts, [{ prompt: "Rendered prompt", at: "1970-01-01T00:00:00.001Z" }]);
    assert.deepEqual(trace.events.map((event) => event.type), ["usage", "reasoning_summary", "reasoning_summary", "tool_start", "tool_start", "tool_end", "tool_end"]);
    assert.deepEqual(trace.events[0], { type: "usage", input: 12, output: 3, cacheRead: 7, cacheWrite: 2, label: "Usage recorded", at: "1970-01-01T00:00:00.002Z" });
    assert.match(trace.events[3].args, /npm test/);
    assert.match(trace.events[4].args, /Derived the architecture/);
    assert.equal(trace.events[5].result, "32 tests pass");
    assert.equal(trace.events[6].result, "Reported completed");
    const later = await new PiHarness({ dataDir: root }).sessionTrace(file, { after: "1970-01-01T00:00:00.003Z" });
    assert.ok(later.events.every((event) => event.type !== "usage"), "attempt bounds exclude earlier usage");
  } finally {
    await rm(root, { recursive: true });
  }
});

test("session traces retain only redacted text and safe reasoning summaries", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-redacted-trace-"));
  const directory = join(root, "pi-sessions");
  const file = join(directory, "run.jsonl");
  try {
    await mkdir(directory);
    await writeFile(file, JSON.stringify({ type: "message", message: { role: "assistant", timestamp: 1, content: [
      { type: "thinking", thinkingSignature: JSON.stringify({ summary: [{ text: "Use token=secret_abcdefgh" }] }) },
      { type: "text", text: "ghp_0123456789abcdefghijklmnop" }
    ] } }));
    const trace = await new PiHarness({ dataDir: root }).sessionTrace(file);
    assert.equal(JSON.stringify(trace).includes("secret_abcdefgh"), false);
    assert.equal(JSON.stringify(trace).includes("ghp_0123456789abcdefghijklmnop"), false);
    assert.equal(trace.events[0].type, "reasoning_summary");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("resumed worker sessions send a continuation prompt instead of the full step context", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-resume-prompt-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    let prompt;
    const session = {
      state: { messages: [{ role: "user", content: "Original step context" }] },
      resourceLoader: { getSkills: () => ({ skills: [] }) },
      setSessionName() {},
      subscribe() { return () => {}; },
      async prompt(value) { if (!value.startsWith("Your turn ended without worker_report")) prompt = value; },
      dispose() {}
    };
    harness.sdk = async () => ({
      createAgentSession: async () => ({ session }),
      SessionManager: { create: () => ({}), open: () => ({}), forkFrom: () => ({}) }
    });
    const plan = normalizePlan({ title: "Read", nodes: [
      { id: "inspect", title: "Inspect", permission: "write", writeScope: "src,test/e2e-proof.test.js", skills: [], acceptanceCriteria: ["The API stores queued work"] },
      { id: "deliver", title: "Deliver queued work", permission: "write", writeScope: "src", dependsOn: ["inspect"], acceptanceCriteria: ["Queued work drains after resume"] }
    ] });
    plan.nodes[0].scopeChanges = [{ paths: ["test/e2e-proof.test.js"], reason: "Canonical proof fixtures exercise this contract." }];
    await assert.rejects(harness.runStep({
      cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [],
      feedback: "Use the existing queue model", resumeSessionFile: join(root, "worker.jsonl")
    }), /required worker_report tool/);
    assert.match(prompt, /The user responded to this worker session/);
    assert.match(prompt, /Use the existing queue model/);
    assert.match(prompt, /Effective write scope: src,test\/e2e-proof\.test\.js/);
    assert.match(prompt, /Audited scope additions: test\/e2e-proof\.test\.js \(Canonical proof fixtures exercise this contract\.\)/);
    assert.match(prompt, /Do not request access to a path already included/);
    assert.match(prompt, /Acceptance criteria: The API stores queued work/);
    assert.match(prompt, /Deferred slices: Deliver queued work \(Queued work drains after resume\)/);
    assert.match(prompt, /Do not implement behavior assigned exclusively to a deferred slice/);
    assert.doesNotMatch(prompt, /Skills requested/);

    await assert.rejects(harness.runStep({
      cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [], feedback: "Fix the tests"
    }), /required worker_report tool/);
    assert.match(prompt, /# Review feedback/);
    assert.match(prompt, /Skills requested/);

    session.state.messages = []; // SDK silently creates an empty session for a missing/empty file.
    const events = [];
    await assert.rejects(harness.runStep({
      cwd: root, plan, step: plan.nodes[0], artifacts: [{ kind: "agent-output", name: "prior.md", content: "Accepted interfaces" }], images: [],
      feedback: "Keep the correction", resumeSessionFile: join(root, "missing.jsonl"), onEvent: event => events.push(event)
    }), /required worker_report tool/);
    assert.match(prompt, /Skills requested/);
    const navigation = JSON.parse(prompt.split("# Current evidence index\n")[1].split("\n\n")[0]);
    const index = JSON.parse(await readFile(navigation.index, "utf8"));
    assert.match(await readFile(join(dirname(navigation.index), index.evidence[0].detail), "utf8"), /Accepted interfaces/);
    assert.match(prompt, /Keep the correction/);
    assert.ok(events.some(event => /rebuilding full step context/.test(event.label)));

  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("a verified worker report cannot introduce a second model gate", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  harness.planningSession = async () => assert.fail("verified reports must not launch another model review");
  const result = await harness.reviewWorkerReport({
    cwd: "/repo", sessionFile: "/tmp/supervisor.jsonl", sessionKey: "ticket-run",
    step: { id: "slice", title: "Slice", agentId: "worker:impl", acceptanceCriteria: ["Board renders"] },
    report: { status: "completed", summary: "Done" }, diff: { files: ["src/a.js"] }
  });
  assert.equal(result.sessionFile, "/tmp/supervisor.jsonl");
  assert.deepEqual(result.checkpoints, []);
  assert.match(result.reply, /Independent verification passed for Slice/);
  assert.match(result.reply, /Done \(1 changed file\)/);
});

test("binding a discovered skill loads it as the supervisor workflow", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  let opened;
  let prompt;
  const session = {
    sessionFile: "/tmp/supervisor.jsonl",
    resourceLoader: { getSkills: () => ({ skills: [{ name: "shape-feature", description: "Shape the brief" }] }) }
  };
  harness.planningSession = async (...args) => {
    opened = args;
    return session;
  };
  harness.visibleSupervisorPrompt = async (_session, value) => {
    prompt = value;
    return "Workflow loaded";
  };
  const result = await harness.activateWorkflow({
    cwd: "/repo", sessionFile: null, sessionKey: "ticket-run", skillName: "shape-feature"
  });
  assert.equal(opened[2], "ticket-run");
  assert.match(prompt, /\/skill:shape-feature/);
  assert.match(prompt, /binding workflow/);
  assert.equal(result.reply, "Workflow loaded");
  await assert.rejects(harness.activateWorkflow({
    cwd: "/repo", sessionFile: null, skillName: "missing"
  }), /Pi skill not found: missing/);
});

test("continuing a supervisor checkpoint sends the user response", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  let prompt;
  harness.planningSession = async () => ({ sessionFile: "/tmp/supervisor.jsonl" });
  harness.visibleSupervisorPrompt = async (_session, value) => {
    prompt = value;
    return "Continuing";
  };
  const result = await harness.continueWorkflow({
    cwd: "/repo", sessionFile: "/tmp/supervisor.jsonl", sessionKey: "ticket-run",
    checkpoint: { title: "Approve the brief" }, response: "Ship it"
  });
  assert.match(prompt, /Approve the brief/);
  assert.match(prompt, /Ship it/);
  assert.equal(result.reply, "Continuing");
});

test("reset disposes cached supervisor sessions and clears the queue", () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  let disposed = 0;
  harness.planning.set("ticket-run", { cwd: "/repo", session: { dispose() { disposed++; } } });
  harness.supervisorQueues.set("ticket-run", Promise.resolve());
  harness.reset();
  assert.equal(disposed, 1);
  assert.equal(harness.planning.size, 0);
  assert.equal(harness.supervisorQueues.size, 0);
});

test("explore, design, bind, continue, and review share one supervisor queue key per run", async () => {
  const harness = new PiHarness({ dataDir: tmpdir() });
  const keys = [];
  const original = harness.supervisorTurn.bind(harness);
  harness.supervisorTurn = (work, key) => {
    keys.push(key);
    return original(work, key);
  };
  const session = {
    sessionFile: "/tmp/plan.jsonl",
    resourceLoader: { getSkills: () => ({ skills: [{ name: "shape-feature", description: "Shape" }] }) }
  };
  harness.planningSession = async () => session;
  harness.visibleSupervisorPrompt = async () => JSON.stringify({
    artifact: "# ok", questions: [], title: "Plan", nodes: [{ title: "Build" }], designArtifact: "# design"
  });
  const ticket = { id: "ticket-1", identifier: "T-1", title: "Ticket", description: "" };
  const runId = "run-1";
  const expected = harness.supervisorRunKey(ticket.id, runId);
  await harness.exploreTicket({ cwd: "/repo", ticket, runId, productContext: "ctx", requirements: "req" });
  await harness.designTicket({ cwd: "/repo", ticket, runId, productContext: "ctx", requirements: "req", exploration: "delta", ticketLookAhead: "none" }).catch(() => {});
  await harness.activateWorkflow({ cwd: "/repo", sessionKey: expected, skillName: "shape-feature" });
  await harness.continueWorkflow({ cwd: "/repo", sessionKey: expected, checkpoint: { title: "Gate" }, response: "ok" });
  await harness.reviewWorkerReport({ cwd: "/repo", sessionKey: expected, step: { id: "build", title: "Build", agentId: "w", acceptanceCriteria: [] }, report: { status: "completed" }, diff: { files: [] } });
  assert.ok(keys.includes(expected));
  assert.equal(keys.filter((key) => key === expected).length >= 4, true);
});

test("visual capture readiness is planned early and a failed fixture preflight skips browser capture", async () => {
  const plan = ensureVerificationContractStep(normalizePlan({ nodes: [{ id: "ui", title: "UI", requiresVisualEvidence: true }] }), true, true, false);
  assert.equal(plan.nodes[0].role, "architecture");
  assert.match(plan.nodes[0].prompt, /test-capture-proof/);
  const root = await mkdtemp(join(tmpdir(), "capture-readiness-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "verify.mjs"), "");
    const calls = [];
    const harness = new PiHarness({ dataDir: root, execImpl: async (_command, args) => { calls.push(args); throw new Error("fixture rejected instruction"); } });
    const missing = await harness.runRepositoryChecks({ cwd: root, requireVisualEvidence: true });
    assert.equal(missing.failureKind, "capture-configuration");
    assert.equal(calls.length, 0);
    await writeFile(join(root, ".agent-plan", "project.json"), JSON.stringify({ commands: { "capture-proof": ["node", "capture.mjs"], "test-capture-proof": ["node", "preflight.mjs"] } }));
    const failed = await harness.runRepositoryChecks({ cwd: root, requireVisualEvidence: true });
    assert.equal(failed.failureKind, "capture-preflight");
    assert.equal(calls.length, 1);
    assert.deepEqual(calls[0], ["preflight.mjs"]);
    assert.match(failed.output, /fixture rejected instruction/);
  } finally { await rm(root, { recursive: true, force: true }); }
});

function toolNamed(tools, name) {
  return tools.find((tool) => tool.name === name);
}

function resultText(result) {
  return (result?.content || []).filter((part) => part?.type === "text").map((part) => part.text || "").join("");
}

async function accessLayout() {
  const root = await mkdtemp(join(tmpdir(), "pi-file-tools-"));
  const primary = join(root, "project-a");
  const extra = join(root, "project-b");
  const sibling = join(root, "sibling");
  const outside = join(root, "outside");
  await mkdir(primary);
  await mkdir(extra);
  await mkdir(sibling);
  await mkdir(outside);
  await writeFile(join(primary, "main.js"), "primary-source");
  await writeFile(join(extra, "notes.txt"), "from-b");
  await writeFile(join(sibling, "secret.txt"), "unlisted");
  await writeFile(join(outside, "hidden.txt"), "escaped");
  return { root, primary, extra, sibling, outside };
}

test("file tools from primary A read configured B and deny an unlisted sibling", async () => {
  const { root, primary, extra, sibling } = await accessLayout();
  try {
    const access = await freezeRunAccess({
      primaryCwd: primary,
      policy: await normalizeProjectPolicy({
        extraRoots: [{ path: extra, mode: "read-only", displayPath: "project-b" }]
      }, { primaryCwd: primary })
    });
    const tools = scopedReadTools(primary, access);
    const read = toolNamed(tools, "read");
    const extraRead = await read.execute("extra", { path: join(extra, "notes.txt") });
    assert.match(resultText(extraRead), /from-b/);
    const primaryRead = await read.execute("primary", { path: "main.js" });
    assert.match(resultText(primaryRead), /primary-source/);
    await assert.rejects(read.execute("sibling", { path: join(sibling, "secret.txt") }), /outside the frozen directory allow-list/);
    const listed = await toolNamed(tools, "ls").execute("list-extra", { path: extra });
    assert.match(resultText(listed), /notes.txt/);
    await assert.rejects(toolNamed(tools, "ls").execute("list-sibling", { path: sibling }), /outside the frozen directory allow-list/);
    await assert.rejects(toolNamed(tools, "grep").execute("grep-sibling", { pattern: "unlisted", path: sibling }), /outside the frozen directory allow-list/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("file-tool writes into a read-only extra root fail, as do traversal and symlink escapes", async () => {
  const { root, primary, extra, outside } = await accessLayout();
  try {
    const escape = join(primary, "escape");
    await symlink(outside, escape);
    const access = await freezeRunAccess({
      primaryCwd: primary,
      policy: await normalizeProjectPolicy({
        extraRoots: [{ path: extra, mode: "read-only", displayPath: "project-b" }]
      }, { primaryCwd: primary })
    });
    const tools = scopedWorkerTools(primary, "**", access);
    const write = toolNamed(tools, "write");
    const read = toolNamed(tools, "read");
    const listed = await toolNamed(tools, "ls").execute("list-primary", { path: "." });
    assert.doesNotMatch(resultText(listed), /hidden\.txt/);
    await assert.rejects(write.execute("ro", { path: join(extra, "created.txt"), content: "nope" }), /read-only extra root/);
    await assert.rejects(read.execute("symlink", { path: join(escape, "hidden.txt") }), /outside the frozen directory allow-list/);
    await assert.rejects(write.execute("symlink-write", { path: join(escape, "created.txt"), content: "nope" }), /outside the frozen directory allow-list/);
    await assert.rejects(read.execute("traverse", { path: join(primary, "..", "sibling", "secret.txt") }), /outside the frozen directory allow-list/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("Any-access file tools skip the allow-list and still report host permission failures", async () => {
  const { root, primary, extra, sibling } = await accessLayout();
  const lockedDir = join(root, "locked");
  const lockedFile = join(lockedDir, "secret.txt");
  try {
    await mkdir(lockedDir);
    await writeFile(lockedFile, "denied");
    const access = await freezeRunAccess({
      primaryCwd: primary,
      policy: await normalizeProjectPolicy({
        mode: "any",
        extraRoots: [{ path: extra, mode: "read-only" }]
      }, { primaryCwd: primary })
    });
    const tools = scopedReadTools(primary, access);
    const read = toolNamed(tools, "read");
    const siblingRead = await read.execute("sibling", { path: join(sibling, "secret.txt") });
    assert.match(resultText(siblingRead), /unlisted/);
    assert.deepEqual(tools.map((tool) => tool.name), ["read", "grep", "find", "ls"]);
    if (process.getuid?.() !== 0) {
      await chmod(lockedDir, 0);
      try {
        await assert.rejects(read.execute("eacces", { path: lockedFile }), /EACCES|permission denied|not accessible/i);
      } finally {
        await chmod(lockedDir, 0o700);
      }
    }
  } finally {
    await chmod(lockedDir, 0o700).catch(() => {});
    await rm(root, { recursive: true, force: true });
  }
});

test("read-only sessions stay read-only even when frozen access is Any", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-readonly-any-"));
  try {
    const access = { mode: "any", primary: { id: "primary", path: root, displayPath: root, mode: "read/write" }, extraRoots: [], frozenAt: null };
    let captured;
    const harness = new PiHarness({ dataDir: root });
    const session = {
      sessionFile: join(root, "worker.jsonl"), state: { messages: [] },
      resourceLoader: { getSkills: () => ({ skills: [] }) }, setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
      async prompt() { await captured.find((tool) => tool.name === "worker_report").execute("report", { status: "completed", summary: "Done", artifact: "ok" }); }
    };
    harness.sdk = async () => ({
      createAgentSession: async (options) => { captured = options.customTools; return { session }; },
      SessionManager: { create: () => ({}) }
    });
    const plan = normalizePlan({ title: "Read", nodes: [{ id: "inspect", title: "Inspect", permission: "read", skills: [] }] });
    await harness.runStep({ cwd: root, plan, step: plan.nodes[0], artifacts: [], images: [], access });
    assert.deepEqual(captured.filter((tool) => ["read", "grep", "find", "ls", "edit", "write", "delete"].includes(tool.name)).map((tool) => tool.name), ["read", "grep", "find", "ls"]);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("named project_command still rejects blocked executables", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-blocked-command-"));
  try {
    await mkdir(join(root, ".agent-plan"));
    await writeFile(join(root, ".agent-plan", "project.json"), JSON.stringify({
      commands: { hack: ["bash", "-lc", "pwd"] }
    }));
    await assert.rejects(projectCommandTool(root).execute("hack", { name: "hack" }), /blocked executable/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("primary writes use the session worktree rather than the original checkout", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-mapped-primary-"));
  const original = join(root, "original");
  const worktree = join(root, "worktree");
  try {
    await mkdir(original);
    await mkdir(worktree);
    await writeFile(join(original, "app.js"), "original");
    await writeFile(join(worktree, "app.js"), "worktree");
    const access = await freezeRunAccess({ primaryCwd: original, policy: { mode: "restricted", extraRoots: [] } });
    const write = toolNamed(scopedWorkerTools(worktree, "**", access), "write");
    await write.execute("create", { path: "next.js", content: "from-worktree" });
    assert.equal(await readFile(join(worktree, "next.js"), "utf8"), "from-worktree");
    await assert.rejects(readFile(join(original, "next.js"), "utf8"), /ENOENT/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("grep keeps matches for a permitted file and directory and denies unlisted paths", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-grep-file-"));
  const original = join(root, "original");
  const worktree = join(root, "worktree");
  const sibling = join(root, "sibling");
  try {
    await mkdir(original);
    await mkdir(worktree);
    await mkdir(sibling);
    await writeFile(join(worktree, "file.txt"), "WORKTREE fixture\n");
    await writeFile(join(sibling, "secret.txt"), "unlisted\n");
    const access = await freezeRunAccess({ primaryCwd: original, policy: { mode: "restricted", extraRoots: [] } });
    const grep = toolNamed(scopedReadTools(worktree, access), "grep");
    const directoryHit = await grep.execute("dir", { path: worktree, pattern: "WORKTREE fixture" });
    assert.match(resultText(directoryHit), /WORKTREE fixture/);
    const fileHit = await grep.execute("file", { path: join(worktree, "file.txt"), pattern: "WORKTREE fixture" });
    assert.match(resultText(fileHit), /WORKTREE fixture/);
    await assert.rejects(grep.execute("unlisted", { path: join(sibling, "secret.txt"), pattern: "unlisted" }), /outside the frozen directory allow-list/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("delete refuses an out-of-scope symlink even when its target is in scope", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-delete-link-"));
  const original = join(root, "original");
  const worktree = join(root, "worktree");
  try {
    await mkdir(original);
    await mkdir(join(worktree, "private"), { recursive: true });
    await writeFile(join(worktree, "private", "target.txt"), "keep");
    await writeFile(join(worktree, "private", "ok.txt"), "delete-me");
    await symlink(join(worktree, "private", "target.txt"), join(worktree, "public-link"));
    const access = await freezeRunAccess({ primaryCwd: original, policy: { mode: "restricted", extraRoots: [] } });
    const remove = toolNamed(scopedWorkerTools(worktree, "private", access), "delete");
    await assert.rejects(remove.execute("link", { path: "public-link" }), /Write blocked outside scope/);
    assert.equal((await lstat(join(worktree, "public-link"))).isSymbolicLink(), true);
    assert.equal(await readFile(join(worktree, "private", "target.txt"), "utf8"), "keep");
    await remove.execute("file", { path: "private/ok.txt" });
    await assert.rejects(readFile(join(worktree, "private", "ok.txt")), /ENOENT/);
    assert.equal((await lstat(join(worktree, "public-link"))).isSymbolicLink(), true);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("root-qualified file scope can create a missing parent and leaves unauthorized paths untouched", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-root-scope-"));
  const original = join(root, "original");
  const worktree = join(root, "worktree");
  try {
    await mkdir(original);
    await mkdir(worktree);
    const access = await freezeRunAccess({ primaryCwd: original, policy: { mode: "restricted", extraRoots: [] } });
    const write = toolNamed(scopedWorkerTools(worktree, "root:primary:deep/new.txt", access), "write");
    await write.execute("ok", { path: "deep/new.txt", content: "fixture" });
    assert.equal(await readFile(join(worktree, "deep", "new.txt"), "utf8"), "fixture");
    await assert.rejects(write.execute("denied", { path: "other.txt", content: "nope" }), /Write blocked outside scope/);
    await assert.rejects(readFile(join(worktree, "other.txt")), /ENOENT/);
    await assert.rejects(lstat(join(worktree, "other")), /ENOENT/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("non-Git extra-root exact-file scope can create a missing parent", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-extra-scope-"));
  const original = join(root, "original");
  const worktree = join(root, "worktree");
  const extra = join(root, "extra-b");
  try {
    await mkdir(original);
    await mkdir(worktree);
    await mkdir(extra);
    const access = await freezeRunAccess({
      primaryCwd: original,
      policy: await normalizeProjectPolicy({
        extraRoots: [{ path: extra, mode: "read/write", displayPath: "extra-b" }]
      }, { primaryCwd: original })
    });
    const extraId = access.extraRoots[0].id;
    const write = toolNamed(scopedWorkerTools(worktree, `root:${extraId}:deep/new.txt`, access), "write");
    await write.execute("ok", { path: join(extra, "deep", "new.txt"), content: "fixture" });
    assert.equal(await readFile(join(extra, "deep", "new.txt"), "utf8"), "fixture");
    await assert.rejects(write.execute("denied", { path: join(extra, "denied", "x.txt"), content: "nope" }), /Write blocked outside scope/);
    await assert.rejects(lstat(join(extra, "denied")), /ENOENT/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("Any-access exact absolute file scope can create a missing parent", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-any-scope-"));
  const original = join(root, "original");
  const worktree = join(root, "worktree");
  const outside = join(root, "outside");
  try {
    await mkdir(original);
    await mkdir(worktree);
    await mkdir(outside);
    const access = await freezeRunAccess({
      primaryCwd: original,
      policy: await normalizeProjectPolicy({ mode: "any", extraRoots: [] }, { primaryCwd: original })
    });
    const target = join(outside, "deep", "new.txt");
    const write = toolNamed(scopedWorkerTools(worktree, target, access), "write");
    await write.execute("ok", { path: target, content: "fixture" });
    assert.equal(await readFile(target, "utf8"), "fixture");
    await assert.rejects(write.execute("denied", { path: join(outside, "denied", "x.txt"), content: "nope" }), /Write blocked outside scope/);
    await assert.rejects(lstat(join(outside, "denied")), /ENOENT/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("project_command without a repository stays primary; an explicit id uses mapped B", async () => {
  const root = await mkdtemp(join(tmpdir(), "pi-command-repo-"));
  const primary = join(root, "primary");
  const extra = join(root, "extra-worktree");
  try {
    await mkdir(join(primary, ".agent-plan"), { recursive: true });
    await mkdir(join(extra, ".agent-plan"), { recursive: true });
    await writeFile(join(primary, "ping.mjs"), "console.log('from-primary');\n");
    await writeFile(join(extra, "ping.mjs"), "console.log('from-extra');\n");
    await writeFile(join(primary, ".agent-plan", "project.json"), JSON.stringify({
      commands: { ping: ["node", "ping.mjs"] }
    }));
    await writeFile(join(extra, ".agent-plan", "project.json"), JSON.stringify({
      commands: { ping: ["node", "ping.mjs"] }
    }));
    const repositories = [
      { id: "primary", cwd: primary, sourceCwd: primary },
      { id: "r-extra", cwd: extra, sourceCwd: join(root, "extra-source") }
    ];
    const tool = projectCommandTool(primary, undefined, undefined, runProjectCommand, undefined, undefined, repositories);
    const primaryResult = await tool.execute("primary", { name: "ping" });
    assert.match(resultText(primaryResult), /from-primary/);
    const extraResult = await tool.execute("extra", { name: "ping", repository: "r-extra" });
    assert.match(resultText(extraResult), /from-extra/);
    await assert.rejects(tool.execute("missing", { name: "ping", repository: "nope" }), /Unknown repository/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("independent review loads images only through explicit current-artifact lookup", async () => {
  const root = await mkdtemp(join(tmpdir(), "review-media-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    let customTools;
    let inspect = true;
    let count = 0;
    const session = {
      state: { messages: [] }, setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
      async prompt(_prompt, options) {
        assert.match(_prompt, /artifactId.*exact supplied ID/);
        assert.deepEqual(options.images, []);
        count++;
        if (inspect) {
          const evidenceTool = customTools.find((tool) => tool.name === "review_evidence");
          await assert.rejects(evidenceTool.execute("call", { file: "../index.json" }), /current review index/);
          const index = JSON.parse((await evidenceTool.execute("call", { file: "index.json", limit: 50 })).content[0].text);
          assert.equal(index.content.length, 50);
          assert.ok(index.total > 50);
          const tool = customTools.find((tool) => tool.name === "review_media");
          await assert.rejects(tool.execute("call", { artifactId: "stale" }), /No current review image/);
          const result = await tool.execute("call", { artifactId: "current" });
          assert.equal(result.content[1].data, "image-bytes");
        }
        this.state.messages.push({ role: "assistant", content: [{ type: "text", text: JSON.stringify({ summary: "Reviewed", findings: [], criterionResults: [{ criterionId: "criterion", status: "verified", evidence: [{ type: "media", artifactId: "current" }] }] }) }] });
      }
    };
    harness.sdk = async () => ({ createAgentSession: async (options) => { customTools = options.customTools; for (const tool of customTools) assert.ok(options.tools.includes(tool.name), `Registered tool ${tool.name} must be allowed by the Pi SDK`); return { session }; }, SessionManager: { create: () => ({}) } });
    const input = { cwd: root, ticket: { id: "T" }, plan: normalizePlan({ nodes: [{ id: "ui", title: "UI" }] }), artifacts: [{ id: "current", name: "screen.png", kind: "visual-evidence", path: "/proof/screen.png" }], checks: { status: "passed", evidence: [{ path: "/proof/screen.png", mediaKind: "image" }] }, images: [{ type: "image", data: "image-bytes", mimeType: "image/png" }], role: "requirements", round: 1, runId: "run" };
    const result = await harness.reviewTicket(input);
    assert.deepEqual(result.inputMetrics.inspectedMediaIds, ["current"]);
    assert.ok(result.inputMetrics.promptCharacters < 16000);
    inspect = false;
    await harness.reviewTicket(input); // Same immutable packet retains prior inspection.
    await assert.rejects(harness.reviewTicket({ ...input, round: 2 }), /uninspected media/);
    assert.equal(count, 3, "cached success skips inspection; uninspected media gets one repair, then fails closed");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("UI workers cannot start before the design-system prerequisite exists", async () => {
  const root = await mkdtemp(join(tmpdir(), "ui-prerequisite-"));
  try {
    const harness = new PiHarness({ dataDir: root });
    harness.sdk = async () => { throw new Error("Model must not start"); };
    const plan = normalizePlan({ nodes: [{ id: "ui", title: "UI", permission: "write", requiresVisualEvidence: true }] });
    await assert.rejects(harness.runStep({ cwd: root, plan, step: plan.nodes[0], artifacts: [] }), /Missing \.agent-plan\/design-system.md/);
  } finally { await rm(root, { recursive: true, force: true }); }

});

test("slice verification keeps large evidence out of prompts and indexes changed files", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "slice-context-budget-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const harness = new PiHarness({ dataDir: root });
  let customTools;
  let rendered;
  const events = [];
  const session = {
    state: { messages: [] }, setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
    async prompt(prompt) {
      rendered = prompt;
      assert.ok(prompt.length < 20000, prompt.length);
      assert.doesNotMatch(prompt, /worker-body-sentinel|design-body-sentinel/);
      const tool = customTools.find((tool) => tool.name === "review_evidence");
      const read = async (file, offset = 0) => JSON.parse((await tool.execute("read", { file, offset })).content[0].text);
      await assert.rejects(read("../index.json"), /current review index/);
      const changes = JSON.parse((await read("changes.json")).content);
      assert.deepEqual(changes.files, ["src/a.js"]);
      const index = JSON.parse((await read("index.json")).content);
      const worker = index.evidence.find((item) => item.kind === "agent-output");
      assert.match((await read(worker.detail)).content, /worker-body-sentinel/);
      this.state.messages.push({ role: "assistant", content: [{ type: "text", text: '{"summary":"Verified","findings":[]}' }] });
    }
  };
  harness.sdk = async () => ({ createAgentSession: async (options) => { customTools = options.customTools; for (const tool of customTools) assert.ok(options.tools.includes(tool.name), `Registered tool ${tool.name} must be allowed by the Pi SDK`); return { session }; }, SessionManager: { create: () => ({}) } });
  const plan = normalizePlan({ nodes: [{ id: "slice", title: "Slice", permission: "write", writeScope: "src" }] });
  await harness.verifyStep({ cwd: root, ticket: { id: "T" }, runId: "run", round: 1, plan, step: plan.nodes[0],
    artifacts: [{ kind: "agent-output", stepId: "slice", content: "stale-worker" }],
    design: "design-body-sentinel".repeat(30000), output: "worker-body-sentinel", diff: { files: ["src/a.js"] },
    checks: { status: "passed", output: "check-body".repeat(10000) }, onEvent: (event) => events.push(event)
  });
  assert.equal(events.find((event) => event.type === "prompt").content, rendered);
  assert.equal(events.find((event) => event.type === "context").promptCharacters, rendered.length);
});

test("resumed final fixers receive current indexed evidence instead of replaying stale handoffs", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "fixer-current-context-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const harness = new PiHarness({ dataDir: root });
  let customTools;
  const session = {
    state: { messages: [{ role: "user", content: "Stale evidence" }] },
    resourceLoader: { getSkills: () => ({ skills: [] }) },
    setSessionName() {}, subscribe() { return () => {}; }, dispose() {},
    async prompt(prompt) {
      assert.match(prompt, /Continue from the existing conversation/);
      assert.match(prompt, /This current snapshot supersedes earlier evidence/);
      assert.doesNotMatch(prompt, /current-check-diagnostic|current-handoff/);
      const evidence = customTools.find((tool) => tool.name === "review_evidence");
      const read = async (file) => JSON.parse((await evidence.execute("read", { file })).content[0].text).content;
      assert.match(await read("checks.json"), /current-check-diagnostic/);
      assert.match(await read("constraints.md"), /Preserve the public API/);
      const index = JSON.parse(await read("index.json"));
      assert.match(await read(index.evidence[0].detail), /current-handoff/);
      await customTools.find((tool) => tool.name === "worker_report").execute("report", { status: "completed", summary: "Fixed", artifact: "Cumulative result" });
    }
  };
  harness.sdk = async () => ({ createAgentSession: async (options) => { customTools = options.customTools; for (const tool of customTools) assert.ok(options.tools.includes(tool.name), `Registered tool ${tool.name} must be allowed by the Pi SDK`); return { session }; }, SessionManager: { open: () => ({}), create: () => ({}) } });
  const plan = normalizePlan({ nodes: [{ id: "fix", title: "Fix", permission: "read", skills: [] }] });
  const result = await harness.runStep({ cwd: root, ticketId: "T", runId: "run", step: plan.nodes[0], plan, artifacts: [], feedback: "Fix the current issue", resumeSessionFile: "saved.jsonl", reviewContext: {
    plan: { nodes: [{ id: "implementation", status: "accepted" }] },
    artifacts: [{ stepId: "implementation", kind: "agent-output", content: "current-handoff" }],
    checks: { status: "failed", output: "current-check-diagnostic" }, operatorFeedback: "Preserve the public API"
  } });
  assert.equal(result.report.status, "completed");
});

test("design contract failures receive one same-session repair, never an unbounded retry", async () => {
  const harness = new PiHarness({ dataDir: "/tmp/design-repair-test" });
  const session = { sessionFile: "design-session", resourceLoader: { getSkills: () => ({ skills: [] }) } };
  harness.planningSession = async () => session;
  harness.configuredPrompt = (_session, _profile, prompt) => prompt;
  const prompts = [];
  harness.visibleSupervisorPrompt = async (actual, prompt) => {
    assert.equal(actual, session);
    prompts.push(prompt);
    return JSON.stringify({ title: "Plan", designArtifact: "Design", nodes: [{ id: "save", title: "Save", acceptanceCriteria: ["Saved"], criterionBindings: [{ index: 1, id: "save", evidence: "check" }] }] });
  };
  await assert.rejects(harness.designTicket({ cwd: "/tmp", ticket: { id: "repair" }, runId: "run" }), /Criterion bindings/);
  assert.equal(prompts.length, 2);
  assert.match(prompts[1], /zero-based/);
});
