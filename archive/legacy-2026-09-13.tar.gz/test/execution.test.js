import test from "node:test";
import assert from "node:assert/strict";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { freezeRunAccess, normalizeProjectPolicy } from "../src/access-policy.js";
import { actionableFindings, archiveRun, auditVisualEvidencePolicy, beginRunCleanup, clearInactiveRuns, compactRun, completeRunCleanup, correctionPauseReason, correctionWindowRound, createActivityCapture, createTicketRun, finalReviewFixFeedback, finalReviewFixStep, finalReviewRepositoryBoundary, findingsFingerprint, groupActivityEvents, humanProofFindings, interruptedStepFeedback, liveCaptureEnvironment, markRunCancelled, markRunPaused, materializeActiveAttempt, nextCorrectionRound, nextRunnableBatch, nextRunnableStep, pendingReviewAttempt, pendingReviewFix, planApprovalPending, prepareRunResume, providerWaitCheckpoint, publicPreviewState, publicState, recoverableCleanReview, recurringReviewClusters, refreshedReviewFindings, restartReviewFixSession, resumeStage, reviewFixConstraints, reviewFixImages, reviewScopeExpanded, rewindRun, shouldPauseCorrection, storedFindingsFingerprint, unaddressedReviewClusters, verificationFocusFindings, visualEvidencePolicy } from "../src/execution.js";
import { normalizePlan } from "../src/plan.js";
import { initializeProofMap } from "../src/proof-map.js";

test("only the first dependency-ready implementation slice is selected", () => {
  const plan = normalizePlan({ nodes: [
    { id: "one", title: "First slice", permission: "write" },
    { id: "two", title: "Second slice", permission: "write", dependsOn: ["one"] },
    { id: "three", title: "Third slice", permission: "write", dependsOn: ["two"] }
  ] });
  assert.equal(nextRunnableStep(plan).id, "one");
  plan.nodes[0].status = "review_ready";
  assert.equal(nextRunnableStep(plan), null);
  plan.nodes[0].status = "accepted";
  assert.equal(nextRunnableStep(plan).id, "two");
});

test("dependency-ready siblings in one group form a parallel batch", () => {
  const plan = normalizePlan({ nodes: [{
    id: "parallel", type: "group", title: "Parallel", children: [
      { id: "feature", title: "Feature", permission: "write" },
      { id: "ci", title: "CI", permission: "write" }
    ]
  }] });
  assert.deepEqual(nextRunnableBatch(plan).map((step) => step.id), ["feature", "ci"]);
  plan.nodes[0].children[0].status = "review_ready";
  assert.deepEqual(nextRunnableBatch(plan), []);
});

test("resuming a run makes attention-blocked workers runnable again", () => {
  const run = {
    status: "needs_attention",
    plan: normalizePlan({ nodes: [
      { id: "blocked", title: "Blocked", status: "needs_attention" },
      { id: "later", title: "Later", dependsOn: ["blocked"] }
    ] })
  };
  assert.equal(prepareRunResume(run), true);
  assert.equal(run.status, "interrupted");
  assert.equal(run.plan.nodes[0].status, "interrupted");
  assert.equal(nextRunnableStep(run.plan).id, "blocked");
});

test("final review keeps every unique actionable finding", () => {
  const duplicate = { severity: "blocking", claim: "Missing guard", evidence: [{ file: "src/a.ts", line: 9 }] };
  const findings = actionableFindings([
    { findings: [duplicate, { severity: "medium", claim: "Missing browser coverage", evidence: [{ file: "test/app.test.ts", line: 2 }] }] },
    { findings: [duplicate, { severity: "blocking", claim: "No regression test", evidence: [{ file: "test/a.test.ts", line: 1 }] }] }
  ]);
  assert.equal(findings.length, 3);
});

test("final review collapses a generic test failure and reviewer paraphrases into one concrete defect", () => {
  const criterion = "Full repository tests pass.";
  const findings = actionableFindings([
    { findings: [{ severity: "blocking", category: "tests", claim: "Repository check failed: node verify.mjs", suggestedFix: "not ok 4" }] },
    { findings: [{ severity: "high", category: "tests", claim: "An async test was cancelled.", acceptanceCriterion: criterion, evidence: [{ file: "test/run.test.js", line: 20 }] }] },
    { findings: [{ severity: "high", category: "tests", claim: "The worker test deadlocks while awaiting resume.", acceptanceCriterion: criterion, evidence: [{ file: "test/run.test.js", line: 24 }, { file: "src/server.js", line: 10 }], suggestedFix: "Start resume without awaiting it, release the worker, and then await resume." }] },
    { findings: [{ severity: "high", category: "requirements", claim: "Ambiguous input is accepted.", evidence: [{ file: "src/steering.js", line: 12 }] }] }
  ]);
  assert.equal(findings.length, 2);
  assert.match(findings[0].claim, /deadlocks/);
  assert.match(findings[1].claim, /Ambiguous/);
});

test("final review collapses nearby paraphrases of the same defect across criteria", () => {
  const findings = actionableFindings([
    { findings: [{ severity: "high", category: "tests", claim: "The verification gate fails because completeRunCleanup stores the trigger object instead of flattening its fields, leaving lifecycle evidence malformed.", suggestedFix: "Preserve the complete trigger payload and timestamp, then deduplicate only exact records.", acceptanceCriterion: "Full tests pass.", evidence: [{ file: "src/execution.js", line: 147 }, { file: "src/execution.js", line: 155 }] }] },
    { findings: [{ severity: "high", category: "correctness", claim: "Cleanup trigger persistence drops payload fields because completeRunCleanup records only trigger and timestamp, producing mismatched lifecycle evidence.", suggestedFix: "Pass the complete trigger payload and timestamp through cleanup, then deduplicate only exact records.", acceptanceCriterion: "Repeated cleanup retains every trigger.", evidence: [{ file: "src/execution.js", line: 154 }, { file: "src/execution.js", line: 155 }] }] },
    { findings: [{ severity: "high", category: "correctness", claim: "Cleanup can terminate a newly launched process after ownership transfers.", acceptanceCriterion: "Process ownership transfers safely.", evidence: [{ file: "src/execution.js", line: 90 }] }] }
  ]);
  assert.equal(findings.length, 2);
  assert.match(findings[0].claim, /lifecycle/);
  assert.match(findings[1].claim, /newly launched/);
});

test("final review collapses independently worded findings on the same code defect", () => {
  const findings = actionableFindings([
    { findings: [{ severity: "high", category: "correctness", claim: "Restarting an approved run does not reset or invalidate its proof map, so a rerun can inherit verified records for superseded code.", suggestedFix: "Discard prior proof on design restart and invalidate affected criteria on step restart.", evidence: [{ file: "src/execution.js", line: 300 }, { file: "src/server.js", line: 900 }] }] },
    { findings: [{ severity: "high", category: "correctness", claim: "Run rewind does not reconcile the proof map with restored code or redesigned plans, retaining obsolete proof after restarts.", suggestedFix: "Make rewind proof-aware and archive prior approved proof before redesign.", evidence: [{ file: "src/execution.js", line: 302 }, { file: "src/server.js", line: 902 }] }] },
    { findings: [{ severity: "high", category: "correctness", claim: "Media evidence remains valid when an unrelated cache entry changes.", suggestedFix: "Scope cache identity to the run.", evidence: [{ file: "src/execution.js", line: 302 }] }] }
  ]);
  assert.equal(findings.length, 2);
  assert.match(findings[0].claim, /Restarting|rewind/);
  assert.match(findings[1].claim, /Media evidence/);
});

test("final review retains distinct failures on the same criterion and code surface", () => {
  const shared = { severity: "high", category: "correctness", acceptanceCriterion: "Historical evidence remains valid" };
  const findings = actionableFindings([{ findings: [
    { ...shared, claim: "Rewind reuses attempt IDs and aliases old evidence to a new attempt", evidence: [{ file: "src/proof-map.js", line: 84 }] },
    { ...shared, claim: "Stale locators can be resubmitted without evidence produced after invalidation", evidence: [{ file: "src/proof-map.js", line: 84 }] }
  ] }]);
  assert.equal(findings.length, 2);
});

test("final review keeps separate stale-evidence bypass mechanisms", () => {
  const shared = { severity: "high", category: "correctness", acceptanceCriterion: "Re-verification requires fresh evidence" };
  const findings = actionableFindings([{ findings: [
    { ...shared, claim: "Submitting the same stale locator twice drops invalidatedAt after the first rejection", evidence: [{ file: "src/proof-map.js", line: 202 }, { file: "test/proof-map.test.js", line: 184 }] },
    { ...shared, claim: "A different pre-existing locator without producedAt bypasses freshness after invalidation", evidence: [{ file: "src/proof-map.js", line: 198 }, { file: "test/proof-map.test.js", line: 188 }] }
  ] }]);
  assert.equal(findings.length, 2);
});

test("a generic red-gate report does not duplicate its concrete test findings", () => {
  const findings = actionableFindings([{ findings: [
    { severity: "high", category: "tests", claim: "The required verification suite is not green: the supplied gate reports failures", evidence: [{ file: ".agent-plan/verify.mjs", line: 7 }] },
    { severity: "medium", category: "tests", claim: "Two assertions still expect the old rejection wording", acceptanceCriterion: "Full tests pass", evidence: [{ file: "test/proof-map.test.js", line: 99 }] }
  ] }]);
  assert.deepEqual(findings.map((finding) => finding.claim), ["Two assertions still expect the old rejection wording"]);
});

test("final review prefers a concrete root cause over a vaguer failure paraphrase", () => {
  const criterion = "Re-running verification preserves old evidence and produces fresh proof.";
  const findings = actionableFindings([{ findings: [
    { severity: "blocking", category: "tests", claim: "Repository check failed: node .agent-plan/verify.mjs", suggestedFix: "The restart test timed out." },
    { severity: "high", category: "tests", claim: "The canonical verification suite remains red: the restart test times out.", acceptanceCriterion: criterion, evidence: [{ file: "test/e2e-proof.test.js", line: 109 }, { file: "src/server.js", line: 2251 }] },
    { severity: "high", category: "tests", claim: "The restart test waits for finalCheckHistory through GET /run, but compactRun omits finalCheckHistory, so success is unobservable.", suggestedFix: "Wait on the exposed proof locator or expose immutable review history.", acceptanceCriterion: criterion, evidence: [{ file: "test/e2e-proof.test.js", line: 143 }, { file: "src/execution.js", line: 553 }] },
    { severity: "high", category: "tests", claim: "The restart flow times out before fresh proof appears and the suite is failing.", suggestedFix: "Trace the transition and correct it.", acceptanceCriterion: criterion, evidence: [{ file: "test/e2e-proof.test.js", line: 109 }, { file: "test/e2e-proof.test.js", line: 143 }, { file: "src/server.js", line: 2251 }] }
  ] }]);
  assert.equal(findings.length, 1);
  assert.match(findings[0].claim, /compactRun omits finalCheckHistory/);
});

test("resuming review refreshes canonical findings from durable raw reviewer output", () => {
  const distinct = [
    { severity: "high", category: "correctness", claim: "Attempt IDs alias old evidence", evidence: [{ file: "src/proof-map.js", line: 84 }] },
    { severity: "high", category: "correctness", claim: "Stale locators bypass freshness", evidence: [{ file: "src/proof-map.js", line: 84 }] }
  ];
  const review = { reviews: [{ role: "verification", findings: distinct }], actionableFindings: [distinct[0]] };
  assert.deepEqual(refreshedReviewFindings(review), distinct);
});

test("resuming a proof correction restores the operator's canonical numbered scope", () => {
  const feedback = "Proof issues. (1) Remove the blank pill. (2) Fix mobile clipping. (3) Regenerate ticket screenshots.";
  const review = {
    reviews: [{ role: "requirements", findings: [{ severity: "high", category: "accessibility", claim: "The mobile row is clipped", evidence: [{ file: "public/styles.css", line: 80 }] }] }],
    actionableFindings: [
      { severity: "high", category: "accessibility", claim: "The mobile row is clipped", evidence: [{ file: "public/styles.css", line: 80 }] },
      { severity: "blocking", category: "human-proof-review", claim: feedback }
    ]
  };
  assert.deepEqual(refreshedReviewFindings(review).map((finding) => finding.claim), [
    "Remove the blank pill.", "Fix mobile clipping.", "Regenerate ticket screenshots."
  ]);
});

test("review refresh detects findings removed by canonicalization", () => {
  const generic = { severity: "high", category: "tests", claim: "The required suite is not green: the gate reports failures", evidence: [{ file: ".agent-plan/verify.mjs", line: 8 }] };
  const concrete = { severity: "medium", category: "tests", claim: "The producedAt assertion is stale", evidence: [{ file: "test/proof-map.test.js", line: 85 }] };
  const stored = [generic, concrete];
  const refreshed = actionableFindings([{ findings: stored }]);
  assert.equal(findingsFingerprint(stored), findingsFingerprint(refreshed));
  assert.notEqual(storedFindingsFingerprint(stored), storedFindingsFingerprint(refreshed));
});

test("review refresh reopens completed fixes only for newly exposed mechanisms", () => {
  const prior = { severity: "high", category: "tests", claim: "The canonical verifier fails because collision-resistant artifact storage paths no longer match two stale migration-test regexes.", evidence: [{ file: "test/store.test.js", line: 63 }, { file: "src/artifacts.js", line: 61 }], suggestedFix: "Update migration assertions to validate kind/hash-prefixed storage paths and retained bodies." };
  const paraphrase = { severity: "high", category: "tests", claim: "Two store migration tests expect legacy filenames that no longer match collision-resistant artifact storage names.", evidence: [{ file: "test/store.test.js", line: 61 }, { file: "src/artifacts.js", line: 59 }], suggestedFix: "Update migration path assertions for collision-resistant persisted paths and retained bodies." };
  const distinct = { severity: "high", category: "correctness", claim: "Artifact bodies are overwritten on a same-name collision", evidence: [{ file: "src/artifacts.js", line: 59 }], suggestedFix: "Include artifact kind in storage identity." };
  assert.equal(reviewScopeExpanded([prior], [paraphrase]), false);
  assert.equal(reviewScopeExpanded([prior], [paraphrase, distinct]), true);
});

test("an interrupted review round reuses its persisted deterministic attempt", () => {
  const attempt = { round: 12, checks: { status: "passed" }, diff: { available: true }, verificationDiff: { available: true } };
  assert.equal(pendingReviewAttempt({ pendingReviewAttempt: attempt }, 12), attempt);
  assert.equal(pendingReviewAttempt({ pendingReviewAttempt: attempt }, 13), null);
});

test("final proof feedback becomes a durable actionable review finding", () => {
  const [finding] = humanProofFindings("Fix the clipped mobile worker row");
  assert.equal(finding.category, "human-proof-review");
  assert.equal(finding.severity, "blocking");
  assert.match(finding.claim, /clipped mobile worker row/);
  assert.deepEqual(humanProofFindings("  "), []);
});

test("numbered visual proof feedback creates distinct visual correction criteria", () => {
  const findings = humanProofFindings("Visual proof issues. (1) Remove the blank status pill. (2) Fix the clipped mobile worker row. (3) Regenerate ticket-specific desktop screenshots.");
  assert.deepEqual(findings.map((finding) => finding.claim), [
    "Remove the blank status pill.",
    "Fix the clipped mobile worker row.",
    "Regenerate ticket-specific desktop screenshots."
  ]);
  const step = finalReviewFixStep(17, findings);
  assert.equal(step.requiresVisualEvidence, false);
  assert.match(step.prompt, /harness captures required visual proof/);
  assert.equal(step.acceptanceCriteria.length, 3);
});

test("visual checks receive the live ticket and run capture identity", () => {
  assert.deepEqual(liveCaptureEnvironment({ address: "127.0.0.1", port: 4317 }, "ticket-1", "run-2"), {
    AGENT_PLAN_CAPTURE_URL: "http://127.0.0.1:4317",
    AGENT_PLAN_CAPTURE_TICKET_ID: "ticket-1",
    AGENT_PLAN_CAPTURE_RUN_ID: "run-2"
  });
  assert.deepEqual(liveCaptureEnvironment(null, "ticket-1", "run-2"), {});
  assert.deepEqual(liveCaptureEnvironment("http://127.0.0.1:47821/", "ticket-1", "run-2"), {
    AGENT_PLAN_CAPTURE_URL: "http://127.0.0.1:47821",
    AGENT_PLAN_CAPTURE_TICKET_ID: "ticket-1",
    AGENT_PLAN_CAPTURE_RUN_ID: "run-2"
  });
});

test("automatic corrections ignore findings below medium severity", () => {
  const findings = actionableFindings([{ findings: [
    { severity: "low", claim: "Could rename this helper" },
    { severity: "medium", claim: "Cancellation leaves the request running" },
    { severity: "high", claim: "Write access bypasses the guard" },
    { severity: "critical", claim: "Credentials are exposed" }
  ] }]);
  assert.deepEqual(findings.map((finding) => finding.severity), ["medium", "high", "critical"]);
});

test("cancelling a run stops every active step and preserves it for resume", () => {
  const run = {
    status: "verifying", checkpoint: { kind: "step_review" }, activeRuns: { one: {} },
    stages: [{ status: "active", summary: "Working" }],
    plan: normalizePlan({ nodes: [{ title: "One", status: "running" }, { title: "Two", status: "fixing" }, { title: "Later" }] })
  };
  markRunCancelled(run, "2026-08-24T20:00:00.000Z");
  assert.deepEqual(run.plan.nodes.map((step) => step.status), ["cancelled", "cancelled", "ready"]);
  assert.equal(run.status, "cancelled");
  assert.deepEqual(run.activeRuns, {});
  assert.equal(run.stages[0].summary, "Run cancelled");
});

test("pausing a run preserves the live attempt and session as an audit checkpoint", () => {
  const plan = normalizePlan({ nodes: [{ id: "one", title: "One", status: "verifying", attempts: [] }] });
  const run = {
    status: "running", checkpoint: null, sessionFile: "/tmp/supervisor.jsonl",
    stages: [{ id: "implement", status: "active", summary: "Working" }], plan,
    activeRuns: { one: {
      runId: "worker-1", sessionFile: "/tmp/worker.jsonl", startedAt: "2026-09-02T10:00:00.000Z",
      activity: { lastEventAt: "2026-09-02T10:01:00.000Z", lastEvent: "Editing", rawOutput: "partial", events: [{ type: "phase", label: "Editing" }], groups: [{ title: "Change implementation" }] }
    } }
  };
  const audit = markRunPaused(run, "2026-09-02T10:02:00.000Z");
  assert.equal(run.status, "paused");
  assert.equal(run.stages[0].status, "paused");
  assert.equal(run.plan.nodes[0].status, "interrupted");
  assert.equal(run.plan.nodes[0].sessionFile, "/tmp/worker.jsonl");
  assert.equal(run.plan.nodes[0].attempts[0].sessionFile, "/tmp/worker.jsonl");
  assert.equal(run.plan.nodes[0].attempts[0].rawOutput, "partial");
  assert.equal(run.plan.nodes[0].attempts[0].terminationReason, "run_paused");
  assert.equal(run.plan.nodes[0].attempts[0].failureKind, "interruption");
  assert.deepEqual(run.activeRuns, {});
  assert.equal(audit.steps[0].lastEvent, "Editing");
  assert.equal(run.pauseHistory[0].id, "pause-1");
});

test("terminal snapshots isolate parallel workers and correction history", () => {
  const plan = normalizePlan({ nodes: [
    { id: "api", title: "API", status: "running", attempts: [] },
    { id: "ui", title: "UI", status: "fixing", attempts: [] }
  ] });
  const run = {
    status: "running", checkpoint: null, stages: [{ id: "implement", status: "active", summary: "Parallel work" }], plan,
    activeRuns: {
      api: { runId: "worker-api", attemptId: "attempt-1", startedAt: "2026-09-02T10:00:00.000Z", activity: { lastEvent: "Editing API", rawOutput: "api output", events: [{ label: "API" }] } },
      ui: { runId: "worker-ui", attemptId: "attempt-1", startedAt: "2026-09-02T10:01:00.000Z", activity: { lastEvent: "Editing UI", rawOutput: "ui output", events: [{ label: "UI" }] } }
    }
  };
  markRunCancelled(run, "2026-09-02T10:02:00.000Z");
  assert.deepEqual(run.plan.nodes.map((step) => [step.attempts[0].attemptId, step.attempts[0].runId, step.attempts[0].rawOutput]), [
    ["attempt-1", "worker-api", "api output"], ["attempt-1", "worker-ui", "ui output"]
  ]);

  const prior = structuredClone(run.plan.nodes[0].attempts[0]);
  materializeActiveAttempt(run.plan.nodes[0], {
    runId: "worker-api-correction", attemptId: "attempt-2", startedAt: "2026-09-02T10:03:00.000Z",
    activity: { lastEvent: "Fixing API", rawOutput: "corrected output" }
  }, { status: "verified", reason: "verification_complete", phase: "verification" });
  assert.equal(run.plan.nodes[0].attempts.length, 2);
  assert.deepEqual(run.plan.nodes[0].attempts[0], prior);
  assert.equal(run.plan.nodes[0].attempts[1].attemptId, "attempt-2");
  assert.equal(run.plan.nodes[0].attempts[1].rawOutput, "corrected output");
});

test("failed and paused workflows can resume from their persisted stage", () => {
  const failed = {
    status: "failed", plan: null, lastError: "planner stopped",
    artifacts: [{ kind: "requirements" }, { kind: "implementation-delta" }],
    stages: [
      { id: "requirements", status: "completed" },
      { id: "explore", status: "completed" },
      { id: "design", status: "blocked" }
    ]
  };
  assert.equal(resumeStage(failed), "design");
  assert.equal(prepareRunResume(failed), true);
  assert.equal(failed.status, "interrupted");
  assert.equal(failed.lastError, null);

  const paused = { status: "paused", plan: normalizePlan({ nodes: [{ id: "one", title: "One", status: "interrupted" }] }), pauseHistory: [{ id: "pause-1" }] };
  assert.equal(resumeStage(paused), "run");
  assert.equal(prepareRunResume(paused), true);
  assert.ok(paused.pauseHistory[0].resumedAt);
});

test("operator resume opens a fresh audited correction window after the cap", () => {
  const run = {
    status: "needs_attention",
    lastError: "Paused after 12 verification attempts without a passing result.",
    checkpoint: { title: "Correction stalled", prompt: "Latest high finding" },
    reviews: [{ round: 12, actionableFindings: [{ severity: "high", claim: "Latest high finding" }] }],
    plan: normalizePlan({ nodes: [{ id: "done", title: "Done", status: "accepted" }] })
  };
  assert.equal(prepareRunResume(run), true);
  assert.equal(run.correctionWindowStartRound, 13);
  assert.equal(run.correctionResumes.length, 1);
  assert.equal(run.correctionResumes[0].afterRound, 12);
  assert.equal(correctionWindowRound(13, run.reviews, run.correctionWindowStartRound), 1);
});

test("clearing the queue preserves active runs", () => {
  const state = { selectedTicketId: "old", ticketRuns: { old: { status: "cancelled" }, stale: { status: "awaiting_approval" }, active: { status: "running" }, merge: { status: "merging" } } };
  assert.equal(clearInactiveRuns(state, new Set(["stale", "active", "merge"])), 2);
  assert.deepEqual(Object.keys(state.ticketRuns), ["active", "merge"]);
  assert.deepEqual(Object.keys(state.retainedRuns), ["old:legacy", "stale:legacy"]);
  assert.equal(state.selectedTicketId, null);
});

test("a preserved plan checkpoint remains approvable after setup fails", () => {
  assert.equal(planApprovalPending({ status: "needs_attention", plan: { nodes: [] }, checkpoint: { kind: "awaiting_approval" } }), true);
  assert.equal(planApprovalPending({ status: "needs_attention", plan: { nodes: [] }, checkpoint: null }), false);
});

test("an interrupted pre-plan run resumes its active workflow stage", () => {
  assert.equal(resumeStage({ status: "interrupted", plan: null, stages: [{ id: "explore", status: "active" }] }), "explore");
  assert.equal(resumeStage({ status: "interrupted", plan: { nodes: [] }, stages: [] }), "run");
});

test("archives repeated ticket runs without overwriting their audit history", () => {
  const state = { ticketRuns: { ticket: { id: "ticket", runId: "run-2" } }, retainedRuns: { "ticket:run-1": { runId: "run-1" } } };
  archiveRun(state, "ticket");
  assert.deepEqual(Object.keys(state.retainedRuns), ["ticket:run-1", "ticket:run-2"]);
  assert.equal(state.ticketRuns.ticket, undefined);
});

test("rewinds a step and every later step to its recorded tree", () => {
  const plan = normalizePlan({ nodes: [
    { id: "one", title: "One", status: "accepted" },
    { id: "two", title: "Two", status: "review_ready" },
    { id: "three", title: "Three", status: "ready", dependsOn: ["two"] }
  ] });
  Object.assign(plan.nodes[0], { baseTree: "base", attempts: [{}] });
  Object.assign(plan.nodes[1], { baseTree: "after-one", attempts: [{}, {}] });
  const run = {
    status: "awaiting_step_review", checkpoint: { kind: "step_review" }, activeRuns: {}, baselineTree: "base", plan,
    stages: ["requirements", "explore", "design", "implement", "verify", "handoff"].map((id) => ({ id, status: "completed", activity: {} }))
  };
  const audit = rewindRun(run, "step:two", "2026-08-27T12:00:00.000Z");
  assert.equal(audit.restoredTree, "after-one");
  assert.deepEqual(audit.resetStepIds, ["two", "three"]);
  assert.equal(audit.discardedAttempts, 0);
  assert.equal(audit.retainedAttempts, 2);
  assert.equal(run.plan.nodes[1].attempts.length, 2);
  assert.deepEqual(run.plan.nodes.map((step) => step.status), ["accepted", "ready", "ready"]);
  assert.equal(run.stages.find((stage) => stage.id === "implement").status, "pending");
  assert.equal(run.restartHistory[0].fromCheckpoint, "step_review");
});

test("rewinds per-repository live state for step:id and bare step id", () => {
  for (const target of ["step:two", "two"]) {
    const plan = normalizePlan({ nodes: [
      { id: "one", title: "One", status: "accepted" },
      { id: "two", title: "Two", status: "review_ready" }
    ] });
    Object.assign(plan.nodes[1], {
      baseTree: "a-before",
      baseTrees: { primary: "a-before", b: "b-before" },
      vcsChange: { changeId: "old-a" },
      repositoryVcs: { b: { changeId: "old-b-change" } },
      repositoryDiffs: { b: { files: ["gone.txt"] } },
      workspaceCommits: { b: "deadbeef" },
      acceptedRepositories: { b: { commit: "cafe" } },
      attempts: [{}]
    });
    const run = {
      status: "awaiting_step_review", checkpoint: { kind: "step_review" }, activeRuns: {}, baselineTree: "base", plan,
      stages: ["requirements", "explore", "design", "implement", "verify", "handoff"].map((id) => ({ id, status: "completed" }))
    };
    const audit = rewindRun(run, target, "2026-08-27T12:00:00.000Z");
    assert.equal(audit.restoredTree, "a-before");
    assert.deepEqual(audit.restoredTrees, { primary: "a-before", b: "b-before" });
    assert.equal(run.plan.nodes[1].status, "ready");
    assert.equal(run.plan.nodes[1].vcsChange, null);
    assert.equal(run.plan.nodes[1].baseTree, undefined);
    assert.equal(run.plan.nodes[1].baseTrees, undefined);
    assert.equal(run.plan.nodes[1].repositoryVcs, undefined);
    assert.equal(run.plan.nodes[1].repositoryDiffs, undefined);
    assert.equal(run.plan.nodes[1].workspaceCommits, undefined);
    assert.equal(run.plan.nodes[1].acceptedRepositories, undefined);
    assert.equal(run.plan.nodes[1].attempts.length, 1);
    assert.equal(audit.previousSteps[1].repositoryVcs.b.changeId, "old-b-change");
  }
});

test("restarts verification without discarding accepted implementation", () => {
  const run = {
    status: "needs_attention", checkpoint: null, activeRuns: {}, reviews: [{}],
    stages: ["requirements", "explore", "design", "implement", "verify", "handoff"].map((id) => ({ id, status: "completed" })),
    plan: normalizePlan({ nodes: [{ id: "one", title: "One", status: "accepted" }] })
  };
  rewindRun(run, "stage:verify");
  assert.equal(run.plan.nodes[0].status, "accepted");
  assert.deepEqual(run.reviews, [{}]);
  assert.equal(run.stages.find((stage) => stage.id === "verify").status, "pending");
});

test("activity capture bounds memory and coalesces pending persistence", async () => {
  let releaseFirstWrite;
  const firstWrite = new Promise((resolve) => { releaseFirstWrite = resolve; });
  let writes = 0;
  let activeWrites = 0;
  let maxActiveWrites = 0;
  const capture = createActivityCapture({
    outputLimit: 100,
    eventLimit: 5,
    now: () => 1,
    persist: async () => {
      writes++;
      activeWrites++;
      maxActiveWrites = Math.max(maxActiveWrites, activeWrites);
      if (writes === 1) await firstWrite;
      activeWrites--;
    }
  });

  capture.onEvent({ type: "tool_start", label: "Started" });
  capture.onEvent({ type: "prompt", label: "Prompt rendered", content: "Keep this exact prompt" });
  for (let index = 0; index < 1000; index++) {
    capture.onEvent({ type: "tool_update", detail: "x".repeat(1000) });
    capture.onEvent({ type: "text_delta", delta: "output" });
  }

  assert.equal(writes, 1);
  assert.equal(capture.snapshot().events.length, 5);
  assert.equal(capture.snapshot().prompts[0].content, "Keep this exact prompt");
  assert.equal(capture.snapshot().rawOutput.length, 100);
  releaseFirstWrite();
  await capture.flush();
  assert.equal(writes, 2);
  assert.equal(maxActiveWrites, 1);
});

test("activity and attempt snapshots redact secrets before durable persistence", () => {
  const capture = createActivityCapture({ now: () => 1 });
  capture.onEvent({ type: "prompt", content: "Use token=secret_abcdefgh", label: "Prompt" });
  capture.onEvent({ type: "tool_end", result: "Authorization: Bearer abcdefghijklmnop", label: "Done" });
  capture.onEvent({ type: "text_delta", delta: "ghp_0123456789abcdefghijklmnop" });
  const activity = capture.snapshot();
  assert.equal(JSON.stringify(activity).includes("secret_abcdefgh"), false);
  assert.equal(JSON.stringify(activity).includes("abcdefghijklmnop"), false);
  const step = normalizePlan({ nodes: [{ id: "one", title: "One" }] }).nodes[0];
  const attempt = materializeActiveAttempt(step, { attemptId: "attempt-1", activity }, {
    status: "failed", error: "password=secret_abcdefgh", report: { summary: "token=secret_abcdefgh" }
  });
  assert.equal(JSON.stringify(attempt).includes("secret_abcdefgh"), false);
});

test("groups persisted activity into named repository, change, and verification steps", () => {
  const groups = groupActivityEvents([
    { type: "agent_start", at: "2026-09-02T09:59:59.000Z" },
    { type: "usage", input: 20, output: 4, at: "2026-09-02T10:00:00.000Z" },
    { type: "tool_start", tool: "read", callId: "read", at: "2026-09-02T10:00:00.000Z" },
    { type: "tool_end", tool: "read", callId: "read", at: "2026-09-02T10:00:01.000Z" },
    { type: "tool_start", tool: "edit", callId: "edit", at: "2026-09-02T10:00:02.000Z" },
    { type: "tool_end", tool: "edit", callId: "edit", at: "2026-09-02T10:00:03.000Z" },
    { type: "tool_start", tool: "bash", callId: "test", args: '{"command":"npm test"}', at: "2026-09-02T10:00:04.000Z" }
  ]);
  assert.deepEqual(groups.map((group) => [group.title, group.status, group.events.length]), [
    ["Explore repository", "complete", 2],
    ["Change implementation", "complete", 2],
    ["Run verification", "running", 1]
  ]);
});

test("plan approval ignores supervisor workflow gates", () => {
  assert.equal(planApprovalPending({ plan: { nodes: [] }, checkpoint: { kind: "awaiting_approval", source: "supervisor" } }), false);
});

test("correction pauses when findings repeat but allows distinct medium-or-higher issues to progress", () => {
  const findings = [{ severity: "high", claim: "Missing guard", evidence: [{ file: "src/a.ts", line: 9 }] }];
  const first = shouldPauseCorrection({ round: 1, findings, previousFingerprint: "" });
  assert.equal(first.pause, false);
  const repeat = shouldPauseCorrection({ round: 2, findings, previousFingerprint: first.fingerprint });
  assert.equal(repeat.pause, true);
  assert.match(repeat.reason, /repeated/);
  const progressing = shouldPauseCorrection({ round: 3, findings, previousFingerprint: "other" });
  assert.equal(progressing.pause, false);
  const stillProgressing = shouldPauseCorrection({ round: 6, findings, previousFingerprint: "other" });
  assert.equal(stillProgressing.pause, false);
  const capped = shouldPauseCorrection({ round: 12, findings, previousFingerprint: "other" });
  assert.equal(capped.pause, true);
  assert.match(capped.reason, /12 verification attempts/);
});

test("changed repository failure diagnostics count as correction progress", () => {
  const first = [{ severity: "blocking", category: "tests", claim: "Repository check failed: node verify.mjs", suggestedFix: "not ok 1 - request returned 400" }];
  const second = [{ severity: "blocking", category: "tests", claim: "Repository check failed: node verify.mjs", suggestedFix: "not ok 1 - expected 0 actual 1" }];
  const fingerprint = findingsFingerprint(first);
  assert.equal(shouldPauseCorrection({ round: 2, findings: first, previousFingerprint: fingerprint }).pause, true);
  assert.equal(shouldPauseCorrection({ round: 2, findings: second, previousFingerprint: fingerprint }).pause, false);
});

test("new human proof feedback starts a fresh bounded correction window", () => {
  const reviews = [
    { round: 11, actionableFindings: [{ severity: "high", category: "tests", claim: "Old failure" }] },
    { round: 12, actionableFindings: [{ severity: "blocking", category: "human-proof-review", claim: "Remove harness artifacts" }] }
  ];
  assert.equal(correctionWindowRound(12, reviews), 1);
  assert.equal(correctionWindowRound(13, reviews), 2);
  assert.equal(correctionWindowRound(12, reviews.slice(0, 1)), 12);
});

test("recurring review clusters survive changed wording and duplicate reviewers", () => {
  const finding = (claim) => ({ severity: "high", category: "requirements", claim, evidence: [{ file: "src/steering.js", line: 12 }] });
  assert.deepEqual(recurringReviewClusters([
    { actionableFindings: [finding("Postgres is accepted"), finding("OAuth is accepted")] },
    { actionableFindings: [finding("CSV export is accepted")] },
    { actionableFindings: [finding("SQLite is accepted")] }
  ]), ["requirements:src/steering.js:12"]);
  assert.deepEqual(recurringReviewClusters([
    { actionableFindings: [finding("First occurrence")] },
    { actionableFindings: [finding("Second occurrence")] }
  ]), []);
  assert.deepEqual(recurringReviewClusters([
    { actionableFindings: [{ severity: "blocking", category: "tests", claim: "Repository check failed" }] },
    { actionableFindings: [{ severity: "blocking", category: "tests", claim: "Repository check failed" }] },
    { actionableFindings: [{ severity: "blocking", category: "tests", claim: "Repository check failed" }] }
  ]), []);
  assert.deepEqual(recurringReviewClusters([
    { actionableFindings: [{ ...finding("First defect"), evidence: [{ file: "test/run.test.js", line: 10 }] }] },
    { actionableFindings: [{ ...finding("Second defect"), evidence: [{ file: "test/run.test.js", line: 40 }] }] },
    { actionableFindings: [{ ...finding("Third defect"), evidence: [{ file: "test/run.test.js", line: 80 }] }] }
  ]), []);
});

test("a recurring surface receives one root-cause escalation without blocking later distinct findings", () => {
  const finding = (claim) => ({ severity: "high", category: "requirements", claim, evidence: [{ file: "src/steering.js" }] });
  const reviews = [
    { actionableFindings: [finding("First bypass")] },
    { actionableFindings: [finding("Second bypass")] },
    { actionableFindings: [finding("Third bypass")], fix: { rootCauseClusters: ["requirements:src/steering.js"] } },
    { actionableFindings: [finding("New ambiguity on the same surface")] }
  ];
  assert.deepEqual(recurringReviewClusters(reviews), ["requirements:src/steering.js"]);
  assert.deepEqual(unaddressedReviewClusters(reviews), []);
});

test("correction pause output retains the latest actionable evidence", () => {
  const reason = correctionPauseReason("Paused after 3 verification attempts.", [{
    severity: "high",
    claim: "Sentence-final root paths evade scope checks",
    evidence: [{ file: "src/scope.js", line: 42 }],
    suggestedFix: "Cover punctuation delimiters with a table-driven regression."
  }]);
  assert.match(reason, /\[HIGH\] Sentence-final root paths evade scope checks/);
  assert.match(reason, /src\/scope\.js:42/);
  assert.match(reason, /table-driven regression/);
});

test("final-review fixes keep audit prose out of the product repository", () => {
  const findings = [{ severity: "high", claim: "Cleanup can miss a late child" }];
  const step = finalReviewFixStep(2, findings, ["correctness:src/process.js"]);
  assert.deepEqual(step.expectedArtifacts, []);
  assert.match(step.prompt, /Cleanup can miss a late child/);
  assert.match(step.prompt, /external audit records, not product artifacts/);
  assert.match(step.prompt, /Fix the general invariant/);
  assert.match(finalReviewRepositoryBoundary, /harness removes its legacy copies/);
  assert.match(finalReviewFixFeedback(findings), /supersedes any earlier duplicated or stale finding list/);
  assert.match(finalReviewFixFeedback(findings), /Cleanup can miss a late child/);
  assert.match(finalReviewFixFeedback(findings), /do not add a synthetic fallback/);
});

test("an interrupted final-review fix resumes from persisted findings", () => {
  const findings = [{ severity: "high", claim: "Cleanup can miss a late child", evidence: [{ file: "src/process.js", line: 42 }] }];
  assert.deepEqual(pendingReviewFix([{ round: 2, actionableFindings: findings }]), { round: 2, findings, sessionFile: null, restartFeedback: "" });
  assert.deepEqual(pendingReviewFix([{ round: 2, actionableFindings: findings, fix: { sessionFile: "/tmp/review-fix.jsonl" } }]), { round: 2, findings, sessionFile: "/tmp/review-fix.jsonl", restartFeedback: "" });
  assert.deepEqual(pendingReviewFix([{ round: 2, actionableFindings: findings, fix: { report: { status: "needs_input" } } }]), { round: 2, findings, sessionFile: null, restartFeedback: "" });
  assert.equal(pendingReviewFix([{ round: 2, actionableFindings: findings, fix: { report: { status: "completed" } } }]), null);
  assert.equal(pendingReviewFix([{ round: 2, actionableFindings: [] }]), null);
});

test("a contaminated fixer session restarts fresh without discarding its worktree", () => {
  const run = {
    status: "paused", checkpoint: { kind: "pause" }, lastError: "old",
    pendingReviewAttempt: { round: 19, checks: { status: "failed" } },
    reviews: [{ round: 18, actionableFindings: [{ severity: "high", claim: "Live capture URL is missing" }], fix: { sessionFile: "/audit/old.jsonl", startedAt: "before" } }]
  };
  assert.deepEqual(restartReviewFixSession(run, "Remove the queued synthetic fallback", ["public/app.js", "scripts/capture.mjs"]), { round: 18, previousSessionFile: "/audit/old.jsonl" });
  assert.equal(run.status, "interrupted");
  assert.equal(run.reviews[0].fix.sessionFile, null);
  assert.equal(run.pendingReviewAttempt, undefined);
  assert.match(run.reviews[0].fix.restartFeedback, /synthetic fallback/);
  assert.match(run.reviews[0].fix.restartFeedback, /Inherited changed files at restart:\n- public\/app\.js\n- scripts\/capture\.mjs/);
  assert.equal(run.reviewFixSessionRestarts[0].previousSessionFile, "/audit/old.jsonl");
  assert.deepEqual(run.reviewFixSessionRestarts[0].inheritedFiles, ["public/app.js", "scripts/capture.mjs"]);
  const prompt = finalReviewFixStep(18, run.reviews[0].actionableFindings, [], run.reviews[0].fix.restartFeedback).prompt;
  assert.match(prompt, /Operator restart directive/);
  assert.match(prompt, /inspect its complete current diff/);
  assert.match(prompt, /name every file remaining in the final diff/);
  assert.equal(reviewFixConstraints(run), "- Remove the queued synthetic fallback");
});

test("an interrupted run can restart its contaminated fixer after a daemon reload", () => {
  const run = {
    status: "interrupted",
    reviews: [{ round: 4, actionableFindings: [{ severity: "medium", claim: "Proof used stale server code" }], fix: { sessionFile: "/audit/stale.jsonl" } }]
  };

  assert.deepEqual(restartReviewFixSession(run, "Use the corrected proof harness"), { round: 4, previousSessionFile: "/audit/stale.jsonl" });
  assert.equal(run.reviews[0].fix.sessionFile, null);
});

test("operator fixer constraints survive into later correction rounds", () => {
  const run = { reviewFixSessionRestarts: [
    { reason: "Never replace live ticket capture with a seeded fallback" },
    { reason: "Never replace live ticket capture with a seeded fallback" },
    { reason: "Validate the rendered ticket identity before saving proof" }
  ] };
  const constraints = reviewFixConstraints(run);
  assert.match(finalReviewFixStep(19, [{ severity: "high", claim: "Wrong ticket is visible" }], [], constraints).prompt, /Never replace live ticket capture/);
  assert.equal(constraints.split("\n").length, 2);
});

test("a persisted clean review resumes at final proof without rerunning reviewers", () => {
  const clean = { round: 4, actionableFindings: [], diff: { summary: "clean" }, reviews: [
    { role: "deterministic", checks: { status: "passed", summary: "240 tests passed" } }
  ] };
  assert.deepEqual(recoverableCleanReview({ reviews: [clean] }), {
    round: 4, checks: clean.reviews[0].checks, diff: clean.diff
  });
  assert.equal(recoverableCleanReview({ reviews: [{ ...clean, actionableFindings: [{ severity: "medium" }] }] }), null);
  assert.equal(recoverableCleanReview({ reviews: [clean], pendingEvidenceFeedback: "Please revise" }), null);
  assert.equal(recoverableCleanReview({ reviews: [clean], checkpoint: { kind: "evidence_review" } }), null);
  assert.equal(recoverableCleanReview({ reviews: [{ ...clean, reviews: [] }] }), null);
});

test("resuming a model session does not re-embed its existing image context", () => {
  const images = [{ mimeType: "image/png", data: "large-base64-payload" }];
  assert.equal(reviewFixImages(null, [{ severity: "medium", claim: "Screenshot layout clips the title" }], images), images);
  assert.deepEqual(reviewFixImages(null, [{ severity: "high", claim: "Artifact IDs collide" }], images), []);
  assert.deepEqual(reviewFixImages("/tmp/persisted-session.jsonl", [{ severity: "medium", claim: "Screenshot layout clips the title" }], images), []);
});

test("a verifier transport failure does not resurrect superseded correction feedback", () => {
  const oldFinding = { severity: "blocking", claim: "Old repository failure", suggestedFix: "Very large stale log" };
  const step = { attempts: [
    { status: "verification_failed", verification: { findings: [oldFinding] } },
    { status: "failed", report: { status: "completed" }, checks: { status: "passed" }, verification: null, error: "Provider rejected image" }
  ] };
  const feedback = interruptedStepFeedback(step);
  assert.match(feedback, /independent verifier failed/);
  assert.match(feedback, /make no edits/);
  assert.doesNotMatch(feedback, /Old repository failure|stale log/);
});

test("an audited scope expansion starts a fresh bounded correction window", () => {
  const step = {
    attempts: [
      { completedAt: "2026-09-03T10:00:00.000Z", verification: { findings: [{ severity: "high", claim: "Old" }] } },
      { completedAt: "2026-09-03T10:05:00.000Z", error: "provider timeout" },
      { completedAt: "2026-09-03T10:10:00.000Z", report: { status: "needs_input" } },
      { completedAt: "2026-09-03T10:20:00.000Z", verification: { findings: [{ severity: "medium", claim: "New" }] } }
    ],
    scopeChanges: [{ at: "2026-09-03T10:15:00.000Z", paths: ["test/e2e.test.js"] }]
  };
  assert.equal(nextCorrectionRound(step), 2);
  assert.equal(nextCorrectionRound({ attempts: step.attempts }), 3);
});

test("the strict visual-evidence policy audit resets legacy correction windows once", () => {
  const run = {
    plan: normalizePlan({ nodes: [{ id: "visual", title: "Prove it", requiresVisualEvidence: true }, { id: "logic", title: "Check it" }] })
  };
  run.plan.nodes[0].attempts = [{ completedAt: "2026-09-03T10:00:00.000Z", verification: { findings: [{ severity: "high", claim: "Old preview mismatch" }] } }];
  assert.deepEqual(auditVisualEvidencePolicy(run, "2026-09-03T10:15:00.000Z"), ["visual"]);
  assert.equal(run.harnessEvidencePolicy, visualEvidencePolicy);
  assert.equal(nextCorrectionRound(run.plan.nodes[0]), 1);
  assert.deepEqual(auditVisualEvidencePolicy(run, "2026-09-03T10:20:00.000Z"), []);
  assert.equal(run.plan.nodes[0].correctionResets.length, 1);
});

test("a correction keeps its verification focus after the round window resets", () => {
  const findings = [{ severity: "high", claim: "The supplied screenshot is incomplete" }];
  assert.deepEqual(verificationFocusFindings("Retry the interrupted correction", findings), findings);
  assert.deepEqual(verificationFocusFindings("", findings), []);
});

test("provider usage exhaustion becomes a durable wait checkpoint", () => {
  assert.deepEqual(providerWaitCheckpoint(new Error("Codex error: The usage limit has been reached. Try again at Sep 7th, 2026 8:42 PM.")), {
    kind: "provider_wait", title: "Paused for provider capacity",
    prompt: "Codex error: The usage limit has been reached. Try again at Sep 7th, 2026 8:42 PM.",
    retryAt: "Sep 7th, 2026 8:42 PM"
  });
  assert.equal(providerWaitCheckpoint(new Error("Verification failed")), null);
});

test("public projections preserve legacy compatibility and stored proof eligibility", () => {
  const plan = normalizePlan({ nodes: [{ id: "build", title: "Build", acceptanceCriteria: ["Works"] }] });
  const run = { id: "proof", plan, proofMap: initializeProofMap(plan), artifacts: [], stages: [] };
  assert.equal(compactRun(run).proofMap.compatibility, false);
  assert.equal(compactRun(run).proofMap.eligibility.eligible, false);
  assert.equal(publicState({ ticketRuns: { proof: run }, retainedRuns: {} }).ticketRuns.proof.proofMap.criteria[0].text, "Works");
  const legacy = compactRun({ id: "legacy", plan, artifacts: [], stages: [] }).proofMap;
  assert.equal(legacy.compatibility, true);
  assert.equal(legacy.eligibility.eligible, true, "legacy UI consumes the server-compatible approval gate");
});

test("cleanup evidence remains pessimistic through cancellation, serialization, and archiving", () => {
  const ticket = { id: "cleanup-ticket", identifier: "CLEAN-1" };
  const run = createTicketRun(ticket, {}, { status: "running", plan: normalizePlan({ nodes: [{ id: "one", title: "One", status: "running" }] }) });
  beginRunCleanup(run, { executionId: "worker-1", stepId: "one", attemptId: "attempt-1", at: "2026-09-03T10:00:00.000Z" });
  completeRunCleanup(run, "worker-1", {
    outcome: "incomplete", platform: { name: "linux", supported: true }, discovered: [{ pid: 41, ppid: 7, startTime: "100" }],
    actions: [{ pid: 41, signal: "SIGTERM", status: "sent" }], unresolved: [{ pid: 41, reason: "still-running-after-force" }],
    diagnostics: ["Fixture process did not exit"], triggers: [{ trigger: "worker-aborted", at: "2026-09-03T10:00:01.000Z" }]
  }, { trigger: "worker-aborted", at: "2026-09-03T10:00:01.000Z" });
  beginRunCleanup(run, { executionId: "worker-2", stepId: "one", attemptId: "attempt-2", at: "2026-09-03T10:00:02.000Z" });
  completeRunCleanup(run, "worker-2", { outcome: "not-required", platform: { name: "linux", supported: true }, triggers: [] }, { trigger: "worker-completed", at: "2026-09-03T10:00:02.000Z" });

  assert.equal(run.cleanup.outcome, "incomplete");
  assert.equal(run.cleanup.executions[1].outcome, "not-required");
  assert.equal(run.cleanup.executions[1].actions.length, 0);
  markRunCancelled(run, "2026-09-03T10:00:03.000Z");
  const state = { ticketRuns: { [ticket.id]: run }, retainedRuns: {} };
  archiveRun(state, ticket.id);
  const retained = publicState(state).retainedRuns[`${ticket.id}:${run.runId}`];
  assert.equal(retained.cleanup.outcome, "incomplete");
  assert.deepEqual(retained.cleanup.executions[0].unresolved, [{ pid: 41, reason: "still-running-after-force" }]);
  assert.equal(retained.cleanup.executions[0].ownership.executionId, "worker-1");
});

test("cleanup settlement retains timestamp-distinct lifecycle triggers while deduplicating redelivery", () => {
  const run = createTicketRun({ id: "trigger-dedupe", identifier: "TRIGGER" }, {}, {});
  beginRunCleanup(run, { executionId: "worker-1", trigger: "worker-launch", at: "2026-09-03T10:00:00.000Z" });
  completeRunCleanup(run, "worker-1", { outcome: "complete", triggers: [] }, {
    trigger: "repository-command-timeout", command: "check", at: "2026-09-03T10:00:01.000Z"
  });
  completeRunCleanup(run, "worker-1", { outcome: "complete", triggers: [] }, {
    trigger: "repository-command-timeout", command: "check", at: "2026-09-03T10:00:02.000Z"
  });
  completeRunCleanup(run, "worker-1", {
    outcome: "complete",
    triggers: [{ trigger: "repository-command-timeout", command: "check", at: "2026-09-03T10:00:02.000Z" }]
  }, { trigger: "daemon-shutdown", at: "2026-09-03T10:00:03.000Z" });
  assert.deepEqual(run.cleanup.executions[0].triggers, [
    { trigger: "worker-launch", at: "2026-09-03T10:00:00.000Z" },
    { trigger: "repository-command-timeout", command: "check", at: "2026-09-03T10:00:01.000Z" },
    { trigger: "repository-command-timeout", command: "check", at: "2026-09-03T10:00:02.000Z" },
    { trigger: "daemon-shutdown", at: "2026-09-03T10:00:03.000Z" }
  ]);
});

test("late cleanup success cannot erase timeout uncertainty", () => {
  const run = createTicketRun({ id: "timeout", identifier: "TIMEOUT" }, {}, {});
  beginRunCleanup(run, { executionId: "worker-1", at: "2026-09-03T10:00:00.000Z" });
  completeRunCleanup(run, "worker-1", {
    outcome: "incomplete", unresolved: [{ reason: "cleanup-wait-timeout" }], diagnostics: ["Cleanup wait timed out"], actions: []
  }, { trigger: "worker-exit", at: "2026-09-03T10:00:01.000Z" });
  completeRunCleanup(run, "worker-1", {
    outcome: "complete", unresolved: [], diagnostics: [], actions: [{ pid: 41, signal: "SIGKILL", status: "sent" }]
  }, { trigger: "daemon-shutdown", at: "2026-09-03T10:00:02.000Z" });
  const execution = run.cleanup.executions[0];
  assert.equal(execution.outcome, "incomplete");
  assert.deepEqual(execution.unresolved, [{ reason: "cleanup-wait-timeout" }]);
  assert.deepEqual(execution.diagnostics, ["Cleanup wait timed out"]);
  assert.deepEqual(execution.actions, [{ pid: 41, signal: "SIGKILL", status: "sent" }]);
});

test("repeated incomplete settlement deduplicates shared containment evidence", () => {
  const run = createTicketRun({ id: "duplicate-cleanup", identifier: "DEDUP" }, {}, {});
  beginRunCleanup(run, { executionId: "worker-1", at: "2026-09-03T10:00:00.000Z" });
  const sharedEvidence = {
    outcome: "incomplete",
    discovered: [{ pid: 41, ppid: 7, startTime: "100" }],
    actions: [{ pid: 41, signal: "SIGTERM", status: "sent", at: "2026-09-03T10:00:01.000Z" }],
    unresolved: [{ pid: 41, identity: { ppid: 7, startTime: "100" }, reason: "still-running-after-force" }],
    diagnostics: ["Fixture process did not exit"]
  };
  completeRunCleanup(run, "worker-1", sharedEvidence, { trigger: "repository-command-timeout", at: "2026-09-03T10:00:01.000Z" });
  completeRunCleanup(run, "worker-1", {
    ...sharedEvidence,
    discovered: [...sharedEvidence.discovered, { pid: 42, ppid: 7, startTime: "101" }],
    actions: [...sharedEvidence.actions, { pid: 42, signal: "SIGKILL", status: "sent", at: "2026-09-03T10:00:02.000Z" }],
    unresolved: [...sharedEvidence.unresolved, { pid: 42, identity: { ppid: 7, startTime: "101" }, reason: "still-running-after-force" }],
    diagnostics: [...sharedEvidence.diagnostics, "Late owned process remained"]
  }, { trigger: "worker-exit", at: "2026-09-03T10:00:02.000Z" });

  const execution = run.cleanup.executions[0];
  assert.equal(execution.outcome, "incomplete");
  assert.equal(execution.discovered.length, 2);
  assert.equal(execution.actions.length, 2);
  assert.equal(execution.unresolved.length, 2);
  assert.deepEqual(execution.diagnostics, ["Fixture process did not exit", "Late owned process remained"]);
});

test("compact run and public state omit artifact bodies", () => {
  const run = {
    id: "t1", runId: "r1", status: "awaiting_approval", lastError: null,
    ticket: { id: "t1", identifier: "MEA-1", title: "Compact title", source: "linear", state: { id: "s1", name: "In Progress", type: "started", color: "#fff" }, description: "large private description" },
    checkpoint: { kind: "awaiting_approval", title: "Approve" },
    workflow: { skillName: "shape-feature", checkpoints: [] },
    stages: [{ id: "design", diff: { files: ["a.js"], patch: "large stage patch" }, activity: { prompts: [{ content: "# private prompt" }], rawOutput: "private output", groups: [{ events: [] }], events: [{ type: "tool_end", output: "x".repeat(3000) }] } }],
    artifacts: [{ id: "a", name: "design.md", path: "/tmp/design.md", kind: "architecture", content: "# secret body" }],
    plan: { nodes: [{ id: "one", type: "step", artifacts: [{ id: "b", name: "out.md", content: "worker body" }], attempts: [
      { rawOutput: "old", activityGroups: [{ events: [] }], events: [{ type: "tool_start", args: "historical args" }, { type: "tool_end", output: "historical detail" }, { type: "usage", input: 10 }], checks: { status: "failed", output: "historical checks" }, feedback: "f".repeat(5000) },
      { rawOutput: "latest", activityGroups: [{ events: [] }], events: [{ type: "tool_end", output: "y".repeat(3000) }], checks: { status: "passed", output: "latest checks" }, verification: { rawOutput: "review transcript", checks: { status: "passed", output: "duplicated checks" } }, diff: { files: ["a.js"], patch: "attempt patch" }, checkDiff: { patch: "check patch" }, aggregateDiff: { patch: "aggregate patch" } }
    ] }] },
    reviews: [{ reviews: [{ role: "deterministic", checks: { status: "passed", output: "review checks" } }], diff: { files: ["a.js"], patch: "repeated review patch" }, fix: { diff: { files: ["a.js"], patch: "fix patch" }, artifact: { id: "fix", name: "fix.md", kind: "review-fix", bodyStored: true, bodySummary: "private fix" } } }]
  };
  const compact = compactRun(run, 9);
  assert.equal(compact.revision, 9);
  assert.equal(compact.status, "awaiting_approval");
  assert.equal(compact.checkpoint.title, "Approve");
  assert.equal(compact.workflow.skillName, "shape-feature");
  assert.deepEqual(compact.ticket, { id: "t1", identifier: "MEA-1", title: "Compact title", source: "linear", provider: null, state: { id: "s1", name: "In Progress", type: "started" } });
  assert.equal(compact.ticket.description, undefined);
  assert.equal("artifacts" in compact, false);
  const published = publicState({ selectedTicketId: "t1", ticketRuns: { t1: run }, retainedRuns: {} });
  assert.equal(published.ticketRuns.t1.artifacts[0].name, "design.md");
  assert.equal(published.ticketRuns.t1.artifacts[0].content, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].artifacts[0].content, undefined);
  assert.equal(published.ticketRuns.t1.stages[0].activity.prompts, undefined);
  assert.equal(published.ticketRuns.t1.stages[0].activity.rawOutput, undefined);
  assert.equal(published.ticketRuns.t1.stages[0].activity.groups, undefined);
  assert.equal(published.ticketRuns.t1.stages[0].diff.patch, undefined);
  assert.deepEqual(published.ticketRuns.t1.plan.nodes[0].attempts[0].events.map((event) => event.type), ["tool_start", "usage"]);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[0].events[0].args, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[0].checks.output, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[0].checks.status, "failed");
  assert.match(published.ticketRuns.t1.plan.nodes[0].attempts[0].feedback, /feedback truncated/);
  assert.match(published.ticketRuns.t1.plan.nodes[0].attempts[1].events[0].output, /truncated/);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].checks.output, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].rawOutput, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].activityGroups, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].verification.rawOutput, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].verification.checks, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].diff.patch, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].checkDiff.patch, undefined);
  assert.equal(published.ticketRuns.t1.plan.nodes[0].attempts[1].aggregateDiff.patch, undefined);
  assert.equal(published.ticketRuns.t1.reviews[0].diff.patch, undefined);
  assert.equal(published.ticketRuns.t1.reviews[0].reviews[0].checks.output, undefined);
  assert.equal(published.ticketRuns.t1.reviews[0].fix.artifact.bodySummary, undefined);
});

test("public state fully projects only the selected run", () => {
  const selected = { id: "selected", runId: "r1", status: "running", artifacts: [{ id: "a" }], stages: [], plan: { nodes: [] } };
  const other = { id: "other", runId: "r2", createdAt: "2026-09-01T00:00:00.000Z", status: "paused", artifacts: [{ id: "b" }], stages: [], plan: { nodes: [] } };
  const published = publicState({ revision: 7, selectedTicketId: "selected", ticketRuns: { selected, other }, retainedRuns: {} });
  assert.ok(Array.isArray(published.ticketRuns.selected.artifacts));
  assert.deepEqual(published.ticketRuns.other, compactRun(other, 7));
});

test("preview state contains only the selected public run", () => {
  const selected = { id: "selected", runId: "r1", status: "verifying", ticket: { id: "selected", title: "Selected" }, artifacts: [{ id: "a", content: "private" }], stages: [], plan: { nodes: [] } };
  const other = { id: "other", runId: "r2", status: "completed", ticket: { id: "other", title: "Other" }, artifacts: [{ content: "x".repeat(10000) }], stages: [], plan: { nodes: [] } };
  const preview = publicPreviewState({ version: 6, revision: 8, workspace: { cwd: "/repo" }, settings: {}, stageProfiles: {}, notice: null, ticketRuns: { selected, other }, retainedRuns: { old: other } }, "selected");
  assert.equal(preview.selectedTicketId, "selected");
  assert.deepEqual(Object.keys(preview.ticketRuns), ["selected"]);
  assert.deepEqual(preview.retainedRuns, {});
  assert.equal(preview.ticketRuns.selected.ticket.title, "Selected");
  assert.equal(preview.ticketRuns.selected.artifacts[0].content, undefined);
});

test("public state keeps retained audits compact", () => {
  const retained = { id: "old", runId: "run-old", status: "completed", createdAt: "2026-01-01T00:00:00.000Z", artifacts: [{ content: "x".repeat(10000) }] };
  const published = publicState({ revision: 4, ticketRuns: {}, retainedRuns: { "old:run-old": retained } });
  assert.deepEqual(published.retainedRuns["old:run-old"], compactRun(retained, 4));
});

test("finding ledger resolves only after independent review and retains regressions", async () => {
  const { reviewFindingLedger, unresolvedReviewFindings } = await import("../src/execution.js");
  const bug = { severity: "high", category: "correctness", claim: "Submission loses its identifier", evidence: [{ file: "src/api.js", line: 4 }] };
  const capture = { severity: "high", category: "evidence", claim: "Capture fixture failed", evidence: [] };
  const rounds = [
    { round: 1, reviewMode: "independent", actionableFindings: [bug] },
    { round: 2, reviewMode: "prerequisite", actionableFindings: [capture] }
  ];
  assert.deepEqual(unresolvedReviewFindings(rounds), [bug, capture]);
  rounds.push({ round: 3, reviewMode: "independent", actionableFindings: [] });
  assert.deepEqual(unresolvedReviewFindings(rounds), []);
  rounds.push({ round: 4, reviewMode: "independent", actionableFindings: [bug] });
  const ledger = reviewFindingLedger(rounds);
  assert.equal(ledger[0].status, "regressed");
  assert.deepEqual(ledger[0].history.map(({ round, status }) => [round, status]), [[1, "open"], [3, "resolved"], [4, "regressed"]]);
  assert.equal(ledger[1].status, "resolved");
});

test("execution failures retain actionable typed diagnostics without prescribing code edits for publication", async () => {
  const { executionFailure } = await import("../src/execution.js");
  const failure = executionFailure({ failureKind: "evidence-publication", message: "Forbidden", output: "Upload denied" }, { phase: "delivery" });
  assert.equal(failure.kind, "evidence-publication");
  assert.equal(failure.phase, "delivery");
  assert.equal(failure.diagnostic, "Upload denied");
  assert.match(failure.nextAction, /forge access.*retain the reviewed files/i);
  assert.equal(executionFailure(new Error("Your input exceeds the context window")).kind, "provider");
  assert.equal(executionFailure({ code: "MODEL_RESPONSE_ERROR", message: "Invalid JSON" }).kind, "model-output");
});

test("createTicketRun freezes access so later Any-access policy cannot enlarge it", async () => {
  const root = await mkdtemp(join(tmpdir(), "agent-plan-run-access-"));
  const primary = join(root, "project");
  const extra = join(root, "shared");
  try {
    await mkdir(primary);
    await mkdir(extra);
    const access = await freezeRunAccess({
      primaryCwd: primary,
      policy: await normalizeProjectPolicy({
        extraRoots: [{ path: extra, mode: "read/write" }]
      }, { primaryCwd: primary })
    });
    const run = createTicketRun({ id: "freeze", identifier: "FREEZE" }, {}, { access });
    access.mode = "any";
    access.extraRoots.length = 0;
    assert.equal(run.access.mode, "restricted");
    assert.equal(run.access.extraRoots.length, 1);
    assert.notEqual(run.access, access);
    const later = createTicketRun({ id: "next", identifier: "NEXT" }, {}, {
      access: await freezeRunAccess({ primaryCwd: primary, policy: { mode: "any", extraRoots: [] } })
    });
    assert.equal(later.access.mode, "any");
    assert.deepEqual(later.access.extraRoots, []);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});


test("usage totals survive event trimming, resume, attempt materialization and public projection", async () => {
  let persisted;
  const capture = createActivityCapture({ eventLimit: 2, persist: async (activity) => { persisted = activity; } });
  capture.onEvent({ type: "usage", input: 123, output: 45, cacheRead: 7 });
  for (let i = 0; i < 5; i++) capture.onEvent({ type: "tool_start", label: "Read" });
  await capture.flush();
  assert.equal(persisted.events.some((event) => event.type === "usage"), false);
  assert.equal(persisted.usage.input, 123);
  const resumed = createActivityCapture({ existing: JSON.parse(JSON.stringify(persisted)) });
  resumed.onEvent({ type: "usage", input: 10, output: 2, cacheWrite: 3 });
  const activity = resumed.snapshot();
  const plan = normalizePlan({ nodes: [{ id: "build", title: "Build" }] });
  materializeActiveAttempt(plan.nodes[0], { runId: "worker", attemptId: "attempt", activity }, { status: "verified" });
  const published = publicState({ selectedTicketId: "t", ticketRuns: { t: { id: "t", runId: "r", plan, stages: [] } }, retainedRuns: {} });
  assert.deepEqual(published.ticketRuns.t.plan.nodes[0].attempts[0].usage, { input: 133, output: 47, cacheRead: 7, cacheWrite: 3, calls: 5, records: 2, complete: true });
});

test("resuming a partial legacy usage aggregate keeps numeric totals and marks it incomplete", () => {
  const capture = createActivityCapture({ existing: { usage: { input: 12 } }, now: () => 1 });
  capture.onEvent({ type: "tool_start" });
  capture.onEvent({ type: "usage", output: 3 });
  assert.deepEqual(capture.snapshot().usage, { input: 12, output: 3, cacheRead: 0, cacheWrite: 0, calls: 1, records: 1, complete: false });
});

test("materializing a finished attempt clears its active status", () => {
  const step = { id: "one", activeAttempt: { id: "attempt-1", status: "active" } };
  materializeActiveAttempt(step, { attemptId: "attempt-1" }, { status: "verified" });
  assert.equal(step.activeAttempt.status, "verified");
});
