import test from "node:test";
import assert from "node:assert/strict";
import { recordReliabilityTransitions, reliabilityReport } from "../src/reliability.js";
import { normalizePlan } from "../src/plan.js";
import { initializeProofMap, applyProofReports } from "../src/proof-map.js";

const at = (seconds) => new Date(seconds * 1000).toISOString();

test("reliability separates decision waiting and recovery from execution without inferring human attribution", () => {
  let previous = { ticketRuns: {} };
  for (const [time, status] of [[0, "running"], [10, "awaiting_approval"], [40, "running"], [50, "failed"], [70, "running"], [90, "completed"]]) {
    const draft = structuredClone(previous);
    draft.ticketRuns.t ||= { id: "t", runId: "r" };
    draft.ticketRuns.t.status = status;
    recordReliabilityTransitions(previous, draft, at(time));
    previous = draft;
  }
  const report = reliabilityReport(previous.ticketRuns.t, 100000);
  assert.deepEqual(report.timing.seconds, { execution: 40, decisionWait: 30, blocked: 20 });
  assert.equal(report.decisions.plannedGateResumes, 1);
  assert.equal(report.decisions.recoveryResumes, 1);
  assert.equal(report.firstPass, false);
  assert.equal(report.ready, false);
  assert.equal(reliabilityReport({ status: "completed" }).timing.seconds, null);
  assert.equal(reliabilityReport({ status: "completed" }).firstPass, null);
});

test("completed alone is not ready: every required criterion, final checks and review must pass", () => {
  const plan = normalizePlan({ nodes: [{ id: "save", title: "Save", acceptanceCriteria: ["Saved", "Reloaded"] }] });
  const run = { status: "completed", plan, finalChecks: { status: "passed" }, reviews: [{ actionableFindings: [] }] };
  run.proofMap = initializeProofMap(plan);
  const reports = run.proofMap.criteria.map(({ id }) => ({ criterionId: id, status: "verified", evidence: [{ type: "check", scope: "final" }] }));
  run.proofMap = applyProofReports(run.proofMap, reports.slice(0, 1), run);
  assert.equal(reliabilityReport(run).ready, false);
  run.proofMap = applyProofReports(run.proofMap, reports, run);
  assert.equal(reliabilityReport(run).ready, true);
  run.proofMap.criteria[0].current.evidenceValidity = "stale";
  assert.equal(reliabilityReport(run).ready, false);
  run.finalChecks.status = "failed";
  assert.equal(reliabilityReport(run).acceptance.finalChecksPassed, false);
});
